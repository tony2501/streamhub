import { useRef, useState, useCallback } from 'react';
import { findNodeHandle, AccessibilityInfo } from 'react-native';

export function useFocusable(onFocus?: () => void, onBlur?: () => void) {
  const ref = useRef<any>(null);
  const [focused, setFocused] = useState(false);

  const handleFocus = useCallback(() => {
    setFocused(true);
    onFocus?.();
  }, [onFocus]);

  const handleBlur = useCallback(() => {
    setFocused(false);
    onBlur?.();
  }, [onBlur]);

  return { ref, focused, handleFocus, handleBlur };
}

export function useStore() {
  const [, forceUpdate] = useState(0);
  const { Store } = require('../store');
  
  const refresh = useCallback(() => forceUpdate(n => n + 1), []);
  
  return { store: Store.get(), refresh };
}
