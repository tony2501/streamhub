export const Colors = {
  // Background layers
  bg: '#0A0A0F',
  bgCard: '#12121A',
  bgElevated: '#1A1A26',
  bgModal: '#0D0D18',

  // Accent - Stremio-style purple/violet
  accent: '#8B5CF6',
  accentBright: '#A78BFA',
  accentDark: '#6D28D9',
  accentGlow: 'rgba(139, 92, 246, 0.3)',

  // Focus ring (Fire TV D-pad)
  focus: '#FFFFFF',
  focusBorder: 'rgba(255,255,255,0.9)',

  // Text
  textPrimary: '#FFFFFF',
  textSecondary: '#A0A0B0',
  textMuted: '#505068',
  textAccent: '#A78BFA',

  // Status
  success: '#10B981',
  warning: '#F59E0B',
  error: '#EF4444',
  rdGreen: '#22C55E',

  // Overlays
  overlay: 'rgba(0,0,0,0.7)',
  overlayHeavy: 'rgba(0,0,0,0.85)',

  // Nav sidebar
  navBg: '#08080F',
  navWidth: 80,
  navWidthExpanded: 240,

  // Borders
  border: 'rgba(255,255,255,0.06)',
  borderFocus: 'rgba(139, 92, 246, 0.8)',
};

export const Typography = {
  // Scale
  xs: 11,
  sm: 13,
  base: 15,
  md: 17,
  lg: 20,
  xl: 24,
  xxl: 32,
  xxxl: 42,

  // Weights
  regular: '400' as const,
  medium: '500' as const,
  semibold: '600' as const,
  bold: '700' as const,
  heavy: '800' as const,
};

export const Spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
  xxxl: 64,
};

export const Radius = {
  sm: 4,
  md: 8,
  lg: 12,
  xl: 16,
  full: 999,
};

export const Shadow = {
  card: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
    elevation: 8,
  },
  focus: {
    shadowColor: Colors.accent,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8,
    shadowRadius: 12,
    elevation: 12,
  },
};
