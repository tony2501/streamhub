import React, { useState } from 'react';
import { View, Text, Image, StyleSheet, Pressable, Animated, ViewStyle } from 'react-native';
import { Colors, Typography, Radius, Spacing } from '../theme';
import { EmbyItem, EmbyAPI } from '../services/emby';

interface MediaCardProps {
  item: EmbyItem;
  onPress: (item: EmbyItem) => void;
  width?: number;
  height?: number;
  style?: ViewStyle;
  hasTVPreferredFocus?: boolean;
  showProgress?: boolean;
}

export function MediaCard({ item, onPress, width = 150, height = 220, style, hasTVPreferredFocus, showProgress }: MediaCardProps) {
  const [focused, setFocused] = useState(false);
  const scale = React.useRef(new Animated.Value(1)).current;
  const borderOpacity = React.useRef(new Animated.Value(0)).current;

  const imageUrl = EmbyAPI.getImageUrl(item, 'Primary', width * 2);
  const progress = item.UserData?.PlayedPercentage || 0;
  const year = item.ProductionYear;
  const rating = item.CommunityRating?.toFixed(1);

  const handleFocus = () => {
    setFocused(true);
    Animated.parallel([
      Animated.spring(scale, { toValue: 1.08, useNativeDriver: true, speed: 25, bounciness: 4 }),
      Animated.timing(borderOpacity, { toValue: 1, duration: 100, useNativeDriver: false }),
    ]).start();
  };

  const handleBlur = () => {
    setFocused(false);
    Animated.parallel([
      Animated.spring(scale, { toValue: 1, useNativeDriver: true, speed: 25 }),
      Animated.timing(borderOpacity, { toValue: 0, duration: 100, useNativeDriver: false }),
    ]).start();
  };

  return (
    <Animated.View style={[{ transform: [{ scale }] }, style]}>
      <Pressable
        onFocus={handleFocus}
        onBlur={handleBlur}
        onPress={() => onPress(item)}
        hasTVPreferredFocus={hasTVPreferredFocus}
      >
        <Animated.View style={[
          styles.card,
          { width, height },
          { borderColor: borderOpacity.interpolate({ inputRange: [0,1], outputRange: [Colors.border, Colors.accent] }),
            borderWidth: 2 }
        ]}>
          {imageUrl ? (
            <Image source={{ uri: imageUrl }} style={styles.image} />
          ) : (
            <View style={[styles.image, styles.placeholder]}>
              <Text style={styles.placeholderText} numberOfLines={2}>{item.Name}</Text>
            </View>
          )}

          {/* Gradient overlay on focus */}
          {focused && <View style={styles.focusOverlay} />}

          {/* Progress bar */}
          {showProgress && progress > 0 && (
            <View style={styles.progressTrack}>
              <View style={[styles.progressFill, { width: `${Math.min(progress, 100)}%` as any }]} />
            </View>
          )}

          {/* Rating badge */}
          {rating && (
            <View style={styles.ratingBadge}>
              <Text style={styles.ratingText}>⭐ {rating}</Text>
            </View>
          )}
        </Animated.View>

        {/* Title below card */}
        <View style={{ width, marginTop: Spacing.xs }}>
          <Text style={styles.title} numberOfLines={1}>{item.Name}</Text>
          {year && <Text style={styles.year}>{year}</Text>}
        </View>
      </Pressable>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  card: {
    borderRadius: Radius.md,
    overflow: 'hidden',
    backgroundColor: Colors.bgCard,
  },
  image: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  placeholder: {
    backgroundColor: Colors.bgElevated,
    justifyContent: 'center',
    alignItems: 'center',
    padding: Spacing.sm,
  },
  placeholderText: {
    color: Colors.textSecondary,
    fontSize: Typography.sm,
    textAlign: 'center',
  },
  focusOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(139, 92, 246, 0.15)',
  },
  progressTrack: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: 3,
    backgroundColor: 'rgba(255,255,255,0.2)',
  },
  progressFill: {
    height: '100%',
    backgroundColor: Colors.accent,
  },
  ratingBadge: {
    position: 'absolute',
    top: Spacing.xs,
    right: Spacing.xs,
    backgroundColor: 'rgba(0,0,0,0.7)',
    borderRadius: Radius.sm,
    paddingHorizontal: 5,
    paddingVertical: 2,
  },
  ratingText: {
    color: Colors.textPrimary,
    fontSize: Typography.xs,
    fontWeight: Typography.semibold,
  },
  title: {
    color: Colors.textPrimary,
    fontSize: Typography.sm,
    fontWeight: Typography.medium,
  },
  year: {
    color: Colors.textMuted,
    fontSize: Typography.xs,
    marginTop: 1,
  },
});
