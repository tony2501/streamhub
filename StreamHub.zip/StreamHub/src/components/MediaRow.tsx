import React, { useRef } from 'react';
import { View, Text, ScrollView, StyleSheet, ViewStyle } from 'react-native';
import { Colors, Typography, Spacing } from '../theme';
import { MediaCard } from './MediaCard';
import { EmbyItem } from '../services/emby';

interface MediaRowProps {
  title: string;
  items: EmbyItem[];
  onPressItem: (item: EmbyItem) => void;
  cardWidth?: number;
  cardHeight?: number;
  showProgress?: boolean;
  style?: ViewStyle;
  firstFocused?: boolean;
}

export function MediaRow({ title, items, onPressItem, cardWidth = 150, cardHeight = 220, showProgress, style, firstFocused }: MediaRowProps) {
  if (!items.length) return null;

  return (
    <View style={[styles.container, style]}>
      <Text style={styles.title}>{title}</Text>
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.scroll}
      >
        {items.map((item, idx) => (
          <MediaCard
            key={item.Id}
            item={item}
            onPress={onPressItem}
            width={cardWidth}
            height={cardHeight}
            showProgress={showProgress}
            hasTVPreferredFocus={firstFocused && idx === 0}
            style={{ marginRight: Spacing.md }}
          />
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: Spacing.xl,
  },
  title: {
    color: Colors.textPrimary,
    fontSize: Typography.lg,
    fontWeight: Typography.semibold,
    marginBottom: Spacing.md,
    marginLeft: Spacing.xl,
    letterSpacing: 0.3,
  },
  scroll: {
    paddingHorizontal: Spacing.xl,
  },
});
