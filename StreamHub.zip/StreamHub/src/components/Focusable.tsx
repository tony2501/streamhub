import React, { useState } from 'react';
import { Pressable, PressableProps, ViewStyle, StyleSheet, Animated } from 'react-native';
import { Colors, Radius } from '../theme';

interface FocusableProps extends PressableProps {
  children: React.ReactNode;
  style?: ViewStyle | ViewStyle[];
  focusStyle?: ViewStyle;
  onFocusChange?: (focused: boolean) => void;
  hasTVPreferredFocus?: boolean;
}

export function Focusable({
  children,
  style,
  focusStyle,
  onFocusChange,
  hasTVPreferredFocus,
  onPress,
  ...props
}: FocusableProps) {
  const [focused, setFocused] = useState(false);
  const scale = React.useRef(new Animated.Value(1)).current;

  const handleFocus = () => {
    setFocused(true);
    onFocusChange?.(true);
    Animated.spring(scale, { toValue: 1.05, useNativeDriver: true, speed: 20 }).start();
  };

  const handleBlur = () => {
    setFocused(false);
    onFocusChange?.(false);
    Animated.spring(scale, { toValue: 1, useNativeDriver: true, speed: 20 }).start();
  };

  return (
    <Animated.View style={{ transform: [{ scale }] }}>
      <Pressable
        onFocus={handleFocus}
        onBlur={handleBlur}
        onPress={onPress}
        hasTVPreferredFocus={hasTVPreferredFocus}
        style={[
          style as ViewStyle,
          focused && (focusStyle || styles.defaultFocus),
          focused && focusStyle === undefined && styles.defaultFocusRing,
        ]}
        {...props}
      >
        {children}
      </Pressable>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  defaultFocus: {},
  defaultFocusRing: {
    borderWidth: 2,
    borderColor: Colors.focus,
    borderRadius: Radius.md,
  },
});
