import React, { useState } from 'react';
import { View, Text, StyleSheet, Pressable, Animated } from 'react-native';
import { Colors, Typography, Spacing, Radius } from '../theme';

export type NavTab = 'home' | 'discover' | 'library' | 'search' | 'settings';

interface NavItem {
  id: NavTab;
  label: string;
  icon: string;
}

const NAV_ITEMS: NavItem[] = [
  { id: 'home',     label: 'Home',     icon: '⌂' },
  { id: 'discover', label: 'Discover', icon: '◎' },
  { id: 'library',  label: 'Library',  icon: '▣' },
  { id: 'search',   label: 'Search',   icon: '⌕' },
  { id: 'settings', label: 'Settings', icon: '⚙' },
];

interface SidebarProps {
  activeTab: NavTab;
  onTabChange: (tab: NavTab) => void;
}

export function Sidebar({ activeTab, onTabChange }: SidebarProps) {
  const [hoveredTab, setHoveredTab] = useState<NavTab | null>(null);

  return (
    <View style={styles.sidebar}>
      {/* Logo */}
      <View style={styles.logoContainer}>
        <Text style={styles.logoIcon}>▶</Text>
        <Text style={styles.logoText}>Stream{'\n'}Hub</Text>
      </View>

      {/* Nav items */}
      <View style={styles.nav}>
        {NAV_ITEMS.map(item => {
          const isActive = activeTab === item.id;
          const isHovered = hoveredTab === item.id;
          return (
            <Pressable
              key={item.id}
              onFocus={() => setHoveredTab(item.id)}
              onBlur={() => setHoveredTab(null)}
              onPress={() => onTabChange(item.id)}
              style={[
                styles.navItem,
                isActive && styles.navItemActive,
                isHovered && !isActive && styles.navItemHovered,
              ]}
            >
              <Text style={[styles.navIcon, isActive && styles.navIconActive]}>
                {item.icon}
              </Text>
              <Text style={[styles.navLabel, isActive && styles.navLabelActive]} numberOfLines={1}>
                {item.label}
              </Text>
              {isActive && <View style={styles.activeIndicator} />}
            </Pressable>
          );
        })}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  sidebar: {
    width: Colors.navWidth,
    backgroundColor: Colors.navBg,
    borderRightWidth: 1,
    borderRightColor: Colors.border,
    paddingVertical: Spacing.lg,
    alignItems: 'center',
  },
  logoContainer: {
    alignItems: 'center',
    marginBottom: Spacing.xxl,
    paddingTop: Spacing.md,
  },
  logoIcon: {
    fontSize: 28,
    color: Colors.accent,
    marginBottom: 4,
  },
  logoText: {
    color: Colors.textPrimary,
    fontSize: Typography.xs,
    fontWeight: Typography.bold,
    textAlign: 'center',
    lineHeight: 14,
    letterSpacing: 0.5,
  },
  nav: {
    flex: 1,
    width: '100%',
    paddingHorizontal: Spacing.sm,
    gap: Spacing.xs,
  },
  navItem: {
    alignItems: 'center',
    paddingVertical: Spacing.md,
    borderRadius: Radius.md,
    position: 'relative',
    gap: 4,
  },
  navItemActive: {
    backgroundColor: Colors.accentGlow,
  },
  navItemHovered: {
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  navIcon: {
    fontSize: 20,
    color: Colors.textMuted,
  },
  navIconActive: {
    color: Colors.accent,
  },
  navLabel: {
    fontSize: Typography.xs,
    color: Colors.textMuted,
    fontWeight: Typography.medium,
  },
  navLabelActive: {
    color: Colors.accentBright,
  },
  activeIndicator: {
    position: 'absolute',
    left: 0,
    top: '20%',
    bottom: '20%',
    width: 3,
    backgroundColor: Colors.accent,
    borderRadius: Radius.full,
  },
});
