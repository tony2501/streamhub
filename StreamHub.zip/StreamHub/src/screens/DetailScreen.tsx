import React, { useState, useEffect } from 'react';
import {
  View, Text, Image, StyleSheet, ScrollView, Pressable,
  ActivityIndicator, FlatList, Modal
} from 'react-native';
import { Colors, Typography, Spacing, Radius } from '../theme';
import { EmbyAPI, EmbyItem } from '../services/emby';
import { TorrentioAPI, TorrentStream } from '../services/realdebrid';
import { Store } from '../store';

interface DetailScreenProps {
  item: EmbyItem;
  onPlay: (url: string, title: string, item: EmbyItem) => void;
  onBack: () => void;
}

export function DetailScreen({ item, onPlay, onBack }: DetailScreenProps) {
  const [seasons, setSeasons] = useState<EmbyItem[]>([]);
  const [episodes, setEpisodes] = useState<EmbyItem[]>([]);
  const [selectedSeason, setSelectedSeason] = useState<EmbyItem | null>(null);
  const [loading, setLoading] = useState(false);
  const [showStreamPicker, setShowStreamPicker] = useState(false);
  const [streams, setStreams] = useState<TorrentStream[]>([]);
  const [streamsLoading, setStreamsLoading] = useState(false);
  const [playTarget, setPlayTarget] = useState<EmbyItem | null>(null);

  const emby = Store.get().emby!;
  const backdropUrl = item.BackdropImageTags?.[0]
    ? `${emby.serverUrl}/Items/${item.Id}/Images/Backdrop?tag=${item.BackdropImageTags[0]}&maxWidth=1920&quality=80`
    : null;
  const posterUrl = EmbyAPI.getImageUrl(item, 'Primary', 400);
  const isSeries = item.Type === 'Series';

  // Load seasons if series
  useEffect(() => {
    if (!isSeries) return;
    EmbyAPI.getSeasons(item.Id).then(s => {
      setSeasons(s);
      if (s.length) setSelectedSeason(s[0]);
    });
  }, [item.Id, isSeries]);

  // Load episodes when season changes
  useEffect(() => {
    if (!selectedSeason) return;
    EmbyAPI.getEpisodes(item.Id, selectedSeason.Id).then(setEpisodes);
  }, [selectedSeason, item.Id]);

  const handlePlayEmby = async (target: EmbyItem) => {
    setLoading(true);
    try {
      const info = await EmbyAPI.getPlaybackInfo(target.Id);
      const src = info.MediaSources?.[0];
      if (src) {
        const url = EmbyAPI.getStreamUrl(target.Id, src.Id);
        onPlay(url, target.Name, target);
      }
    } catch (e) {
      console.error('Playback error', e);
    } finally {
      setLoading(false);
    }
  };

  const handleOpenStreamPicker = async (target: EmbyItem) => {
    setPlayTarget(target);
    setShowStreamPicker(true);
    setStreamsLoading(true);
    setStreams([]);

    // Get Emby stream
    try {
      const info = await EmbyAPI.getPlaybackInfo(target.Id);
      const src = info.MediaSources?.[0];
      if (src) {
        const embyStream: TorrentStream = {
          name: 'Emby Library',
          title: `📀 ${src.Name || target.Name}`,
          url: EmbyAPI.getStreamUrl(target.Id, src.Id),
          quality: 'Direct',
          source: 'Direct',
          rdCached: false,
        };
        setStreams([embyStream]);
      }
    } catch {}

    // Get Torrentio streams if RD configured
    const rd = Store.get().realDebrid;
    if (rd?.connected) {
      try {
        const type = isSeries ? 'series' : 'movie';
        // We use Emby's ID as a proxy - ideally you'd map to IMDB ID
        // For demo we'll just show what we have
        const torrentStreams = await TorrentioAPI.getStreams(
          target.Id,
          type,
          item.Type === 'Series' ? (target.ParentIndexNumber || 1) : undefined,
          item.Type === 'Series' ? (target.IndexNumber || 1) : undefined,
        );
        setStreams(prev => [...prev, ...torrentStreams]);
      } catch {}
    }
    setStreamsLoading(false);
  };

  const qualityColor = (q: string) => {
    if (q === '4K') return '#F59E0B';
    if (q === '1080p') return '#10B981';
    if (q === '720p') return '#3B82F6';
    return Colors.textMuted;
  };

  return (
    <View style={styles.container}>
      {/* Back button */}
      <Pressable style={styles.backBtn} onPress={onBack} hasTVPreferredFocus>
        <Text style={styles.backText}>← Back</Text>
      </Pressable>

      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Backdrop */}
        {backdropUrl && (
          <View style={styles.backdropContainer}>
            <Image source={{ uri: backdropUrl }} style={styles.backdrop} />
            <View style={styles.backdropGradient} />
          </View>
        )}

        {/* Content */}
        <View style={styles.content}>
          {/* Poster + info */}
          <View style={styles.topRow}>
            {posterUrl && (
              <Image source={{ uri: posterUrl }} style={styles.poster} />
            )}
            <View style={styles.info}>
              <Text style={styles.title}>{item.Name}</Text>
              <View style={styles.metaRow}>
                {item.ProductionYear && <Text style={styles.meta}>{item.ProductionYear}</Text>}
                {item.OfficialRating && <View style={styles.ratingBadge}><Text style={styles.ratingText}>{item.OfficialRating}</Text></View>}
                {item.CommunityRating && <Text style={styles.meta}>⭐ {item.CommunityRating.toFixed(1)}</Text>}
                {item.RunTimeTicks && <Text style={styles.meta}>{EmbyAPI.formatRuntime(item.RunTimeTicks)}</Text>}
              </View>
              {item.Genres?.length ? (
                <View style={styles.genreRow}>
                  {item.Genres.slice(0, 4).map(g => (
                    <View key={g} style={styles.genre}><Text style={styles.genreText}>{g}</Text></View>
                  ))}
                </View>
              ) : null}
              {item.Overview ? (
                <Text style={styles.overview}>{item.Overview}</Text>
              ) : null}

              {/* Play buttons */}
              {!isSeries && (
                <View style={styles.buttons}>
                  <Pressable
                    style={styles.playBtn}
                    onPress={() => handleOpenStreamPicker(item)}
                    disabled={loading}
                  >
                    {loading
                      ? <ActivityIndicator color="#fff" />
                      : <Text style={styles.playBtnText}>▶  Play</Text>
                    }
                  </Pressable>
                  <Pressable style={styles.embyBtn} onPress={() => handlePlayEmby(item)}>
                    <Text style={styles.embyBtnText}>📀 Play from Emby</Text>
                  </Pressable>
                </View>
              )}
            </View>
          </View>

          {/* TV Series: Season + Episodes */}
          {isSeries && seasons.length > 0 && (
            <View style={styles.seasonSection}>
              <View style={styles.seasonPicker}>
                {seasons.map(s => (
                  <Pressable
                    key={s.Id}
                    style={[styles.seasonBtn, selectedSeason?.Id === s.Id && styles.seasonBtnActive]}
                    onPress={() => setSelectedSeason(s)}
                  >
                    <Text style={[styles.seasonBtnText, selectedSeason?.Id === s.Id && styles.seasonBtnTextActive]}>
                      {s.Name}
                    </Text>
                  </Pressable>
                ))}
              </View>

              <FlatList
                data={episodes}
                keyExtractor={ep => ep.Id}
                scrollEnabled={false}
                renderItem={({ item: ep }) => (
                  <Pressable style={styles.episodeRow} onPress={() => handleOpenStreamPicker(ep)}>
                    <View style={styles.epNumber}>
                      <Text style={styles.epNumberText}>{ep.IndexNumber || '?'}</Text>
                    </View>
                    <View style={styles.epInfo}>
                      <Text style={styles.epTitle}>{ep.Name}</Text>
                      {ep.Overview && <Text style={styles.epOverview} numberOfLines={2}>{ep.Overview}</Text>}
                    </View>
                    <Text style={styles.epPlay}>▶</Text>
                  </Pressable>
                )}
              />
            </View>
          )}
        </View>
      </ScrollView>

      {/* Stream picker modal */}
      <Modal visible={showStreamPicker} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modal}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Choose Stream</Text>
              <Pressable onPress={() => setShowStreamPicker(false)}>
                <Text style={styles.modalClose}>✕</Text>
              </Pressable>
            </View>

            {streamsLoading && streams.length === 0 ? (
              <View style={styles.streamLoading}>
                <ActivityIndicator size="large" color={Colors.accent} />
                <Text style={styles.streamLoadingText}>Fetching streams…</Text>
              </View>
            ) : (
              <FlatList
                data={streams}
                keyExtractor={(s, i) => `${s.url}_${i}`}
                renderItem={({ item: s }) => (
                  <Pressable
                    style={styles.streamRow}
                    onPress={() => {
                      setShowStreamPicker(false);
                      onPlay(s.url, playTarget?.Name || item.Name, playTarget || item);
                    }}
                  >
                    <View style={styles.streamLeft}>
                      {s.rdCached && <Text style={styles.rdBolt}>⚡</Text>}
                      <View>
                        <Text style={styles.streamName}>{s.name}</Text>
                        <Text style={styles.streamTitle} numberOfLines={2}>{s.title}</Text>
                      </View>
                    </View>
                    <View style={styles.streamRight}>
                      <Text style={[styles.streamQuality, { color: qualityColor(s.quality) }]}>{s.quality}</Text>
                      {s.size ? <Text style={styles.streamSize}>{s.size}</Text> : null}
                    </View>
                  </Pressable>
                )}
                ListFooterComponent={streamsLoading ? <ActivityIndicator color={Colors.accent} style={{ margin: Spacing.md }} /> : null}
              />
            )}
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  backBtn: { position: 'absolute', top: Spacing.lg, left: Spacing.lg, zIndex: 10, backgroundColor: 'rgba(0,0,0,0.6)', borderRadius: Radius.md, paddingHorizontal: Spacing.md, paddingVertical: Spacing.sm },
  backText: { color: Colors.textPrimary, fontSize: Typography.base, fontWeight: Typography.medium },
  backdropContainer: { height: 350, position: 'relative' },
  backdrop: { width: '100%', height: '100%', resizeMode: 'cover' },
  backdropGradient: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(10,10,15,0.5)' },
  content: { padding: Spacing.xl, marginTop: -80 },
  topRow: { flexDirection: 'row', gap: Spacing.xl },
  poster: { width: 160, height: 240, borderRadius: Radius.md, resizeMode: 'cover' },
  info: { flex: 1, paddingTop: Spacing.md },
  title: { color: Colors.textPrimary, fontSize: Typography.xxl, fontWeight: Typography.heavy, letterSpacing: -0.5, marginBottom: Spacing.sm },
  metaRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md, marginBottom: Spacing.sm },
  meta: { color: Colors.textSecondary, fontSize: Typography.sm },
  ratingBadge: { backgroundColor: Colors.bgElevated, borderRadius: Radius.sm, paddingHorizontal: Spacing.sm, paddingVertical: 2, borderWidth: 1, borderColor: Colors.border },
  ratingText: { color: Colors.textSecondary, fontSize: Typography.xs },
  genreRow: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.xs, marginBottom: Spacing.md },
  genre: { backgroundColor: Colors.bgElevated, borderRadius: Radius.full, paddingHorizontal: Spacing.md, paddingVertical: 3 },
  genreText: { color: Colors.textSecondary, fontSize: Typography.xs },
  overview: { color: Colors.textSecondary, fontSize: Typography.base, lineHeight: 24, marginBottom: Spacing.lg },
  buttons: { flexDirection: 'row', gap: Spacing.md },
  playBtn: { backgroundColor: Colors.accent, paddingHorizontal: Spacing.xl, paddingVertical: Spacing.md, borderRadius: Radius.md, minWidth: 120, alignItems: 'center' },
  playBtnText: { color: Colors.textPrimary, fontSize: Typography.md, fontWeight: Typography.bold },
  embyBtn: { backgroundColor: Colors.bgElevated, paddingHorizontal: Spacing.lg, paddingVertical: Spacing.md, borderRadius: Radius.md, borderWidth: 1, borderColor: Colors.border },
  embyBtnText: { color: Colors.textSecondary, fontSize: Typography.sm },
  seasonSection: { marginTop: Spacing.xl },
  seasonPicker: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.xs, marginBottom: Spacing.lg },
  seasonBtn: { paddingHorizontal: Spacing.md, paddingVertical: Spacing.sm, borderRadius: Radius.full, backgroundColor: Colors.bgElevated, borderWidth: 1, borderColor: Colors.border },
  seasonBtnActive: { backgroundColor: Colors.accent, borderColor: Colors.accent },
  seasonBtnText: { color: Colors.textSecondary, fontSize: Typography.sm },
  seasonBtnTextActive: { color: Colors.textPrimary, fontWeight: Typography.semibold },
  episodeRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md, paddingVertical: Spacing.md, borderBottomWidth: 1, borderBottomColor: Colors.border },
  epNumber: { width: 40, height: 40, borderRadius: Radius.sm, backgroundColor: Colors.bgElevated, justifyContent: 'center', alignItems: 'center' },
  epNumberText: { color: Colors.textSecondary, fontSize: Typography.sm, fontWeight: Typography.bold },
  epInfo: { flex: 1 },
  epTitle: { color: Colors.textPrimary, fontSize: Typography.base, fontWeight: Typography.medium },
  epOverview: { color: Colors.textMuted, fontSize: Typography.sm, marginTop: 2 },
  epPlay: { color: Colors.accent, fontSize: 20, paddingHorizontal: Spacing.md },
  modalOverlay: { flex: 1, backgroundColor: Colors.overlayHeavy, justifyContent: 'flex-end' },
  modal: { backgroundColor: Colors.bgCard, borderTopLeftRadius: Radius.xl, borderTopRightRadius: Radius.xl, maxHeight: '70%', minHeight: 300 },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: Spacing.xl, borderBottomWidth: 1, borderBottomColor: Colors.border },
  modalTitle: { color: Colors.textPrimary, fontSize: Typography.lg, fontWeight: Typography.semibold },
  modalClose: { color: Colors.textMuted, fontSize: Typography.xl, padding: Spacing.sm },
  streamLoading: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: Spacing.xxl, gap: Spacing.md },
  streamLoadingText: { color: Colors.textSecondary, fontSize: Typography.base },
  streamRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: Spacing.lg, borderBottomWidth: 1, borderBottomColor: Colors.border },
  streamLeft: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, flex: 1 },
  rdBolt: { fontSize: 18 },
  streamName: { color: Colors.textPrimary, fontSize: Typography.base, fontWeight: Typography.medium },
  streamTitle: { color: Colors.textMuted, fontSize: Typography.xs, marginTop: 2, maxWidth: 400 },
  streamRight: { alignItems: 'flex-end', gap: 2 },
  streamQuality: { fontSize: Typography.sm, fontWeight: Typography.bold },
  streamSize: { color: Colors.textMuted, fontSize: Typography.xs },
});
