import React, { useEffect, useState, useCallback } from 'react';
import { View, ScrollView, StyleSheet, Text, Image, ActivityIndicator, Pressable } from 'react-native';
import { Colors, Typography, Spacing } from '../theme';
import { MediaRow } from '../components/MediaRow';
import { EmbyAPI, EmbyItem } from '../services/emby';
import { Store } from '../store';

interface HomeScreenProps {
  onSelectItem: (item: EmbyItem) => void;
}

interface HomeData {
  continueWatching: EmbyItem[];
  nextUp: EmbyItem[];
  latestMovies: EmbyItem[];
  latestShows: EmbyItem[];
}

export function HomeScreen({ onSelectItem }: HomeScreenProps) {
  const [data, setData] = useState<HomeData | null>(null);
  const [loading, setLoading] = useState(true);
  const [hero, setHero] = useState<EmbyItem | null>(null);
  const [heroFocused, setHeroFocused] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [continueWatching, nextUp, latestMovies, latestShows] = await Promise.all([
        EmbyAPI.getContinueWatching(10),
        EmbyAPI.getNextUp(10),
        EmbyAPI.getLatestMovies(20),
        EmbyAPI.getLatestShows(20),
      ]);
      const d = { continueWatching, nextUp, latestMovies, latestShows };
      setData(d);

      // Pick hero from latest movies or continue watching
      const heroPool = [...latestMovies, ...continueWatching].filter(i => i.BackdropImageTags?.length);
      if (heroPool.length) setHero(heroPool[Math.floor(Math.random() * Math.min(5, heroPool.length))]);
    } catch (e) {
      console.error('Home load error', e);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  if (loading) {
    return (
      <View style={styles.loading}>
        <ActivityIndicator size="large" color={Colors.accent} />
        <Text style={styles.loadingText}>Loading your library…</Text>
      </View>
    );
  }

  const emby = Store.get().emby!;
  const heroImageUrl = hero && hero.BackdropImageTags?.[0]
    ? `${emby.serverUrl}/Items/${hero.Id}/Images/Backdrop?tag=${hero.BackdropImageTags[0]}&maxWidth=1920&quality=85`
    : null;

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      {/* Hero Banner */}
      {hero && heroImageUrl && (
        <Pressable
          onFocus={() => setHeroFocused(true)}
          onBlur={() => setHeroFocused(false)}
          onPress={() => onSelectItem(hero)}
          style={[styles.hero, heroFocused && styles.heroFocused]}
          hasTVPreferredFocus
        >
          <Image source={{ uri: heroImageUrl }} style={styles.heroImage} />
          <View style={styles.heroGradient} />
          <View style={styles.heroContent}>
            {hero.OfficialRating && (
              <View style={styles.heroBadge}>
                <Text style={styles.heroBadgeText}>{hero.OfficialRating}</Text>
              </View>
            )}
            <Text style={styles.heroTitle}>{hero.Name}</Text>
            <View style={styles.heroMeta}>
              {hero.ProductionYear && <Text style={styles.heroMetaText}>{hero.ProductionYear}</Text>}
              {hero.CommunityRating && <Text style={styles.heroMetaText}>⭐ {hero.CommunityRating.toFixed(1)}</Text>}
              {hero.RunTimeTicks && <Text style={styles.heroMetaText}>{EmbyAPI.formatRuntime(hero.RunTimeTicks)}</Text>}
            </View>
            {hero.Overview && (
              <Text style={styles.heroOverview} numberOfLines={2}>{hero.Overview}</Text>
            )}
            <View style={styles.heroButtons}>
              <View style={styles.heroPlayBtn}>
                <Text style={styles.heroPlayText}>▶  Play</Text>
              </View>
              <View style={styles.heroInfoBtn}>
                <Text style={styles.heroInfoText}>ℹ  More Info</Text>
              </View>
            </View>
          </View>
        </Pressable>
      )}

      {/* Content rows */}
      <View style={styles.rows}>
        {data?.continueWatching.length ? (
          <MediaRow
            title="Continue Watching"
            items={data.continueWatching}
            onPressItem={onSelectItem}
            cardWidth={200}
            cardHeight={115}
            showProgress
          />
        ) : null}

        {data?.nextUp.length ? (
          <MediaRow
            title="Next Up"
            items={data.nextUp}
            onPressItem={onSelectItem}
            cardWidth={200}
            cardHeight={115}
          />
        ) : null}

        {data?.latestMovies.length ? (
          <MediaRow
            title="Latest Movies"
            items={data.latestMovies}
            onPressItem={onSelectItem}
            cardWidth={150}
            cardHeight={225}
          />
        ) : null}

        {data?.latestShows.length ? (
          <MediaRow
            title="Latest TV Shows"
            items={data.latestShows}
            onPressItem={onSelectItem}
            cardWidth={150}
            cardHeight={225}
          />
        ) : null}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.bg,
  },
  loading: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: Spacing.md,
  },
  loadingText: {
    color: Colors.textSecondary,
    fontSize: Typography.base,
  },
  hero: {
    height: 400,
    marginBottom: Spacing.xl,
    borderWidth: 2,
    borderColor: 'transparent',
  },
  heroFocused: {
    borderColor: Colors.accent,
  },
  heroImage: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  heroGradient: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(10,10,15,0.55)',
  },
  heroContent: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    padding: Spacing.xl,
    paddingBottom: Spacing.xxl,
  },
  heroBadge: {
    backgroundColor: Colors.accent,
    borderRadius: 4,
    paddingHorizontal: Spacing.sm,
    paddingVertical: 2,
    alignSelf: 'flex-start',
    marginBottom: Spacing.sm,
  },
  heroBadgeText: {
    color: Colors.textPrimary,
    fontSize: Typography.xs,
    fontWeight: Typography.bold,
  },
  heroTitle: {
    color: Colors.textPrimary,
    fontSize: Typography.xxxl,
    fontWeight: Typography.heavy,
    letterSpacing: -1,
    textShadowColor: 'rgba(0,0,0,0.8)',
    textShadowOffset: { width: 0, height: 2 },
    textShadowRadius: 8,
  },
  heroMeta: {
    flexDirection: 'row',
    gap: Spacing.md,
    marginTop: Spacing.xs,
    marginBottom: Spacing.sm,
  },
  heroMetaText: {
    color: Colors.textSecondary,
    fontSize: Typography.sm,
  },
  heroOverview: {
    color: Colors.textSecondary,
    fontSize: Typography.base,
    lineHeight: 22,
    maxWidth: 500,
    marginBottom: Spacing.md,
  },
  heroButtons: {
    flexDirection: 'row',
    gap: Spacing.md,
  },
  heroPlayBtn: {
    backgroundColor: Colors.accent,
    paddingHorizontal: Spacing.xl,
    paddingVertical: Spacing.md,
    borderRadius: 6,
  },
  heroPlayText: {
    color: Colors.textPrimary,
    fontSize: Typography.md,
    fontWeight: Typography.bold,
  },
  heroInfoBtn: {
    backgroundColor: 'rgba(255,255,255,0.15)',
    paddingHorizontal: Spacing.xl,
    paddingVertical: Spacing.md,
    borderRadius: 6,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
  },
  heroInfoText: {
    color: Colors.textPrimary,
    fontSize: Typography.md,
    fontWeight: Typography.medium,
  },
  rows: {
    paddingBottom: Spacing.xxl,
  },
});
