import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, StyleSheet, FlatList, Pressable, ActivityIndicator } from 'react-native';
import { Colors, Typography, Spacing, Radius } from '../theme';
import { MediaCard } from '../components/MediaCard';
import { EmbyAPI, EmbyItem } from '../services/emby';

const GENRES = ['Action', 'Adventure', 'Animation', 'Comedy', 'Crime', 'Documentary', 'Drama', 'Family', 'Fantasy', 'Horror', 'Mystery', 'Romance', 'Sci-Fi', 'Thriller'];
const SORT_OPTIONS = [
  { label: 'A-Z', value: 'SortName' },
  { label: 'Rating', value: 'CommunityRating' },
  { label: 'Year', value: 'ProductionYear' },
  { label: 'Date Added', value: 'DateCreated' },
];

interface DiscoverScreenProps {
  onSelectItem: (item: EmbyItem) => void;
}

export function DiscoverScreen({ onSelectItem }: DiscoverScreenProps) {
  const [contentType, setContentType] = useState<'movies' | 'shows'>('movies');
  const [genre, setGenre] = useState('');
  const [sortBy, setSortBy] = useState('SortName');
  const [items, setItems] = useState<EmbyItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(0);
  const PAGE_SIZE = 40;

  const load = useCallback(async (startIndex = 0, append = false) => {
    if (startIndex === 0) setLoading(true);
    else setLoadingMore(true);

    try {
      const params = { limit: PAGE_SIZE, sortBy, genres: genre || undefined, startIndex };
      const result = contentType === 'movies'
        ? await EmbyAPI.getMovies(params)
        : await EmbyAPI.getSeries(params as any);

      setItems(prev => append ? [...prev, ...result.items] : result.items);
      setTotal(result.total);
    } catch (e) {
      console.error('Discover load error', e);
    } finally {
      setLoading(false);
      setLoadingMore(false);
    }
  }, [contentType, genre, sortBy]);

  useEffect(() => {
    setPage(0);
    load(0, false);
  }, [load]);

  const loadMore = () => {
    if (loadingMore || items.length >= total) return;
    const next = page + 1;
    setPage(next);
    load(next * PAGE_SIZE, true);
  };

  const numColumns = 5;

  return (
    <View style={styles.container}>
      {/* Filter bar */}
      <View style={styles.filterBar}>
        {/* Type toggle */}
        <View style={styles.typeToggle}>
          <Pressable
            style={[styles.typeBtn, contentType === 'movies' && styles.typeBtnActive]}
            onPress={() => setContentType('movies')}
          >
            <Text style={[styles.typeBtnText, contentType === 'movies' && styles.typeBtnTextActive]}>Movies</Text>
          </Pressable>
          <Pressable
            style={[styles.typeBtn, contentType === 'shows' && styles.typeBtnActive]}
            onPress={() => setContentType('shows')}
          >
            <Text style={[styles.typeBtnText, contentType === 'shows' && styles.typeBtnTextActive]}>TV Shows</Text>
          </Pressable>
        </View>

        {/* Sort */}
        <View style={styles.filterGroup}>
          {SORT_OPTIONS.map(opt => (
            <Pressable
              key={opt.value}
              style={[styles.chip, sortBy === opt.value && styles.chipActive]}
              onPress={() => setSortBy(opt.value)}
            >
              <Text style={[styles.chipText, sortBy === opt.value && styles.chipTextActive]}>{opt.label}</Text>
            </Pressable>
          ))}
        </View>

        {/* Genre filter */}
        <View style={styles.filterGroup}>
          <Pressable
            style={[styles.chip, genre === '' && styles.chipActive]}
            onPress={() => setGenre('')}
          >
            <Text style={[styles.chipText, genre === '' && styles.chipTextActive]}>All</Text>
          </Pressable>
          {GENRES.map(g => (
            <Pressable
              key={g}
              style={[styles.chip, genre === g && styles.chipActive]}
              onPress={() => setGenre(g)}
            >
              <Text style={[styles.chipText, genre === g && styles.chipTextActive]}>{g}</Text>
            </Pressable>
          ))}
        </View>
      </View>

      {/* Results */}
      {loading ? (
        <View style={styles.loading}>
          <ActivityIndicator size="large" color={Colors.accent} />
        </View>
      ) : (
        <FlatList
          data={items}
          keyExtractor={item => item.Id}
          numColumns={numColumns}
          contentContainerStyle={styles.grid}
          columnWrapperStyle={styles.row}
          onEndReached={loadMore}
          onEndReachedThreshold={0.3}
          ListFooterComponent={loadingMore ? <ActivityIndicator color={Colors.accent} style={{ margin: Spacing.xl }} /> : null}
          ListHeaderComponent={
            <Text style={styles.resultCount}>{total} {contentType === 'movies' ? 'movies' : 'shows'}</Text>
          }
          renderItem={({ item }) => (
            <MediaCard
              item={item}
              onPress={onSelectItem}
              width={140}
              height={210}
              style={{ marginBottom: Spacing.md }}
            />
          )}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.bg,
  },
  filterBar: {
    backgroundColor: Colors.bgCard,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
    padding: Spacing.md,
    gap: Spacing.sm,
  },
  typeToggle: {
    flexDirection: 'row',
    gap: Spacing.xs,
  },
  typeBtn: {
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.sm,
    borderRadius: Radius.full,
    backgroundColor: Colors.bgElevated,
  },
  typeBtnActive: {
    backgroundColor: Colors.accent,
  },
  typeBtnText: {
    color: Colors.textSecondary,
    fontSize: Typography.sm,
    fontWeight: Typography.medium,
  },
  typeBtnTextActive: {
    color: Colors.textPrimary,
    fontWeight: Typography.semibold,
  },
  filterGroup: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.xs,
  },
  chip: {
    paddingHorizontal: Spacing.md,
    paddingVertical: 5,
    borderRadius: Radius.full,
    backgroundColor: Colors.bgElevated,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  chipActive: {
    backgroundColor: Colors.accentGlow,
    borderColor: Colors.accent,
  },
  chipText: {
    color: Colors.textSecondary,
    fontSize: Typography.xs,
  },
  chipTextActive: {
    color: Colors.accentBright,
    fontWeight: Typography.semibold,
  },
  loading: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  grid: {
    padding: Spacing.lg,
    gap: Spacing.md,
  },
  row: {
    gap: Spacing.md,
    justifyContent: 'flex-start',
  },
  resultCount: {
    color: Colors.textMuted,
    fontSize: Typography.sm,
    marginBottom: Spacing.md,
  },
});
