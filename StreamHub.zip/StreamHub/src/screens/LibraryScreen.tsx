import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, Pressable, ActivityIndicator } from 'react-native';
import { Colors, Typography, Spacing, Radius } from '../theme';
import { MediaCard } from '../components/MediaCard';
import { EmbyAPI, EmbyItem } from '../services/emby';

interface LibraryScreenProps {
  onSelectItem: (item: EmbyItem) => void;
}

export function LibraryScreen({ onSelectItem }: LibraryScreenProps) {
  const [tab, setTab] = useState<'movies' | 'shows'>('movies');
  const [items, setItems] = useState<EmbyItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      try {
        const result = tab === 'movies'
          ? await EmbyAPI.getMovies({ sortBy: 'DateCreated', limit: 200 })
          : await EmbyAPI.getSeries({ sortBy: 'DateCreated', limit: 200 });
        setItems(result.items);
      } catch {}
      setLoading(false);
    };
    load();
  }, [tab]);

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.heading}>Library</Text>
        <View style={styles.tabs}>
          <Pressable style={[styles.tab, tab === 'movies' && styles.tabActive]} onPress={() => setTab('movies')}>
            <Text style={[styles.tabText, tab === 'movies' && styles.tabTextActive]}>Movies</Text>
          </Pressable>
          <Pressable style={[styles.tab, tab === 'shows' && styles.tabActive]} onPress={() => setTab('shows')}>
            <Text style={[styles.tabText, tab === 'shows' && styles.tabTextActive]}>TV Shows</Text>
          </Pressable>
        </View>
      </View>

      {loading ? (
        <View style={styles.loading}><ActivityIndicator size="large" color={Colors.accent} /></View>
      ) : (
        <FlatList
          data={items}
          keyExtractor={i => i.Id}
          numColumns={5}
          contentContainerStyle={styles.grid}
          columnWrapperStyle={styles.row}
          renderItem={({ item }) => (
            <MediaCard item={item} onPress={onSelectItem} width={140} height={210} style={{ marginBottom: Spacing.md }} />
          )}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  header: { padding: Spacing.xl, paddingBottom: Spacing.md, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  heading: { color: Colors.textPrimary, fontSize: Typography.xxl, fontWeight: Typography.bold },
  tabs: { flexDirection: 'row', gap: Spacing.xs },
  tab: { paddingHorizontal: Spacing.lg, paddingVertical: Spacing.sm, borderRadius: Radius.full, backgroundColor: Colors.bgElevated },
  tabActive: { backgroundColor: Colors.accent },
  tabText: { color: Colors.textSecondary, fontSize: Typography.sm, fontWeight: Typography.medium },
  tabTextActive: { color: Colors.textPrimary, fontWeight: Typography.semibold },
  loading: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  grid: { padding: Spacing.lg },
  row: { gap: Spacing.md, justifyContent: 'flex-start', marginBottom: Spacing.sm },
});
