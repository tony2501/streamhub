import React, { useState } from 'react';
import { View, Text, StyleSheet, Pressable, Switch, Alert } from 'react-native';
import { Colors, Typography, Spacing, Radius } from '../theme';
import { Store } from '../store';
import { resetClient } from '../services/emby';

interface SettingsScreenProps {
  onLogout: () => void;
}

export function SettingsScreen({ onLogout }: SettingsScreenProps) {
  const store = Store.get();
  const [settings, setSettings] = useState(store.settings);

  const updateQuality = (q: typeof settings.preferredQuality) => {
    const updated = { ...settings, preferredQuality: q };
    setSettings(updated);
    Store.updateSettings({ preferredQuality: q });
  };

  const handleLogout = () => {
    Alert.alert('Sign Out', 'Disconnect from Emby and Real-Debrid?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Sign Out', style: 'destructive', onPress: () => {
          resetClient();
          Store.logout();
          onLogout();
        }
      },
    ]);
  };

  const QUALITY_OPTIONS = ['Auto', '4K', '1080p', '720p'] as const;

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>Settings</Text>

      {/* Emby connection */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Emby</Text>
        <View style={styles.row}>
          <Text style={styles.rowLabel}>Server</Text>
          <Text style={styles.rowValue} numberOfLines={1}>{store.emby?.serverUrl || '—'}</Text>
        </View>
        <View style={styles.row}>
          <Text style={styles.rowLabel}>User</Text>
          <Text style={styles.rowValue}>{store.emby?.username || '—'}</Text>
        </View>
      </View>

      {/* Real-Debrid */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Real-Debrid</Text>
        <View style={styles.row}>
          <Text style={styles.rowLabel}>Status</Text>
          <View style={[styles.statusBadge, { backgroundColor: store.realDebrid?.connected ? 'rgba(16,185,129,0.15)' : 'rgba(239,68,68,0.15)' }]}>
            <Text style={{ color: store.realDebrid?.connected ? Colors.success : Colors.error, fontSize: Typography.sm }}>
              {store.realDebrid?.connected ? '✓ Connected' : '✗ Not connected'}
            </Text>
          </View>
        </View>
      </View>

      {/* Playback quality */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Preferred Quality</Text>
        <View style={styles.qualityOptions}>
          {QUALITY_OPTIONS.map(q => (
            <Pressable
              key={q}
              style={[styles.qualityBtn, settings.preferredQuality === q && styles.qualityBtnActive]}
              onPress={() => updateQuality(q)}
            >
              <Text style={[styles.qualityBtnText, settings.preferredQuality === q && styles.qualityBtnTextActive]}>{q}</Text>
            </Pressable>
          ))}
        </View>
      </View>

      {/* About */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>About</Text>
        <View style={styles.row}>
          <Text style={styles.rowLabel}>StreamHub</Text>
          <Text style={styles.rowValue}>v1.0.0</Text>
        </View>
      </View>

      {/* Logout */}
      <Pressable style={styles.logoutBtn} onPress={handleLogout}>
        <Text style={styles.logoutText}>Sign Out</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg, padding: Spacing.xl },
  heading: { color: Colors.textPrimary, fontSize: Typography.xxl, fontWeight: Typography.bold, marginBottom: Spacing.xl },
  section: { marginBottom: Spacing.xl, backgroundColor: Colors.bgCard, borderRadius: Radius.lg, overflow: 'hidden', borderWidth: 1, borderColor: Colors.border },
  sectionTitle: { color: Colors.textMuted, fontSize: Typography.xs, fontWeight: Typography.semibold, letterSpacing: 1, textTransform: 'uppercase', padding: Spacing.md, paddingBottom: 0 },
  row: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: Spacing.md, borderTopWidth: 1, borderTopColor: Colors.border },
  rowLabel: { color: Colors.textSecondary, fontSize: Typography.base },
  rowValue: { color: Colors.textPrimary, fontSize: Typography.base, maxWidth: '60%', textAlign: 'right' },
  statusBadge: { paddingHorizontal: Spacing.md, paddingVertical: 4, borderRadius: Radius.full },
  qualityOptions: { flexDirection: 'row', gap: Spacing.xs, padding: Spacing.md, paddingTop: Spacing.sm },
  qualityBtn: { paddingHorizontal: Spacing.md, paddingVertical: Spacing.sm, borderRadius: Radius.full, backgroundColor: Colors.bgElevated, borderWidth: 1, borderColor: Colors.border },
  qualityBtnActive: { backgroundColor: Colors.accent, borderColor: Colors.accent },
  qualityBtnText: { color: Colors.textSecondary, fontSize: Typography.sm },
  qualityBtnTextActive: { color: Colors.textPrimary, fontWeight: Typography.semibold },
  logoutBtn: { backgroundColor: 'rgba(239,68,68,0.15)', borderRadius: Radius.md, padding: Spacing.md, alignItems: 'center', borderWidth: 1, borderColor: Colors.error, marginTop: Spacing.xl },
  logoutText: { color: Colors.error, fontSize: Typography.base, fontWeight: Typography.semibold },
});
