import React, { useState, useEffect, useRef } from 'react';
import { View, Text, TextInput, StyleSheet, FlatList, ActivityIndicator } from 'react-native';
import { Colors, Typography, Spacing, Radius } from '../theme';
import { MediaCard } from '../components/MediaCard';
import { EmbyAPI, EmbyItem } from '../services/emby';

interface SearchScreenProps {
  onSelectItem: (item: EmbyItem) => void;
}

export function SearchScreen({ onSelectItem }: SearchScreenProps) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<EmbyItem[]>([]);
  const [loading, setLoading] = useState(false);
  const timerRef = useRef<any>(null);

  useEffect(() => {
    clearTimeout(timerRef.current);
    if (!query.trim()) { setResults([]); return; }
    timerRef.current = setTimeout(async () => {
      setLoading(true);
      try {
        const r = await EmbyAPI.search(query);
        setResults(r);
      } catch {}
      setLoading(false);
    }, 400);
    return () => clearTimeout(timerRef.current);
  }, [query]);

  return (
    <View style={styles.container}>
      <View style={styles.searchBar}>
        <Text style={styles.searchIcon}>⌕</Text>
        <TextInput
          style={styles.input}
          value={query}
          onChangeText={setQuery}
          placeholder="Search movies and shows…"
          placeholderTextColor={Colors.textMuted}
          autoFocus
          returnKeyType="search"
        />
        {loading && <ActivityIndicator size="small" color={Colors.accent} style={{ marginRight: Spacing.md }} />}
      </View>

      {results.length > 0 ? (
        <FlatList
          data={results}
          keyExtractor={i => i.Id}
          numColumns={5}
          contentContainerStyle={styles.grid}
          columnWrapperStyle={styles.row}
          renderItem={({ item }) => (
            <MediaCard item={item} onPress={onSelectItem} width={140} height={210} style={{ marginBottom: Spacing.md }} />
          )}
        />
      ) : query ? (
        <View style={styles.empty}>
          <Text style={styles.emptyText}>{loading ? '' : 'No results found'}</Text>
        </View>
      ) : (
        <View style={styles.empty}>
          <Text style={styles.hint}>Search your Emby library</Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    margin: Spacing.xl,
    backgroundColor: Colors.bgCard,
    borderRadius: Radius.xl,
    borderWidth: 1,
    borderColor: Colors.border,
    paddingHorizontal: Spacing.md,
  },
  searchIcon: { color: Colors.textMuted, fontSize: 22, marginRight: Spacing.sm },
  input: {
    flex: 1,
    color: Colors.textPrimary,
    fontSize: Typography.lg,
    paddingVertical: Spacing.md,
  },
  grid: { padding: Spacing.lg },
  row: { gap: Spacing.md, justifyContent: 'flex-start', marginBottom: Spacing.sm },
  empty: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  emptyText: { color: Colors.textSecondary, fontSize: Typography.lg },
  hint: { color: Colors.textMuted, fontSize: Typography.base },
});
