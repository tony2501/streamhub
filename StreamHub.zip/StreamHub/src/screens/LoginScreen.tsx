import React, { useState } from 'react';
import {
  View, Text, TextInput, StyleSheet, ScrollView,
  ActivityIndicator, Pressable, KeyboardAvoidingView, Platform
} from 'react-native';
import { Colors, Typography, Spacing, Radius } from '../theme';
import { EmbyAPI } from '../services/emby';
import { RealDebridAPI } from '../services/realdebrid';
import { Store } from '../store';

interface LoginScreenProps {
  onLoginComplete: () => void;
}

export function LoginScreen({ onLoginComplete }: LoginScreenProps) {
  const [step, setStep] = useState<'emby' | 'rd'>('emby');

  // Emby fields
  const [serverUrl, setServerUrl] = useState('http://');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [embyError, setEmbyError] = useState('');
  const [embyLoading, setEmbyLoading] = useState(false);

  // RD fields
  const [rdKey, setRdKey] = useState('');
  const [rdError, setRdError] = useState('');
  const [rdLoading, setRdLoading] = useState(false);

  const handleEmbyLogin = async () => {
    if (!serverUrl || !username) { setEmbyError('Server URL and username required'); return; }
    setEmbyLoading(true);
    setEmbyError('');
    try {
      const url = serverUrl.endsWith('/') ? serverUrl.slice(0, -1) : serverUrl;
      const { userId, accessToken, deviceId } = await EmbyAPI.authenticate(url, username, password);
      await Store.setEmby({ serverUrl: url, username, userId, accessToken, deviceId });
      setStep('rd');
    } catch (e: any) {
      setEmbyError(e?.response?.data?.message || 'Could not connect. Check server URL and credentials.');
    } finally {
      setEmbyLoading(false);
    }
  };

  const handleRDConnect = async () => {
    if (!rdKey.trim()) { setRdError('API key required'); return; }
    setRdLoading(true);
    setRdError('');
    try {
      const { valid, username: rdUser } = await RealDebridAPI.validateKey(rdKey.trim());
      if (!valid) { setRdError('Invalid API key'); setRdLoading(false); return; }
      await Store.setRealDebrid({ apiKey: rdKey.trim(), connected: true });
      onLoginComplete();
    } catch {
      setRdError('Could not validate key');
    } finally {
      setRdLoading(false);
    }
  };

  const handleSkipRD = async () => {
    await Store.setRealDebrid({ apiKey: '', connected: false });
    onLoginComplete();
  };

  return (
    <View style={styles.container}>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={styles.inner}>
        {/* Logo */}
        <View style={styles.logoArea}>
          <Text style={styles.logoIcon}>▶</Text>
          <Text style={styles.logoTitle}>StreamHub</Text>
          <Text style={styles.logoSubtitle}>Your personal media centre</Text>
        </View>

        {step === 'emby' ? (
          <View style={styles.card}>
            <Text style={styles.cardTitle}>Connect to Emby</Text>
            <Text style={styles.cardSubtitle}>Enter your Emby Media Server details</Text>

            <View style={styles.fieldGroup}>
              <Text style={styles.label}>Server URL</Text>
              <TextInput
                style={styles.input}
                value={serverUrl}
                onChangeText={setServerUrl}
                placeholder="http://192.168.1.100:8096"
                placeholderTextColor={Colors.textMuted}
                autoCapitalize="none"
                autoCorrect={false}
                keyboardType="url"
              />
            </View>

            <View style={styles.fieldGroup}>
              <Text style={styles.label}>Username</Text>
              <TextInput
                style={styles.input}
                value={username}
                onChangeText={setUsername}
                placeholder="admin"
                placeholderTextColor={Colors.textMuted}
                autoCapitalize="none"
              />
            </View>

            <View style={styles.fieldGroup}>
              <Text style={styles.label}>Password</Text>
              <TextInput
                style={styles.input}
                value={password}
                onChangeText={setPassword}
                placeholder="••••••••"
                placeholderTextColor={Colors.textMuted}
                secureTextEntry
              />
            </View>

            {embyError ? <Text style={styles.errorText}>{embyError}</Text> : null}

            <Pressable style={styles.button} onPress={handleEmbyLogin} disabled={embyLoading}>
              {embyLoading
                ? <ActivityIndicator color={Colors.textPrimary} />
                : <Text style={styles.buttonText}>Connect to Emby</Text>
              }
            </Pressable>
          </View>
        ) : (
          <View style={styles.card}>
            <View style={styles.successBadge}>
              <Text style={styles.successText}>✓ Emby Connected</Text>
            </View>

            <Text style={styles.cardTitle}>Real-Debrid</Text>
            <Text style={styles.cardSubtitle}>Add your Real-Debrid API key for cached torrent streams</Text>

            <View style={styles.fieldGroup}>
              <Text style={styles.label}>API Key</Text>
              <TextInput
                style={styles.input}
                value={rdKey}
                onChangeText={setRdKey}
                placeholder="Your Real-Debrid API key"
                placeholderTextColor={Colors.textMuted}
                autoCapitalize="none"
                autoCorrect={false}
              />
              <Text style={styles.hint}>Find it at: real-debrid.com/apitoken</Text>
            </View>

            {rdError ? <Text style={styles.errorText}>{rdError}</Text> : null}

            <Pressable style={styles.button} onPress={handleRDConnect} disabled={rdLoading}>
              {rdLoading
                ? <ActivityIndicator color={Colors.textPrimary} />
                : <Text style={styles.buttonText}>Connect Real-Debrid</Text>
              }
            </Pressable>

            <Pressable style={styles.skipButton} onPress={handleSkipRD}>
              <Text style={styles.skipText}>Skip — use Emby only</Text>
            </Pressable>
          </View>
        )}
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.bg,
  },
  inner: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: Spacing.xxl,
  },
  logoArea: {
    alignItems: 'center',
    marginBottom: Spacing.xxl,
  },
  logoIcon: {
    fontSize: 56,
    color: Colors.accent,
    marginBottom: Spacing.sm,
  },
  logoTitle: {
    color: Colors.textPrimary,
    fontSize: Typography.xxxl,
    fontWeight: Typography.heavy,
    letterSpacing: -1,
  },
  logoSubtitle: {
    color: Colors.textSecondary,
    fontSize: Typography.base,
    marginTop: Spacing.xs,
  },
  card: {
    width: '100%',
    maxWidth: 480,
    backgroundColor: Colors.bgCard,
    borderRadius: Radius.xl,
    padding: Spacing.xl,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  cardTitle: {
    color: Colors.textPrimary,
    fontSize: Typography.xl,
    fontWeight: Typography.bold,
    marginBottom: Spacing.xs,
  },
  cardSubtitle: {
    color: Colors.textSecondary,
    fontSize: Typography.base,
    marginBottom: Spacing.xl,
    lineHeight: 22,
  },
  successBadge: {
    backgroundColor: 'rgba(16, 185, 129, 0.15)',
    borderRadius: Radius.full,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.xs,
    alignSelf: 'flex-start',
    marginBottom: Spacing.lg,
    borderWidth: 1,
    borderColor: Colors.success,
  },
  successText: {
    color: Colors.success,
    fontSize: Typography.sm,
    fontWeight: Typography.semibold,
  },
  fieldGroup: {
    marginBottom: Spacing.md,
  },
  label: {
    color: Colors.textSecondary,
    fontSize: Typography.sm,
    fontWeight: Typography.medium,
    marginBottom: Spacing.xs,
  },
  input: {
    backgroundColor: Colors.bgElevated,
    borderRadius: Radius.md,
    borderWidth: 1,
    borderColor: Colors.border,
    padding: Spacing.md,
    color: Colors.textPrimary,
    fontSize: Typography.base,
  },
  hint: {
    color: Colors.textMuted,
    fontSize: Typography.xs,
    marginTop: 4,
  },
  errorText: {
    color: Colors.error,
    fontSize: Typography.sm,
    marginBottom: Spacing.md,
  },
  button: {
    backgroundColor: Colors.accent,
    borderRadius: Radius.md,
    padding: Spacing.md,
    alignItems: 'center',
    marginTop: Spacing.sm,
  },
  buttonText: {
    color: Colors.textPrimary,
    fontSize: Typography.md,
    fontWeight: Typography.semibold,
  },
  skipButton: {
    alignItems: 'center',
    padding: Spacing.md,
    marginTop: Spacing.sm,
  },
  skipText: {
    color: Colors.textMuted,
    fontSize: Typography.base,
  },
});
