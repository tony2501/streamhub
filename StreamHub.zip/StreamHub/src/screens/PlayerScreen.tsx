import React, { useEffect, useRef, useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, Pressable, ActivityIndicator,
  Animated, BackHandler
} from 'react-native';
import { Video, ResizeMode, AVPlaybackStatus } from 'expo-av';
import { Colors, Typography, Spacing } from '../theme';
import { EmbyAPI, EmbyItem } from '../services/emby';

interface PlayerScreenProps {
  url: string;
  title: string;
  item: EmbyItem;
  onBack: () => void;
}

export function PlayerScreen({ url, title, item, onBack }: PlayerScreenProps) {
  const videoRef = useRef<Video>(null);
  const [status, setStatus] = useState<AVPlaybackStatus | null>(null);
  const [showControls, setShowControls] = useState(true);
  const controlsTimer = useRef<any>(null);
  const controlsOpacity = useRef(new Animated.Value(1)).current;
  const progressInterval = useRef<any>(null);

  const isPlaying = status?.isLoaded && status.isPlaying;
  const duration = status?.isLoaded ? status.durationMillis || 0 : 0;
  const position = status?.isLoaded ? status.positionMillis || 0 : 0;
  const buffering = status?.isLoaded ? status.isBuffering : true;
  const progress = duration > 0 ? position / duration : 0;

  const formatTime = (ms: number) => {
    const s = Math.floor(ms / 1000);
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = s % 60;
    return h > 0
      ? `${h}:${String(m).padStart(2,'0')}:${String(sec).padStart(2,'0')}`
      : `${m}:${String(sec).padStart(2,'0')}`;
  };

  const showControlsTemp = useCallback(() => {
    setShowControls(true);
    Animated.timing(controlsOpacity, { toValue: 1, duration: 150, useNativeDriver: true }).start();
    clearTimeout(controlsTimer.current);
    controlsTimer.current = setTimeout(() => {
      Animated.timing(controlsOpacity, { toValue: 0, duration: 500, useNativeDriver: true }).start(() => setShowControls(false));
    }, 4000);
  }, [controlsOpacity]);

  useEffect(() => {
    showControlsTemp();
    const backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
      onBack();
      return true;
    });
    return () => {
      backHandler.remove();
      clearTimeout(controlsTimer.current);
      clearInterval(progressInterval.current);
    };
  }, []);

  // Report progress to Emby every 10s
  useEffect(() => {
    progressInterval.current = setInterval(() => {
      if (status?.isLoaded && status.positionMillis) {
        EmbyAPI.reportProgress(item.Id, status.positionMillis * 10000);
      }
    }, 10000);
    return () => clearInterval(progressInterval.current);
  }, [status, item.Id]);

  const togglePlay = () => {
    if (!videoRef.current) return;
    if (isPlaying) videoRef.current.pauseAsync();
    else videoRef.current.playAsync();
    showControlsTemp();
  };

  const seek = (ms: number) => {
    if (!videoRef.current || !status?.isLoaded) return;
    const newPos = Math.max(0, Math.min(duration, position + ms));
    videoRef.current.setPositionAsync(newPos);
    showControlsTemp();
  };

  return (
    <View style={styles.container}>
      <Pressable style={styles.videoArea} onPress={showControlsTemp}>
        <Video
          ref={videoRef}
          source={{ uri: url }}
          style={styles.video}
          resizeMode={ResizeMode.CONTAIN}
          shouldPlay
          onPlaybackStatusUpdate={setStatus}
          onError={(e) => console.error('Video error', e)}
        />

        {/* Buffering */}
        {buffering && (
          <View style={styles.bufferingOverlay}>
            <ActivityIndicator size="large" color={Colors.accent} />
            <Text style={styles.bufferingText}>Buffering…</Text>
          </View>
        )}

        {/* Controls overlay */}
        {showControls && (
          <Animated.View style={[styles.controls, { opacity: controlsOpacity }]}>
            {/* Title bar */}
            <View style={styles.titleBar}>
              <Pressable style={styles.backBtn} onPress={onBack} hasTVPreferredFocus>
                <Text style={styles.backText}>← Back</Text>
              </Pressable>
              <Text style={styles.titleText} numberOfLines={1}>{title}</Text>
            </View>

            {/* Centre controls */}
            <View style={styles.centreControls}>
              <Pressable style={styles.seekBtn} onPress={() => seek(-10000)}>
                <Text style={styles.seekText}>⟪ 10s</Text>
              </Pressable>
              <Pressable style={styles.playPauseBtn} onPress={togglePlay}>
                <Text style={styles.playPauseIcon}>{isPlaying ? '⏸' : '▶'}</Text>
              </Pressable>
              <Pressable style={styles.seekBtn} onPress={() => seek(10000)}>
                <Text style={styles.seekText}>30s ⟫</Text>
              </Pressable>
            </View>

            {/* Progress bar */}
            <View style={styles.progressArea}>
              <Text style={styles.timeText}>{formatTime(position)}</Text>
              <View style={styles.progressTrack}>
                <View style={[styles.progressFill, { width: `${progress * 100}%` as any }]} />
                <View style={[styles.progressThumb, { left: `${progress * 100}%` as any }]} />
              </View>
              <Text style={styles.timeText}>{formatTime(duration)}</Text>
            </View>
          </Animated.View>
        )}
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000' },
  videoArea: { flex: 1 },
  video: { flex: 1 },
  bufferingOverlay: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'center',
    alignItems: 'center',
    gap: Spacing.md,
    backgroundColor: 'rgba(0,0,0,0.4)',
  },
  bufferingText: { color: Colors.textSecondary, fontSize: Typography.base },
  controls: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'space-between',
  },
  titleBar: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: Spacing.xl,
    paddingTop: Spacing.xxl,
    gap: Spacing.md,
  },
  backBtn: {
    backgroundColor: 'rgba(255,255,255,0.15)',
    borderRadius: 8,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
  },
  backText: { color: Colors.textPrimary, fontSize: Typography.base },
  titleText: {
    color: Colors.textPrimary,
    fontSize: Typography.lg,
    fontWeight: Typography.semibold,
    flex: 1,
  },
  centreControls: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: Spacing.xxl,
  },
  seekBtn: {
    backgroundColor: 'rgba(255,255,255,0.15)',
    borderRadius: Spacing.lg,
    paddingHorizontal: Spacing.xl,
    paddingVertical: Spacing.md,
  },
  seekText: { color: Colors.textPrimary, fontSize: Typography.md },
  playPauseBtn: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: Colors.accent,
    justifyContent: 'center',
    alignItems: 'center',
  },
  playPauseIcon: { color: Colors.textPrimary, fontSize: 28 },
  progressArea: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: Spacing.xl,
    paddingBottom: Spacing.xxl,
    gap: Spacing.md,
  },
  timeText: { color: Colors.textSecondary, fontSize: Typography.sm, width: 55, textAlign: 'center' },
  progressTrack: {
    flex: 1,
    height: 4,
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: 2,
    position: 'relative',
  },
  progressFill: {
    height: '100%',
    backgroundColor: Colors.accent,
    borderRadius: 2,
  },
  progressThumb: {
    position: 'absolute',
    top: -6,
    width: 16,
    height: 16,
    borderRadius: 8,
    backgroundColor: Colors.textPrimary,
    marginLeft: -8,
  },
});
