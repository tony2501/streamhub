import axios, { AxiosInstance } from 'axios';
import { Store } from '../store';

export interface EmbyItem {
  Id: string;
  Name: string;
  Type: 'Movie' | 'Series' | 'Episode' | 'Season';
  ImageTags?: { Primary?: string; Backdrop?: string; Thumb?: string };
  BackdropImageTags?: string[];
  Overview?: string;
  ProductionYear?: number;
  CommunityRating?: number;
  OfficialRating?: string;
  Genres?: string[];
  RunTimeTicks?: number;
  UserData?: {
    PlaybackPositionTicks?: number;
    PlayedPercentage?: number;
    Played?: boolean;
    IsFavorite?: boolean;
  };
  SeriesName?: string;
  SeasonName?: string;
  IndexNumber?: number;
  ParentIndexNumber?: number;
}

export interface PlaybackInfo {
  MediaSources: Array<{
    Id: string;
    Name: string;
    Path: string;
    DirectStreamUrl?: string;
    SupportsDirectStream: boolean;
    SupportsDirectPlay: boolean;
    Bitrate?: number;
    MediaStreams?: Array<{
      Type: 'Video' | 'Audio' | 'Subtitle';
      DisplayTitle?: string;
      Codec?: string;
      Language?: string;
      Index: number;
    }>;
  }>;
}

let client: AxiosInstance | null = null;

function getClient(): AxiosInstance {
  const emby = Store.get().emby;
  if (!emby) throw new Error('Emby not configured');

  if (!client) {
    client = axios.create({
      baseURL: emby.serverUrl,
      headers: {
        'X-Emby-Authorization': `MediaBrowser Client="StreamHub", Device="FireTV", DeviceId="${emby.deviceId}", Version="1.0.0", Token="${emby.accessToken}"`,
        'Content-Type': 'application/json',
      },
      timeout: 10000,
    });
  }
  return client;
}

export function resetClient() {
  client = null;
}

export const EmbyAPI = {
  async authenticate(serverUrl: string, username: string, password: string): Promise<{
    userId: string;
    accessToken: string;
    deviceId: string;
  }> {
    const deviceId = Math.random().toString(36).substring(2, 18);
    const response = await axios.post(
      `${serverUrl}/Users/AuthenticateByName`,
      { Username: username, Pw: password },
      {
        headers: {
          'X-Emby-Authorization': `MediaBrowser Client="StreamHub", Device="FireTV", DeviceId="${deviceId}", Version="1.0.0"`,
          'Content-Type': 'application/json',
        },
      }
    );
    return {
      userId: response.data.User.Id,
      accessToken: response.data.AccessToken,
      deviceId,
    };
  },

  async getContinueWatching(limit = 10): Promise<EmbyItem[]> {
    const emby = Store.get().emby!;
    const r = await getClient().get(`/Users/${emby.userId}/Items/Resume`, {
      params: { Limit: limit, Fields: 'Overview,Genres,UserData,ImageTags,BackdropImageTags', MediaTypes: 'Video' },
    });
    return r.data.Items || [];
  },

  async getNextUp(limit = 10): Promise<EmbyItem[]> {
    const emby = Store.get().emby!;
    const r = await getClient().get('/Shows/NextUp', {
      params: { UserId: emby.userId, Limit: limit, Fields: 'Overview,Genres,UserData,ImageTags,BackdropImageTags' },
    });
    return r.data.Items || [];
  },

  async getLatestMovies(limit = 20): Promise<EmbyItem[]> {
    const emby = Store.get().emby!;
    const r = await getClient().get(`/Users/${emby.userId}/Items/Latest`, {
      params: { Limit: limit, IncludeItemTypes: 'Movie', Fields: 'Overview,Genres,UserData,ImageTags' },
    });
    return r.data || [];
  },

  async getLatestShows(limit = 20): Promise<EmbyItem[]> {
    const emby = Store.get().emby!;
    const r = await getClient().get(`/Users/${emby.userId}/Items/Latest`, {
      params: { Limit: limit, IncludeItemTypes: 'Series', Fields: 'Overview,Genres,UserData,ImageTags' },
    });
    return r.data || [];
  },

  async getMovies(params: {
    limit?: number;
    sortBy?: string;
    genres?: string;
    years?: string;
    search?: string;
    startIndex?: number;
  } = {}): Promise<{ items: EmbyItem[]; total: number }> {
    const emby = Store.get().emby!;
    const r = await getClient().get(`/Users/${emby.userId}/Items`, {
      params: {
        IncludeItemTypes: 'Movie',
        Recursive: true,
        Fields: 'Overview,Genres,UserData,ImageTags,BackdropImageTags',
        SortBy: params.sortBy || 'SortName',
        SortOrder: 'Ascending',
        Limit: params.limit || 50,
        StartIndex: params.startIndex || 0,
        Genres: params.genres,
        Years: params.years,
        SearchTerm: params.search,
      },
    });
    return { items: r.data.Items || [], total: r.data.TotalRecordCount || 0 };
  },

  async getSeries(params: {
    limit?: number;
    sortBy?: string;
    genres?: string;
    search?: string;
    startIndex?: number;
  } = {}): Promise<{ items: EmbyItem[]; total: number }> {
    const emby = Store.get().emby!;
    const r = await getClient().get(`/Users/${emby.userId}/Items`, {
      params: {
        IncludeItemTypes: 'Series',
        Recursive: true,
        Fields: 'Overview,Genres,UserData,ImageTags,BackdropImageTags',
        SortBy: params.sortBy || 'SortName',
        SortOrder: 'Ascending',
        Limit: params.limit || 50,
        StartIndex: params.startIndex || 0,
        Genres: params.genres,
        SearchTerm: params.search,
      },
    });
    return { items: r.data.Items || [], total: r.data.TotalRecordCount || 0 };
  },

  async getSeasons(seriesId: string): Promise<EmbyItem[]> {
    const emby = Store.get().emby!;
    const r = await getClient().get(`/Shows/${seriesId}/Seasons`, {
      params: { UserId: emby.userId, Fields: 'Overview,UserData,ImageTags' },
    });
    return r.data.Items || [];
  },

  async getEpisodes(seriesId: string, seasonId: string): Promise<EmbyItem[]> {
    const emby = Store.get().emby!;
    const r = await getClient().get(`/Shows/${seriesId}/Episodes`, {
      params: { SeasonId: seasonId, UserId: emby.userId, Fields: 'Overview,UserData,ImageTags' },
    });
    return r.data.Items || [];
  },

  async search(query: string): Promise<EmbyItem[]> {
    const emby = Store.get().emby!;
    const r = await getClient().get(`/Users/${emby.userId}/Items`, {
      params: {
        SearchTerm: query,
        IncludeItemTypes: 'Movie,Series',
        Recursive: true,
        Fields: 'Overview,Genres,UserData,ImageTags',
        Limit: 30,
      },
    });
    return r.data.Items || [];
  },

  async getPlaybackInfo(itemId: string): Promise<PlaybackInfo> {
    const emby = Store.get().emby!;
    const r = await getClient().post(`/Items/${itemId}/PlaybackInfo`, {
      UserId: emby.userId,
      DeviceProfile: { DirectPlayProfiles: [{ Type: 'Video' }] },
    });
    return r.data;
  },

  async markPlayed(itemId: string) {
    const emby = Store.get().emby!;
    await getClient().post(`/Users/${emby.userId}/PlayedItems/${itemId}`);
  },

  async reportProgress(itemId: string, positionTicks: number) {
    const emby = Store.get().emby!;
    await getClient().post('/Sessions/Playing/Progress', {
      ItemId: itemId,
      UserId: emby.userId,
      PositionTicks: positionTicks,
    }).catch(() => {});
  },

  getImageUrl(item: EmbyItem, type: 'Primary' | 'Backdrop' | 'Thumb' = 'Primary', width = 300): string {
    const emby = Store.get().emby;
    if (!emby) return '';
    const tag = type === 'Backdrop'
      ? item.BackdropImageTags?.[0]
      : item.ImageTags?.[type];
    if (!tag) return '';
    return `${emby.serverUrl}/Items/${item.Id}/Images/${type}?tag=${tag}&maxWidth=${width}&quality=90`;
  },

  getStreamUrl(itemId: string, mediaSourceId: string): string {
    const emby = Store.get().emby!;
    return `${emby.serverUrl}/Videos/${itemId}/stream?MediaSourceId=${mediaSourceId}&Static=true&api_key=${emby.accessToken}`;
  },

  formatRuntime(ticks?: number): string {
    if (!ticks) return '';
    const mins = Math.floor(ticks / 600000000);
    const h = Math.floor(mins / 60);
    const m = mins % 60;
    return h > 0 ? `${h}h ${m}m` : `${m}m`;
  },
};
