import axios from 'axios';
import { Store } from '../store';

const RD_BASE = 'https://api.real-debrid.com/rest/1.0';
const TORRENTIO_BASE = 'https://torrentio.strem.fun';

export interface TorrentStream {
  name: string;
  title: string;
  url: string;
  infoHash?: string;
  quality: string;
  size?: string;
  seeds?: number;
  source: 'RealDebrid' | 'Direct';
  rdCached: boolean;
}

function rdHeaders() {
  const rd = Store.get().realDebrid;
  if (!rd) throw new Error('Real-Debrid not configured');
  return { Authorization: `Bearer ${rd.apiKey}` };
}

export const RealDebridAPI = {
  async validateKey(apiKey: string): Promise<{ valid: boolean; username?: string }> {
    try {
      const r = await axios.get(`${RD_BASE}/user`, {
        headers: { Authorization: `Bearer ${apiKey}` },
        timeout: 8000,
      });
      return { valid: true, username: r.data.username };
    } catch {
      return { valid: false };
    }
  },

  async unrestrictLink(magnetOrUrl: string): Promise<string> {
    // Add magnet to RD
    const addR = await axios.post(
      `${RD_BASE}/torrents/addMagnet`,
      `magnet=${encodeURIComponent(magnetOrUrl)}`,
      { headers: { ...rdHeaders(), 'Content-Type': 'application/x-www-form-urlencoded' } }
    );
    const torrentId = addR.data.id;

    // Select all files
    await axios.post(
      `${RD_BASE}/torrents/selectFiles/${torrentId}`,
      'files=all',
      { headers: { ...rdHeaders(), 'Content-Type': 'application/x-www-form-urlencoded' } }
    );

    // Poll until ready
    for (let i = 0; i < 30; i++) {
      await new Promise(r => setTimeout(r, 2000));
      const info = await axios.get(`${RD_BASE}/torrents/info/${torrentId}`, { headers: rdHeaders() });
      if (info.data.status === 'downloaded') {
        const link = info.data.links[0];
        const unr = await axios.post(
          `${RD_BASE}/unrestrict/link`,
          `link=${encodeURIComponent(link)}`,
          { headers: { ...rdHeaders(), 'Content-Type': 'application/x-www-form-urlencoded' } }
        );
        return unr.data.download;
      }
    }
    throw new Error('RD timeout');
  },

  async checkCached(infoHashes: string[]): Promise<Set<string>> {
    if (!infoHashes.length) return new Set();
    try {
      const r = await axios.get(
        `${RD_BASE}/torrents/instantAvailability/${infoHashes.join('/')}`,
        { headers: rdHeaders(), timeout: 8000 }
      );
      const cached = new Set<string>();
      for (const [hash, data] of Object.entries(r.data)) {
        if (data && typeof data === 'object' && Object.keys(data).length > 0) {
          cached.add(hash.toLowerCase());
        }
      }
      return cached;
    } catch {
      return new Set();
    }
  },
};

export const TorrentioAPI = {
  async getStreams(imdbId: string, type: 'movie' | 'series', season?: number, episode?: number): Promise<TorrentStream[]> {
    const rd = Store.get().realDebrid;
    const rdParam = rd ? `|realdebrid=${rd.apiKey}` : '';
    const config = `sort=qualitysize${rdParam}`;

    let path = `${TORRENTIO_BASE}/${config}/stream/${type}/${imdbId}`;
    if (type === 'series' && season !== undefined && episode !== undefined) {
      path += `:${season}:${episode}`;
    }
    path += '.json';

    const r = await axios.get(path, { timeout: 12000 });
    const streams: TorrentStream[] = [];

    for (const s of (r.data.streams || [])) {
      const title: string = s.title || s.name || '';
      const quality = extractQuality(title);
      const isRD = title.includes('⚡') || title.includes('RD+') || (s.url && s.url.includes('real-debrid'));

      streams.push({
        name: s.name || 'Unknown',
        title,
        url: s.url || '',
        infoHash: s.infoHash,
        quality,
        size: extractSize(title),
        seeds: extractSeeds(title),
        source: isRD ? 'RealDebrid' : 'Direct',
        rdCached: isRD,
      });
    }

    return streams;
  },
};

function extractQuality(title: string): string {
  if (/2160p|4K|UHD/i.test(title)) return '4K';
  if (/1080p/i.test(title)) return '1080p';
  if (/720p/i.test(title)) return '720p';
  if (/480p/i.test(title)) return '480p';
  return 'SD';
}

function extractSize(title: string): string {
  const m = title.match(/(\d+(?:\.\d+)?)\s*(?:GB|MB)/i);
  return m ? m[0] : '';
}

function extractSeeds(title: string): number | undefined {
  const m = title.match(/👤\s*(\d+)/);
  return m ? parseInt(m[1]) : undefined;
}
