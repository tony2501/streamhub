import AsyncStorage from '@react-native-async-storage/async-storage';

export interface EmbyConfig {
  serverUrl: string;
  username: string;
  userId: string;
  accessToken: string;
  deviceId: string;
}

export interface RealDebridConfig {
  apiKey: string;
  connected: boolean;
}

export interface AppSettings {
  preferredQuality: '4K' | '1080p' | '720p' | 'Auto';
  subtitles: boolean;
  subtitleLanguage: string;
  audioLanguage: string;
}

export interface AppStore {
  emby: EmbyConfig | null;
  realDebrid: RealDebridConfig | null;
  settings: AppSettings;
}

const STORAGE_KEY = 'streamhub_store';

const defaultSettings: AppSettings = {
  preferredQuality: 'Auto',
  subtitles: false,
  subtitleLanguage: 'eng',
  audioLanguage: 'eng',
};

let _store: AppStore = {
  emby: null,
  realDebrid: null,
  settings: defaultSettings,
};

let _listeners: Array<() => void> = [];

export const Store = {
  get: () => _store,

  async load() {
    try {
      const raw = await AsyncStorage.getItem(STORAGE_KEY);
      if (raw) {
        _store = { ...defaultSettings, ...JSON.parse(raw) };
      }
    } catch {}
  },

  async save() {
    try {
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(_store));
    } catch {}
  },

  async setEmby(config: EmbyConfig) {
    _store = { ..._store, emby: config };
    await this.save();
    _listeners.forEach(fn => fn());
  },

  async setRealDebrid(config: RealDebridConfig) {
    _store = { ..._store, realDebrid: config };
    await this.save();
    _listeners.forEach(fn => fn());
  },

  async updateSettings(settings: Partial<AppSettings>) {
    _store = { ..._store, settings: { ..._store.settings, ...settings } };
    await this.save();
    _listeners.forEach(fn => fn());
  },

  async logout() {
    _store = { emby: null, realDebrid: null, settings: defaultSettings };
    await AsyncStorage.removeItem(STORAGE_KEY);
    _listeners.forEach(fn => fn());
  },

  subscribe(fn: () => void) {
    _listeners.push(fn);
    return () => { _listeners = _listeners.filter(l => l !== fn); };
  },
};
