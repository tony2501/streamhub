import React, { useState, useEffect } from 'react';
import { View, StyleSheet, StatusBar } from 'react-native';
import { Colors } from '../theme';
import { Sidebar, NavTab } from '../components/Sidebar';
import { HomeScreen } from '../screens/HomeScreen';
import { DiscoverScreen } from '../screens/DiscoverScreen';
import { LibraryScreen } from '../screens/LibraryScreen';
import { SearchScreen } from '../screens/SearchScreen';
import { SettingsScreen } from '../screens/SettingsScreen';
import { DetailScreen } from '../screens/DetailScreen';
import { PlayerScreen } from '../screens/PlayerScreen';
import { EmbyItem } from '../services/emby';

interface AppShellProps {
  onLogout: () => void;
}

type AppView =
  | { type: 'main'; tab: NavTab }
  | { type: 'detail'; item: EmbyItem }
  | { type: 'player'; url: string; title: string; item: EmbyItem };

export function AppShell({ onLogout }: AppShellProps) {
  const [view, setView] = useState<AppView>({ type: 'main', tab: 'home' });

  const handleSelectItem = (item: EmbyItem) => {
    setView({ type: 'detail', item });
  };

  const handlePlay = (url: string, title: string, item: EmbyItem) => {
    setView({ type: 'player', url, title, item });
  };

  const handleBack = () => {
    if (view.type === 'player') {
      setView(prev => ({ type: 'detail', item: (prev as any).item }));
    } else if (view.type === 'detail') {
      setView({ type: 'main', tab: 'home' });
    }
  };

  const handleTabChange = (tab: NavTab) => {
    setView({ type: 'main', tab });
  };

  // Full-screen player - no sidebar
  if (view.type === 'player') {
    return (
      <>
        <StatusBar hidden />
        <PlayerScreen
          url={view.url}
          title={view.title}
          item={view.item}
          onBack={handleBack}
        />
      </>
    );
  }

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={Colors.navBg} />

      {/* Sidebar - hidden on detail view */}
      {view.type === 'main' && (
        <Sidebar
          activeTab={view.tab}
          onTabChange={handleTabChange}
        />
      )}

      {/* Main content */}
      <View style={styles.content}>
        {view.type === 'detail' ? (
          <DetailScreen
            item={view.item}
            onPlay={handlePlay}
            onBack={handleBack}
          />
        ) : view.tab === 'home' ? (
          <HomeScreen onSelectItem={handleSelectItem} />
        ) : view.tab === 'discover' ? (
          <DiscoverScreen onSelectItem={handleSelectItem} />
        ) : view.tab === 'library' ? (
          <LibraryScreen onSelectItem={handleSelectItem} />
        ) : view.tab === 'search' ? (
          <SearchScreen onSelectItem={handleSelectItem} />
        ) : view.tab === 'settings' ? (
          <SettingsScreen onLogout={onLogout} />
        ) : null}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'row',
    backgroundColor: Colors.bg,
  },
  content: {
    flex: 1,
  },
});
