import React, { useEffect, useState } from 'react';
import { View, ActivityIndicator, StyleSheet } from 'react-native';
import { Store } from './src/store';
import { LoginScreen } from './src/screens/LoginScreen';
import { AppShell } from './src/navigation/AppShell';
import { Colors } from './src/theme';

export default function App() {
  const [loading, setLoading] = useState(true);
  const [authenticated, setAuthenticated] = useState(false);

  useEffect(() => {
    Store.load().then(() => {
      const { emby } = Store.get();
      setAuthenticated(!!emby?.accessToken);
      setLoading(false);
    });

    const unsub = Store.subscribe(() => {
      const { emby } = Store.get();
      setAuthenticated(!!emby?.accessToken);
    });

    return unsub;
  }, []);

  if (loading) {
    return (
      <View style={styles.loading}>
        <ActivityIndicator size="large" color={Colors.accent} />
      </View>
    );
  }

  if (!authenticated) {
    return <LoginScreen onLoginComplete={() => setAuthenticated(true)} />;
  }

  return <AppShell onLogout={() => setAuthenticated(false)} />;
}

const styles = StyleSheet.create({
  loading: {
    flex: 1,
    backgroundColor: Colors.bg,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
