# StreamHub

A personal media centre for Fire TV / Android TV.  
Connects to **Emby Media Server** + **Real-Debrid** via Torrentio.

## Features

- 🏠 **Home** — Hero banner, Continue Watching, Next Up, Latest Movies/Shows
- 🔍 **Discover** — Browse with genre + sort filters, paginated grid
- 📚 **Library** — Full Emby library browser (Movies + TV)
- 🔎 **Search** — Live search across your Emby library
- ▶️ **Player** — expo-av player with progress reporting back to Emby
- ⚡ **Real-Debrid** — Torrentio stream picker with cached RD streams
- 🎮 **D-pad navigation** — Built for Fire TV remote

---

## Build the APK

### Option 1: EAS Build (easiest — cloud build, no Android Studio needed)

```bash
# 1. Install EAS CLI
npm install -g eas-cli

# 2. Login to Expo (create free account at expo.dev)
eas login

# 3. Build APK
cd StreamHub
eas build --platform android --profile preview
```

EAS will give you a download link for the APK when done (~5 min).  
Sideload it onto Fire TV with `adb install StreamHub.apk`.

---

### Option 2: Local build with Android Studio

```bash
# 1. Install prerequisites
# - Android Studio (with SDK 34, build-tools 34)
# - Java 17+

# 2. Generate native project
npx expo prebuild --platform android

# 3. Build APK
cd android
./gradlew assembleRelease

# APK will be at:
# android/app/build/outputs/apk/release/app-release.apk
```

---

### Option 3: Expo Go (development/testing only)

```bash
npx expo start
```

Scan QR with Expo Go app on Android phone/tablet.

---

## Sideload to Fire TV

```bash
# Enable ADB on Fire TV: Settings > My Fire TV > Developer Options > ADB Debugging

# Find Fire TV IP: Settings > My Fire TV > About > Network

adb connect 192.168.x.x:5555
adb install StreamHub.apk
```

---

## Configuration

On first launch:
1. Enter your **Emby server URL** (e.g. `http://192.168.1.100:8096`)
2. Enter **username + password**
3. Optionally add your **Real-Debrid API key** (from real-debrid.com/apitoken)

---

## Project Structure

```
src/
  theme/          — colours, typography, spacing
  store/          — app state (AsyncStorage)
  services/
    emby.ts       — Emby API client
    realdebrid.ts — Real-Debrid + Torrentio
  components/
    Sidebar.tsx   — Left nav (Home/Discover/Library/Search/Settings)
    MediaCard.tsx — Poster card with focus animation
    MediaRow.tsx  — Horizontal scrollable shelf
    Focusable.tsx — D-pad focusable wrapper
  screens/
    LoginScreen.tsx
    HomeScreen.tsx
    DiscoverScreen.tsx
    LibraryScreen.tsx
    SearchScreen.tsx
    DetailScreen.tsx  — Stream picker modal
    PlayerScreen.tsx  — Video player
  navigation/
    AppShell.tsx  — Main layout + routing
```
