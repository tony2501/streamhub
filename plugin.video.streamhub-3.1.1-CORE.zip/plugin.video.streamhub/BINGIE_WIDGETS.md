# StreamHub — Bingie Skin 1.0.0 Widget Setup

Configure these in Bingie → Settings → Edit Menu Shortcuts → Widgets.

## Widget URLs

### Continue Watching  (Movies + Episodes)
```
plugin://plugin.video.streamhub/?mode=WIDGET_CONTINUE_WATCHING
```

### Recently Added Movies
```
plugin://plugin.video.streamhub/?mode=WIDGET_MOVIES_RECENT
```

### Movies In Progress
```
plugin://plugin.video.streamhub/?mode=WIDGET_MOVIES_INPROGRESS
```

### Popular Movies
```
plugin://plugin.video.streamhub/?mode=WIDGET_MOVIES_POPULAR
```

### Top Rated Movies
```
plugin://plugin.video.streamhub/?mode=WIDGET_MOVIES_TOPRATED
```

### Recently Added Episodes
```
plugin://plugin.video.streamhub/?mode=WIDGET_SHOWS_RECENT
```

### TV Episodes In Progress
```
plugin://plugin.video.streamhub/?mode=WIDGET_SHOWS_INPROGRESS
```

## Speed Notes

All widget endpoints use slim Emby field sets (~60% smaller responses)
and a shared in-memory + disc cache. Cache is pre-warmed in background
the moment you open the StreamHub main menu, so Bingie home rows load
from cache without any network calls.

| Widget                | Network TTL | Cold load  | Warm load |
|-----------------------|-------------|------------|-----------|
| Continue Watching     | 60s         | ~200-400ms | <5ms      |
| Recently Added        | 120s        | ~200-400ms | <5ms      |
| In Progress           | 60s         | ~200-400ms | <5ms      |
| Popular / Top Rated   | 120s        | ~200-400ms | <5ms      |

## IMDB / TMDB Ratings in Bingie

Each ListItem now includes `setUniqueIDs()` with IMDB, TMDB, and TVDB
provider IDs from Emby. Bingie's TMDbHelper integration will
automatically resolve ratings and artwork for items that have them.

## Recommended Bingie Widget Layout

| Hub       | Widget 1              | Widget 2            | Widget 3              |
|-----------|-----------------------|---------------------|-----------------------|
| Home      | Continue Watching     | Recently Added (TV) | Popular Movies        |
| Movies    | Recently Added Movies | Movies In Progress  | Top Rated Movies      |
| TV Shows  | Episodes In Progress  | Recently Added (TV) | —                     |
