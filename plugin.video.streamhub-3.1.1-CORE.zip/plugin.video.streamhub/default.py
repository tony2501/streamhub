"""
StreamHub - Kodi Omega Plugin
Entry point. Mode-based routing identical to EmbyCon pattern.
"""

import sys
from urllib.parse import parse_qsl

import xbmc
import xbmcaddon
import xbmcplugin

ADDON = xbmcaddon.Addon()

# Write baked-in defaults once per install/version — not on every invocation.
_INIT_KEY = 'streamhub_init_302'
if not ADDON.getSetting(_INIT_KEY):
    _DEFAULTS = {
        'emby_server':    'https://emby5.mm04.appboxmanager.xyz',
        'emby_token':     '763f377758974b9baf8104cf44f189f9',
        'emby_user_id':   'ab5b108d51d24e10958eb2c02aa2d7e2',
        'emby_username':  'antonyarcuri',
        'tmdb_api_key':   '435fb4fb5912e6d5f5b80c736bf289e1',
        'xtream_server':   'http://88871-itself.tx-4kott.com',
        'xtream_username': 'u2ox8anuc2',
        'xtream_password': '6295ee6d02',
        'rd_api_key':      '',
        'rd_access_token': '',
        'rd_refresh_token': '',
        'rd_client_id':    '',
        'rd_client_secret': '',
    }
    for _k, _v in _DEFAULTS.items():
        if not ADDON.getSetting(_k):
            ADDON.setSetting(_k, _v)
    ADDON.setSetting(_INIT_KEY, 'true')


def main():
    params = dict(parse_qsl(sys.argv[2][1:]))
    mode   = params.get('mode', 'MAIN_MENU')
    try:
        from resources.lib.routes import dispatch
        dispatch(mode, params)
    except Exception as e:
        import traceback
        xbmc.log(f'[StreamHub] FATAL mode={mode}: {traceback.format_exc()}', xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)


if __name__ == '__main__':
    main()
