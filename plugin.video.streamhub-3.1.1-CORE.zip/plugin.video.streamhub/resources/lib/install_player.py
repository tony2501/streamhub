"""
StreamHub - TMDbHelper Player File Installer

Copies the bundled streamhub.json player file into the correct
TMDbHelper Players directory for the current platform.

TMDbHelper looks for player files in:
  <userdata>/addon_data/plugin.video.tmdbhelper/Players/

This is the same path on all platforms — Kodi's special://userdata
resolves to the platform-specific location automatically.
"""

import os
import shutil
import xbmc
import xbmcvfs
import xbmcaddon
from resources.lib.kodi_utils import log, notify


def _players_dir():
    """Return the TMDbHelper Players directory path, creating it if needed."""
    path = xbmcvfs.translatePath(
        'special://userdata/addon_data/plugin.video.tmdbhelper/Players/'
    )
    if not xbmcvfs.exists(path):
        xbmcvfs.mkdirs(path)
    return path


def _source_file():
    """Return the path to the bundled streamhub.json inside our addon."""
    addon_path = xbmcaddon.Addon('plugin.video.streamhub').getAddonInfo('path')
    return os.path.join(addon_path, 'resources', 'data', 'streamhub.json')


def _marker_file():
    """Flag file so we only install once per addon version."""
    addon_ver = xbmcaddon.Addon('plugin.video.streamhub').getAddonInfo('version')
    data_dir = xbmcvfs.translatePath(
        'special://userdata/addon_data/plugin.video.streamhub/'
    )
    if not xbmcvfs.exists(data_dir):
        xbmcvfs.mkdirs(data_dir)
    return os.path.join(data_dir, f'.player_installed_{addon_ver}')


def install_player_file(force=False):
    """
    Copy streamhub.json to the TMDbHelper Players directory.
    Skips silently if already installed for this version unless force=True.
    """
    marker = _marker_file()

    if not force and os.path.exists(marker):
        log('StreamHub: player file already installed, skipping', xbmc.LOGDEBUG)
        return

    src = _source_file()
    if not os.path.exists(src):
        log(f'StreamHub: bundled player file not found at {src}', xbmc.LOGWARNING)
        return

    players_dir = _players_dir()
    dst = os.path.join(players_dir, 'streamhub.json')

    try:
        shutil.copy2(src, dst)
        log(f'StreamHub: player file installed to {dst}', xbmc.LOGINFO)
        # Write marker so we don't reinstall on every launch
        with open(marker, 'w') as f:
            f.write(dst)
        notify('StreamHub: TMDbHelper player file installed ✓', ms=3000)
    except Exception as e:
        log(f'StreamHub: failed to install player file: {e}', xbmc.LOGWARNING)
