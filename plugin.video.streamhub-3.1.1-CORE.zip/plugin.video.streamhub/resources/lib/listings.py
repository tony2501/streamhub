"""
StreamHub - Listings
TMDB-matched discovery lists + pure-Emby library lists.
"""

import re
from urllib.parse import quote as _url_quote
import xbmc, xbmcgui, xbmcplugin
from resources.lib.kodi_utils import (
    HANDLE, get_int, get_setting,
    add_dir_item, add_media_item, end_directory, end_directory_failed,
    plugin_url, keyboard_input, notify, _stream_height,
)


def _sort_key():
    m = {'0': 'SortName', '1': 'DateCreated', '2': 'CommunityRating', '3': 'PremiereDate'}
    return m.get(get_setting('default_sort', '0'), 'SortName')

def _limit():
    return get_int('items_per_page', 50)

def _next_page(mode, params, data, extra=None):
    total = data.get('TotalRecordCount', 0)
    start = int(params.get('start', 0))
    limit = _limit()
    if start + limit < total:
        kw = {'start': start + limit}
        if extra:
            kw.update(extra)
        nxt = start + limit + 1
        end = min(start + limit * 2, total)
        add_dir_item(f'Next Page  ({nxt}-{end} of {total})',
                     mode, 'DefaultAddonNext.png', **kw)


# ------------------------------------------------------------------ #
# Helpers
# ------------------------------------------------------------------ #

def _tmdb_ok(tmdb):
    return tmdb is not None and tmdb.is_configured()


def _fetch_tmdb_pages(fetch_fn, pages=2):
    """
    Fetch `pages` pages from a TMDB endpoint.
    Endpoints that don't accept a page param are called once only.
    """
    results = []
    for p in range(1, pages + 1):
        try:
            batch = fetch_fn(page=p)
        except TypeError:
            # Function doesn't accept page — call once without it
            try:
                batch = fetch_fn()
            except Exception as e:
                log(f'TMDB fetch: {e}', xbmc.LOGWARNING)
                break
            if batch:
                results.extend(batch)
            break
        except Exception as e:
            log(f'TMDB fetch: {e}', xbmc.LOGWARNING)
            break
        if not batch:
            break
        results.extend(batch)
    return results


def _list_tmdb_movies(tmdb_results, emby, tmdb, fallback_fn):
    matched = []
    if _tmdb_ok(tmdb) and tmdb_results:
        from resources.lib.matcher import match_movies
        matched = match_movies(tmdb_results, emby, limit=_limit())

    if not matched:
        if not _tmdb_ok(tmdb):
            notify('Add a TMDB API key in Settings for TMDB-ordered lists.')
        data = fallback_fn()
        list_movies_data(data, emby)
        return

    for item in matched:
        add_media_item(item, emby)
    end_directory('movies', [xbmcplugin.SORT_METHOD_NONE,
                              xbmcplugin.SORT_METHOD_VIDEO_SORT_TITLE_IGNORE_THE,
                              xbmcplugin.SORT_METHOD_VIDEO_RATING])


def _list_tmdb_shows(tmdb_results, emby, tmdb, fallback_fn):
    matched = []
    if _tmdb_ok(tmdb) and tmdb_results:
        from resources.lib.matcher import match_tvshows
        matched = match_tvshows(tmdb_results, emby, limit=_limit())

    if not matched:
        if not _tmdb_ok(tmdb):
            notify('Add a TMDB API key in Settings for TMDB-ordered lists.')
        data = fallback_fn()
        list_shows_data(data, emby)
        return

    for item in matched:
        li = _make_show_li(item, emby)
        url = plugin_url('TV_SEASONS', series_id=item['Id'])
        xbmcplugin.addDirectoryItem(HANDLE, url, li, True)
    end_directory('tvshows', [xbmcplugin.SORT_METHOD_NONE])


# ------------------------------------------------------------------ #
# Movie discovery (TMDB-matched)
# Fetch 2 pages = 40 candidates. With AnyProviderIdEquals this is
# 1-2 batched Emby calls — fast, no full library scan.
# ------------------------------------------------------------------ #

def list_movies_popular(emby, tmdb):
    results = _fetch_tmdb_pages(tmdb.movies_popular, pages=2) if _tmdb_ok(tmdb) else []
    _list_tmdb_movies(results, emby, tmdb, lambda: emby.movies_popular())

def list_movies_trending(emby, tmdb):
    results = _fetch_tmdb_pages(tmdb.movies_trending_week, pages=1) if _tmdb_ok(tmdb) else []
    _list_tmdb_movies(results, emby, tmdb, lambda: emby.movies_trending())

def list_movies_top_rated(emby, tmdb):
    results = _fetch_tmdb_pages(tmdb.movies_top_rated, pages=2) if _tmdb_ok(tmdb) else []
    _list_tmdb_movies(results, emby, tmdb, lambda: emby.movies_top_rated())

def list_movies_now_playing(emby, tmdb):
    results = _fetch_tmdb_pages(tmdb.movies_now_playing, pages=1) if _tmdb_ok(tmdb) else []
    _list_tmdb_movies(results, emby, tmdb, lambda: emby.movies_now_playing())

def list_movies_upcoming(emby, tmdb):
    results = _fetch_tmdb_pages(tmdb.movies_upcoming, pages=1) if _tmdb_ok(tmdb) else []
    _list_tmdb_movies(results, emby, tmdb, lambda: emby.movies_upcoming())


# ------------------------------------------------------------------ #
# TV discovery (TMDB-matched)
# ------------------------------------------------------------------ #

def list_shows_popular(emby, tmdb):
    results = _fetch_tmdb_pages(tmdb.tv_popular, pages=2) if _tmdb_ok(tmdb) else []
    _list_tmdb_shows(results, emby, tmdb, lambda: emby.shows_popular())

def list_shows_trending(emby, tmdb):
    results = _fetch_tmdb_pages(tmdb.tv_trending_week, pages=1) if _tmdb_ok(tmdb) else []
    _list_tmdb_shows(results, emby, tmdb, lambda: emby.shows_trending())

def list_shows_top_rated(emby, tmdb):
    results = _fetch_tmdb_pages(tmdb.tv_top_rated, pages=2) if _tmdb_ok(tmdb) else []
    _list_tmdb_shows(results, emby, tmdb, lambda: emby.shows_top_rated())

def list_shows_on_air(emby, tmdb):
    results = _fetch_tmdb_pages(tmdb.tv_on_air, pages=1) if _tmdb_ok(tmdb) else []
    _list_tmdb_shows(results, emby, tmdb, lambda: emby.shows_on_air())

def list_shows_airing_today(emby, tmdb):
    results = _fetch_tmdb_pages(tmdb.tv_airing_today, pages=1) if _tmdb_ok(tmdb) else []
    _list_tmdb_shows(results, emby, tmdb, lambda: emby.shows_airing_today())


# ------------------------------------------------------------------ #
# Pure-Emby library lists
# ------------------------------------------------------------------ #

def list_movies_data(data, emby, widget=False):
    if not data or not data.get('Items'):
        notify('No movies found'); end_directory_failed(); return
    for item in data['Items']:
        add_media_item(item, emby)
    if widget:
        end_directory('movies', [xbmcplugin.SORT_METHOD_NONE], cache=True)
    else:
        end_directory('movies', [xbmcplugin.SORT_METHOD_VIDEO_SORT_TITLE_IGNORE_THE,
                                  xbmcplugin.SORT_METHOD_VIDEO_RATING,
                                  xbmcplugin.SORT_METHOD_VIDEO_YEAR])


def list_movies_paged(emby, params, genre=None, year=None, studio=None, unwatched=False):
    start = int(params.get('start', 0))
    limit = _limit()
    if unwatched:
        data = emby.movies_unwatched(start=start, limit=limit)
    else:
        data = emby.movies_all(start=start, limit=limit, sort=_sort_key(),
                               genre=genre, year=year, studio=studio)
    if not data or not data.get('Items'):
        notify('No movies found'); end_directory_failed(); return
    for item in data['Items']:
        add_media_item(item, emby)
    mode = ('MOVIES_UNWATCHED' if unwatched else
            'MOVIES_BY_GENRE' if genre else
            'MOVIES_BY_YEAR' if year else
            'MOVIES_BY_STUDIO' if studio else 'MOVIES_ALL')
    extra = {}
    if genre:  extra['genre']  = genre
    if year:   extra['year']   = year
    if studio: extra['studio'] = studio
    _next_page(mode, params, data, extra)
    end_directory('movies', [xbmcplugin.SORT_METHOD_VIDEO_SORT_TITLE_IGNORE_THE])


def list_shows_data(data, emby, widget=False):
    if not data or not data.get('Items'):
        notify('No TV shows found'); end_directory_failed(); return
    for item in data['Items']:
        li  = _make_show_li(item, emby)
        url = plugin_url('TV_SEASONS', series_id=item['Id'])
        xbmcplugin.addDirectoryItem(HANDLE, url, li, True)
    if widget:
        end_directory('tvshows', [xbmcplugin.SORT_METHOD_NONE], cache=True)
    else:
        end_directory('tvshows', [xbmcplugin.SORT_METHOD_VIDEO_SORT_TITLE_IGNORE_THE])


def list_shows_paged(emby, params, genre=None, unwatched=False):
    start = int(params.get('start', 0))
    limit = _limit()
    mode  = params.get('mode', 'TV_UNWATCHED' if unwatched else 'TV_ALL')
    data  = (emby.shows_unwatched(start=start, limit=limit) if unwatched
             else emby.shows_all(start=start, limit=limit, sort=_sort_key(), genre=genre))
    if not data or not data.get('Items'):
        notify('No TV shows found'); end_directory_failed(); return
    for item in data['Items']:
        li  = _make_show_li(item, emby)
        url = plugin_url('TV_SEASONS', series_id=item['Id'])
        xbmcplugin.addDirectoryItem(HANDLE, url, li, True)
    extra = {'genre': genre} if genre else {}
    _next_page(mode, params, data, extra)
    end_directory('tvshows', [xbmcplugin.SORT_METHOD_VIDEO_SORT_TITLE_IGNORE_THE])


def _make_show_li(item, client):
    iid      = item.get('Id', '')
    name     = item.get('Name', 'Unknown')
    year     = item.get('ProductionYear', 0)
    overview = item.get('Overview', '')
    rating   = float(item.get('CommunityRating') or 0)
    genres   = item.get('Genres', [])
    ud       = item.get('UserData', {})
    is_fav   = ud.get('IsFavorite', False)
    use_tmdb = item.get('_use_tmdb_art', False)

    li = xbmcgui.ListItem(name)
    tag = li.getVideoInfoTag()
    tag.setTitle(name); tag.setPlot(overview)
    tag.setYear(int(year) if year else 0)
    tag.setRating(rating); tag.setGenres(genres)
    tag.setMediaType('tvshow'); tag.setTvShowTitle(name)

    pids = item.get('ProviderIds', {})
    if pids:
        unique = {}
        if pids.get('Imdb'): unique['imdb'] = pids['Imdb']
        if pids.get('Tmdb'): unique['tmdb'] = pids['Tmdb']
        if pids.get('Tvdb'): unique['tvdb'] = pids['Tvdb']
        if unique:
            tag.setUniqueIDs(unique, defaultuniqueid='tvdb' if 'tvdb' in unique else 'tmdb')

    if use_tmdb:
        poster = item.get('_tmdb_poster', '') or client.image_url(iid)
        fanart = item.get('_tmdb_backdrop', '') or client.image_url(iid, 'Backdrop', 1920)
    else:
        poster = client.image_url(iid)
        fanart = client.image_url(iid, 'Backdrop', 1920)
    li.setArt({'thumb': poster, 'poster': poster, 'fanart': fanart})

    fav_label = 'Remove from Favourites' if is_fav else 'Add to Favourites'
    li.addContextMenuItems([
        (fav_label, f'RunPlugin({plugin_url("TOGGLE_FAVOURITE", item_id=iid, is_fav=str(is_fav).lower())})'),
        ('Settings', f'RunPlugin({plugin_url("SHOW_SETTINGS")})'),
    ])
    return li


# ------------------------------------------------------------------ #
# Seasons / Episodes
# ------------------------------------------------------------------ #

def list_seasons(client, series_id):
    if not series_id:
        end_directory_failed(); return
    data = client.seasons(series_id)
    if not data or not data.get('Items'):
        notify('No seasons found'); end_directory_failed(); return
    for s in data['Items']:
        sid   = s.get('Id', '')
        name  = s.get('Name', 'Unknown')
        count = s.get('ChildCount', 0)
        label = f'{name}  ({count} episode{"s" if count != 1 else ""})' if count else name
        li    = xbmcgui.ListItem(label)
        poster = client.image_url(sid)
        li.setArt({'thumb': poster, 'poster': poster,
                   'fanart': client.image_url(series_id, 'Backdrop', 1920)})
        tag = li.getVideoInfoTag()
        tag.setTitle(name); tag.setSeason(s.get('IndexNumber', 0))
        tag.setTvShowTitle(s.get('SeriesName', '')); tag.setMediaType('season')
        xbmcplugin.addDirectoryItem(
            HANDLE, plugin_url('TV_EPISODES', series_id=series_id, season_id=sid), li, True)
    end_directory('seasons')


def list_episodes(data, emby=None, widget=False):
    if not data or not data.get('Items'):
        notify('No episodes found'); end_directory_failed(); return
    if emby is None:
        from resources.lib.emby_client import EmbyClient
        emby = EmbyClient()

    from resources.lib.kodi_utils import _stream_height

    def _item_height(item):
        for ms in item.get('MediaSources', []):
            h = _stream_height(ms)
            if h: return -h
        return 0

    # Group duplicate episodes (4K + 1080p stored as separate Emby items).
    # Primary key: (season, episode number). Fallback: normalised episode name.
    groups = {}
    order = []
    for item in data['Items']:
        s = item.get('ParentIndexNumber', 0)
        e = item.get('IndexNumber', 0)
        if s or e:
            key = (s, e)
        else:
            key = re.sub(r'\s+', ' ', item.get('Name', '').lower().strip())
        if key not in groups:
            groups[key] = []
            order.append(key)
        groups[key].append(item)

    for key in order:
        versions = sorted(groups[key], key=_item_height)
        primary = dict(versions[0])
        # Always store version IDs — picker uses them at play time.
        # Even single-version episodes store their own ID so the player
        # path is consistent.
        primary['_version_ids'] = [v['Id'] for v in versions]
        add_media_item(primary, emby)

    if widget:
        end_directory('episodes', [xbmcplugin.SORT_METHOD_NONE], cache=True)
    else:
        end_directory('episodes', [xbmcplugin.SORT_METHOD_EPISODE])


# ------------------------------------------------------------------ #
# Browse-by
# ------------------------------------------------------------------ #

def list_genres(data, next_mode):
    if not data or not data.get('Items'):
        notify('No genres found'); end_directory_failed(); return
    for g in data['Items']:
        add_dir_item(g['Name'], next_mode, 'DefaultGenre.png', genre=g['Name'])
    end_directory('files')


def list_studios(data):
    if not data or not data.get('Items'):
        notify('No studios found'); end_directory_failed(); return
    for s in data['Items']:
        add_dir_item(s['Name'], 'MOVIES_BY_STUDIO', 'DefaultActor.png', studio=s['Name'])
    end_directory('files')


def list_years(years):
    if not years:
        notify('No years found'); end_directory_failed(); return
    for y in years:
        add_dir_item(str(y), 'MOVIES_BY_YEAR', 'DefaultYear.png', year=y)
    end_directory('files')


# ------------------------------------------------------------------ #
# Continue Watching
# ------------------------------------------------------------------ #

def list_continue_watching(emby):
    """
    Mixed Movies + Episodes that are in-progress, sorted by most
    recently watched. Deduplicates by title so 4K and 1080p versions
    of the same item appear only once — always the highest quality.
    Also includes items played via Real-Debrid (tracked locally).
    """
    data  = emby.continue_watching()
    items = (data or {}).get('Items', [])

    # Build a stable dedup key per item, then keep only the best quality.
    def _key(item):
        itype = item.get('Type', '')
        pids  = item.get('ProviderIds', {})
        tmdb  = pids.get('Tmdb', '')
        if itype == 'Episode':
            return ('ep',
                    item.get('SeriesName', ''),
                    item.get('ParentIndexNumber', 0),
                    item.get('IndexNumber', 0))
        if tmdb:
            return ('tmdb', tmdb)
        return ('raw', item.get('Name', ''), item.get('ProductionYear', ''))

    def _quality(item):
        sources = item.get('MediaSources', [])
        if not sources:
            return 0
        return max(_stream_height(ms) for ms in sources)

    seen = {}  # key -> best item so far
    for item in items:
        k = _key(item)
        if k not in seen or _quality(item) > _quality(seen[k]):
            seen[k] = item

    # Preserve original order (most recently watched first)
    emby_order = []
    for item in items:
        k = _key(item)
        if k in seen and seen[k] is item:
            emby_order.append(item)
            seen.pop(k)

    # ── RD in-progress entries ────────────────────────────────────────
    from resources.lib.kodi_utils import rd_progress_get_all
    rd_entries = rd_progress_get_all()

    # Build dedup keys for Emby items so we don't double-show
    emby_imdb_keys = set()
    for item in emby_order:
        imdb = item.get('ProviderIds', {}).get('Imdb', '')
        if imdb:
            itype = item.get('Type', '')
            if itype == 'Episode':
                s = item.get('ParentIndexNumber', 0)
                e = item.get('IndexNumber', 0)
                emby_imdb_keys.add(f'{imdb}:s{s}e{e}')
            else:
                emby_imdb_keys.add(imdb)

    # Merge: interleave by timestamp so newest is first across both sources
    merged = [(item.get('UserData', {}).get('LastPlayedDate', ''), 'emby', item)
              for item in emby_order]
    for rd in rd_entries:
        rd_key = rd.get('key', '')
        if rd_key in emby_imdb_keys:
            continue   # Emby already tracking this — skip RD duplicate
        merged.append((str(rd.get('ts', 0)), 'rd', rd))

    merged.sort(key=lambda x: x[0], reverse=True)

    if not merged:
        notify('Nothing in progress')
        end_directory_failed()
        return

    for _, source, entry in merged:
        if source == 'emby':
            add_media_item(entry, emby)
        else:
            _add_rd_continue_item(entry)

    end_directory('videos', [xbmcplugin.SORT_METHOD_NONE], cache=False)


def _add_rd_continue_item(rd_entry):
    """Add a RD in-progress item to the Continue Watching list."""
    from resources.lib.kodi_utils import HANDLE, plugin_url
    import xbmcplugin

    imdb_id    = rd_entry.get('imdb_id', '')
    media_type = rd_entry.get('media_type', 'movie')
    season     = rd_entry.get('season')
    episode    = rd_entry.get('episode')
    title      = rd_entry.get('title', 'Unknown')
    series     = rd_entry.get('series_title', '')
    thumb      = rd_entry.get('thumb', '')
    fanart     = rd_entry.get('fanart', '')
    year       = rd_entry.get('year', 0)
    duration   = rd_entry.get('duration', 0)
    position   = rd_entry.get('position', 0)
    overview   = rd_entry.get('overview', '')
    pct        = rd_entry.get('pct', 0)

    display = f'{series} — {title}' if series else title

    li  = xbmcgui.ListItem(f'[RD] {display}')
    li.setProperty('IsPlayable', 'true')
    li.setArt({'thumb': thumb, 'fanart': fanart, 'poster': thumb})

    tag = li.getVideoInfoTag()
    tag.setTitle(title)
    tag.setPlot(overview or f'Resume from {int(position//60)}:{int(position%60):02d}  ({pct:.0f}%)')
    if year:
        tag.setYear(year)
    if duration:
        tag.setDuration(duration)
    if media_type == 'series' and season and episode:
        tag.setMediaType('episode')
        tag.setTvShowTitle(series)
        tag.setSeason(season)
        tag.setEpisode(episode)
    else:
        tag.setMediaType('movie')
    if duration and position:
        tag.setResumePoint(position, duration)

    # Route back through TMDB_PLAY so the quality picker appears again
    # The user picks RD again (or Emby) and it resumes from position
    url = plugin_url('TMDB_PLAY',
                     tmdb_id=imdb_id,
                     media_type='tv' if media_type == 'series' else 'movie',
                     season=str(season or ''),
                     episode=str(episode or ''))
    xbmcplugin.addDirectoryItem(HANDLE, url, li, False)


def list_iptv_recents():
    """Recently watched IPTV channels, newest first."""
    from resources.lib.kodi_utils import iptv_recents_get
    from resources.lib.channel_logos import get_logo
    recents = iptv_recents_get()

    if not recents:
        notify('No recently watched channels')
        end_directory_failed()
        return

    for ch in recents:
        sid  = ch.get('stream_id', '')
        name = ch.get('name', 'Unknown')
        icon = ch.get('icon', '')
        logo = get_logo(name, fallback_url=icon)

        route_url = plugin_url('IPTV_PLAY',
                               stream_id=sid,
                               name=_url_quote(name, safe=''),
                               icon=_url_quote(icon, safe=''),
                               use_ts='0')

        li = xbmcgui.ListItem(name)
        li.setProperty('IsPlayable', 'true')
        if logo:
            li.setArt({'thumb': logo, 'icon': logo})
        li.setInfo('video', {'title': name, 'mediatype': 'video'})

        xbmcplugin.addDirectoryItem(HANDLE, route_url, li, False)

    end_directory('videos', [xbmcplugin.SORT_METHOD_NONE], cache=False)


# ------------------------------------------------------------------ #
# Search — pure Emby, no TMDB
# ------------------------------------------------------------------ #

def do_search(emby):
    query = keyboard_input('Search Emby Library')
    if not query:
        end_directory_failed()
        return
    list_search_results(emby, query)


def list_search_results(emby, query):
    if not query:
        end_directory_failed()
        return

    data  = emby.search(query)
    items = (data or {}).get('Items', [])

    if not items:
        notify(f'No results for "{query}"')
        end_directory_failed()
        return

    for item in items:
        iid   = item.get('Id', '')
        itype = item.get('Type', '')
        name  = item.get('Name', '')
        year  = item.get('ProductionYear', '')
        label = f'{name} ({year})' if year else name

        if itype == 'Episode':
            s = item.get('ParentIndexNumber', 0)
            e = item.get('IndexNumber', 0)
            show = item.get('SeriesName', '')
            label = f'{show} - S{s:02d}E{e:02d} - {name}'

        li = xbmcgui.ListItem(label)
        li.setArt({'thumb': emby.image_url(iid), 'poster': emby.image_url(iid)})
        tag = li.getVideoInfoTag()
        tag.setTitle(name)
        tag.setYear(int(year) if year else 0)
        tag.setPlot(item.get('Overview', ''))
        tag.setRating(float(item.get('CommunityRating') or 0))
        tag.setMediaType({'Movie': 'movie', 'Series': 'tvshow',
                          'Episode': 'episode'}.get(itype, 'video'))

        if itype in ('Movie', 'Episode'):
            li.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(HANDLE, plugin_url('PLAY', item_id=iid), li, False)
        elif itype == 'Series':
            xbmcplugin.addDirectoryItem(HANDLE, plugin_url('TV_SEASONS', series_id=iid), li, True)

    end_directory('videos', [xbmcplugin.SORT_METHOD_NONE])
