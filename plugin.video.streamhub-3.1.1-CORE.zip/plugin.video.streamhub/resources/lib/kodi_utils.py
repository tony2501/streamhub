"""
StreamHub - Kodi Utilities
Speed-optimised for Bingie skin widget loading.
"""

import os
import re
import sys
import time
import json
import threading
from urllib.parse import urlencode
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs

ADDON      = xbmcaddon.Addon()
HANDLE     = int(sys.argv[1]) if len(sys.argv) > 1 else -1
ADDON_ID   = 'plugin.video.streamhub'
BASE_URL   = sys.argv[0] if sys.argv else f'plugin://{ADDON_ID}'
PROFILE    = ADDON.getAddonInfo('profile')   # reuse ADDON — no second Addon()


# ------------------------------------------------------------------ #
# Logging
# ------------------------------------------------------------------ #

def log(msg, level=xbmc.LOGDEBUG):
    xbmc.log(f'[StreamHub] {msg}', level)


# ------------------------------------------------------------------ #
# Settings helpers
# ------------------------------------------------------------------ #

def get_setting(key, default=''):
    v = ADDON.getSetting(key)
    return v if v else default

def get_int(key, default=0):
    try:    return int(ADDON.getSetting(key))
    except: return default

def set_setting(key, value):
    ADDON.setSetting(key, str(value))

def get_bool(key, default=False):
    v = ADDON.getSetting(key).lower()
    if v == 'true':  return True
    if v == 'false': return False
    return default


# ------------------------------------------------------------------ #
# Resolution detection
# ------------------------------------------------------------------ #

def _stream_height(media_source):
    """
    Extract video height. Width checked first — anamorphic DV files can be
    3840 wide but only 1608 tall (scope crop).
    """
    # 1. Video stream Width
    for stream in media_source.get('MediaStreams', []):
        if stream.get('Type') == 'Video':
            w = stream.get('Width', 0)
            if w >= 3200: return 2160   # 4K: 3840, 3828 (anamorphic DV), 4096 (DCI)
            if w >= 1800: return 1080   # 1080p: 1920
            if w >= 1100: return 720    # 720p: 1280
            if w >     0: return 480

    # 2. Emby auto-generated Name: [WEBDL-2160p][HDR]...
    name = media_source.get('Name', '')
    if name:
        m = re.search(r'(2160|4320|1080|720|480|576|360)p', name.lower())
        if m: return int(m.group(1))
        if re.search(r'\b(4k|uhd)\b', name.lower()): return 2160

    # 3. Path/filename tokens
    path = media_source.get('Path', '')
    if path:
        s = path.lower()
        m = re.search(r'(2160|4320|1080|720|480|576|360)p', s)
        if m: return int(m.group(1))
        if re.search(r'\b(4k|uhd)\b', s): return 2160
        if re.search(r'\b(bluray|blu-ray|remux)\b', s): return 1080

    # 4. VideoStream Height fallback (may be < 2160 for anamorphic)
    for stream in media_source.get('MediaStreams', []):
        if stream.get('Type') == 'Video':
            h = stream.get('Height', 0)
            if h: return h

    # 5. Top-level MediaSource fields
    h = media_source.get('Height', 0)
    if h: return h
    w = media_source.get('Width', 0)
    if w >= 3200: return 2160
    if w >= 1800: return 1080
    if w >= 1100: return 720
    if w >     0: return 480
    return 0


def _height_to_label(h):
    if h >= 2160: return '4K UHD'
    if h >= 1080: return '1080p'
    if h >= 720:  return '720p'
    if h > 0:     return 'SD'
    return 'Unknown'


def get_resolution_label(media_source):
    return _height_to_label(_stream_height(media_source))





def _clean_version_label(media_source):
    res   = get_resolution_label(media_source)
    src   = ''
    hdr   = ''
    audio = ''
    name = media_source.get('Name', '')
    if name:
        nl = name.lower()
        for tag, label in [('remux', 'Remux'), ('webdl', 'WEB-DL'), ('web-dl', 'WEB-DL'),
                           ('webrip', 'WEBRip'), ('bluray', 'BluRay'), ('blu-ray', 'BluRay'),
                           ('hdtv', 'HDTV'), ('dvdrip', 'DVDRip')]:
            if tag in nl:
                src = label
                break
        if 'dv' in nl or 'dolby vision' in nl:
            hdr = 'Dolby Vision'
        elif 'hdr10plus' in nl or 'hdr10+' in nl:
            hdr = 'HDR10+'
        elif 'hdr' in nl:
            hdr = 'HDR'

    for stream in media_source.get('MediaStreams', []):
        if stream.get('Type') == 'Audio':
            audio = stream.get('DisplayTitle', '') or stream.get('Codec', '').upper()
            if len(audio) > 24:
                audio = audio[:24].rstrip() + '...'
            break

    parts = [p for p in [res, src, hdr, audio] if p]
    return '  |  '.join(parts) if parts else res


# ------------------------------------------------------------------ #
# Artwork helpers
# ------------------------------------------------------------------ #

def _get_art(item_dict, api):
    iid   = item_dict.get('Id', '')
    itype = item_dict.get('Type', '')
    use_tmdb = item_dict.get('_use_tmdb_art', False)

    if use_tmdb:
        poster  = item_dict.get('_tmdb_poster')  or api.image_url(iid)
        fanart  = item_dict.get('_tmdb_backdrop') or api.image_url(iid, 'Backdrop', 1920)
        clearlogo = ''
    else:
        poster    = api.image_url(iid)
        fanart    = api.image_url(iid, 'Backdrop', 1920)
        clearlogo = api.image_url(iid, 'Logo')

    # For episodes use series artwork as fanart/clearlogo
    if itype == 'Episode':
        sid = item_dict.get('SeriesId', '')
        if sid:
            fanart    = api.image_url(sid, 'Backdrop', 1920)
            clearlogo = api.image_url(sid, 'Logo')
        thumb = api.image_url(iid, 'Thumb', 500) or poster

        return {
            'thumb':     thumb,
            'poster':    api.image_url(sid) if sid else poster,
            'fanart':    fanart,
            'clearlogo': clearlogo,
        }

    return {
        'thumb':     poster,
        'poster':    poster,
        'fanart':    fanart,
        'clearlogo': clearlogo,
    }


# ------------------------------------------------------------------ #
# URL builder
# ------------------------------------------------------------------ #

def plugin_url(mode, **kw):
    params = {'mode': mode}
    params.update(kw)
    return f'{BASE_URL}?{urlencode(params)}'


# ------------------------------------------------------------------ #
# ListItem builders
# ------------------------------------------------------------------ #

def _badge_label(name, sources):
    """Append resolution badge when item has multiple MediaSources (rare — most
    multi-version content is stored as separate Emby items handled via _version_ids)."""
    if len(sources) <= 1:
        return name
    labels = sorted(set(get_resolution_label(ms) for ms in sources
                        if _stream_height(ms) >= 720), reverse=True)
    badge = ' / '.join(l for l in labels if l and l != 'Unknown')
    return f'{name}  [{badge}]' if badge else name


def add_media_item(item_dict, api):
    """
    Build a fully-tagged playable ListItem.
    Works for movies, episodes, and matcher-merged TMDB+Emby items.
    """
    iid     = item_dict.get('Id', '')
    itype   = item_dict.get('Type', 'Movie')
    sources = item_dict.get('MediaSources', [])
    name    = item_dict.get('Name', 'Unknown')
    label   = _badge_label(name, sources)

    li = xbmcgui.ListItem(label)
    li.setProperty('IsPlayable', 'true')
    li.setArt(_get_art(item_dict, api))

    tag = li.getVideoInfoTag()
    tag.setTitle(name)
    tag.setPlot(item_dict.get('Overview', ''))
    tag.setYear(int(item_dict.get('ProductionYear') or 0))
    tag.setRating(float(item_dict.get('CommunityRating') or 0))
    tag.setGenres(item_dict.get('Genres', []))
    tag.setTagLine(item_dict.get('Taglines', [''])[0] if item_dict.get('Taglines') else '')

    # Expose provider IDs so Bingie's info dialog and TMDbHelper can resolve
    # ratings, cast, and artwork without an extra network round-trip.
    pids = item_dict.get('ProviderIds', {})
    if pids:
        unique = {}
        if pids.get('Imdb'):   unique['imdb'] = pids['Imdb']
        if pids.get('Tmdb'):   unique['tmdb'] = pids['Tmdb']
        if pids.get('Tvdb'):   unique['tvdb'] = pids['Tvdb']
        if unique:
            tag.setUniqueIDs(unique, defaultuniqueid='imdb' if 'imdb' in unique else 'tmdb')

    # Runtime: Emby stores RunTimeTicks (100ns intervals)
    ticks = item_dict.get('RunTimeTicks', 0)
    if ticks:
        tag.setDuration(int(ticks / 10_000_000))

    rating_val = item_dict.get('OfficialRating', '')
    if rating_val:
        tag.setMpaa(rating_val)

    ud  = item_dict.get('UserData', {})
    pct = int(ud.get('PlayedPercentage') or 0)

    if itype == 'Movie':
        tag.setMediaType('movie')
        if pct > 0:
            resume_s = int(ud.get('PlaybackPositionTicks', 0) / 10_000_000)
            total_s  = int(ticks / 10_000_000)
            tag.setResumePoint(resume_s, total_s)

    elif itype == 'Episode':
        tag.setMediaType('episode')
        tag.setTvShowTitle(item_dict.get('SeriesName', ''))
        tag.setSeason(item_dict.get('ParentIndexNumber', 0))
        tag.setEpisode(item_dict.get('IndexNumber', 0))
        if pct > 0:
            resume_s = int(ud.get('PlaybackPositionTicks', 0) / 10_000_000)
            total_s  = int(ticks / 10_000_000)
            tag.setResumePoint(resume_s, total_s)
    else:
        tag.setMediaType('video')

    is_fav = ud.get('IsFavorite', False)
    fav_lbl = 'Remove from Favourites' if is_fav else 'Add to Favourites'
    li.addContextMenuItems([
        (fav_lbl, f'RunPlugin({plugin_url("TOGGLE_FAVOURITE", item_id=iid, is_fav=str(is_fav).lower())})'),
        ('Settings', f'RunPlugin({plugin_url("SHOW_SETTINGS")})'),
    ])

    # Stash version IDs in window so play_item can offer picker at play time.
    version_ids = item_dict.get('_version_ids', [])
    if version_ids:
        xbmcgui.Window(10000).setProperty(f'EmbyVER_{iid}', json.dumps(version_ids))
    elif sources:
        xbmcgui.Window(10000).setProperty(f'EmbyMS_{iid}', json.dumps(sources))

    xbmcplugin.addDirectoryItem(HANDLE, plugin_url('PLAY', item_id=iid), li, False)


# ------------------------------------------------------------------ #
# Directory helpers
# ------------------------------------------------------------------ #

def add_dir_item(label, mode, icon='DefaultFolder.png', fanart='',
                 is_folder=True, run_plugin=False, **kw):
    li = xbmcgui.ListItem(label)
    art = {'icon': icon, 'thumb': icon}
    if fanart:
        art['fanart'] = fanart
    li.setArt(art)
    xbmcplugin.addDirectoryItem(HANDLE, plugin_url(mode, **kw), li, is_folder)


def end_directory(content='movies', sort_methods=None, cache=True):
    xbmcplugin.setContent(HANDLE, content)
    for sm in (sort_methods or [xbmcplugin.SORT_METHOD_NONE]):
        xbmcplugin.addSortMethod(HANDLE, sm)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=cache)


def end_directory_failed():
    xbmcplugin.endOfDirectory(HANDLE, succeeded=False)


# ------------------------------------------------------------------ #
# Notifications / keyboard
# ------------------------------------------------------------------ #

def notify(msg, icon=xbmcgui.NOTIFICATION_INFO, duration=4000, ms=None):
    xbmcgui.Dialog().notification('StreamHub', msg, icon, ms if ms is not None else duration)


def keyboard_input(heading='', default=''):
    kb = xbmc.Keyboard(default, heading)
    kb.doModal()
    if kb.isConfirmed():
        return kb.getText().strip()
    return ''

def dialog_ok(heading, msg):
    xbmcgui.Dialog().ok(heading, msg)

def yesno_dialog(heading, msg):
    return xbmcgui.Dialog().yesno(heading, msg)


# ------------------------------------------------------------------ #
# Cache  —  memory-first, async disk write
# ------------------------------------------------------------------ #

_cache_file   = os.path.join(PROFILE, 'emby_cache.json')
_mem          = {}
_disk_lock    = threading.Lock()
_flush_timer  = None   # debounce: only one flush scheduled at a time


def _ensure_dir():
    if not xbmcvfs.exists(PROFILE):
        xbmcvfs.mkdirs(PROFILE)


def _flush_disk():
    """Write _mem to disk."""
    with _disk_lock:
        try:
            _ensure_dir()
            now = time.time()
            snapshot = {k: v for k, v in list(_mem.items()) if now < v.get('x', 0)}
            with xbmcvfs.File(_cache_file, 'w') as f:
                f.write(json.dumps(snapshot))
        except Exception as e:
            log(f'Cache flush: {e}', xbmc.LOGWARNING)


def _schedule_flush():
    """Debounce: schedule one flush 2s from now, cancel any pending one."""
    global _flush_timer
    if _flush_timer is not None:
        _flush_timer.cancel()
    _flush_timer = threading.Timer(2.0, _flush_disk)
    _flush_timer.daemon = True
    _flush_timer.start()


_disk_loaded = False


def _load_disk():
    """Load disk cache into _mem (called once on first miss)."""
    _ensure_dir()
    if not xbmcvfs.exists(_cache_file):
        return
    try:
        with xbmcvfs.File(_cache_file, 'r') as f:
            disk = json.loads(f.read() or '{}')
        now = time.time()
        for k, v in disk.items():
            if now < v.get('x', 0) and k not in _mem:
                _mem[k] = v
    except Exception as e:
        log(f'Cache load: {e}', xbmc.LOGWARNING)


def cache_get(key):
    global _disk_loaded
    e = _mem.get(key)
    if e:
        if time.time() < e['x']:
            return e['d']
        del _mem[key]
    if not _disk_loaded:
        _disk_loaded = True
        _load_disk()
        e = _mem.get(key)
        if e and time.time() < e['x']:
            return e['d']
    return None


def cache_set(key, data, ttl=300):
    _mem[key] = {'d': data, 'x': time.time() + ttl}
    _schedule_flush()


def cache_delete(key):
    _mem.pop(key, None)
    _schedule_flush()


def cache_clear():
    _mem.clear()
    _ensure_dir()
    try:
        with xbmcvfs.File(_cache_file, 'w') as f:
            f.write('{}')
    except Exception:
        pass


# ------------------------------------------------------------------ #
# IPTV Recently Watched channels
# Stored with a 30-day TTL so they survive Kodi restarts.
# Each entry: {'stream_id': str, 'name': str, 'icon': str, 'ts': float}
# ------------------------------------------------------------------ #

_IPTV_RECENTS_KEY = 'iptv_recents_v1'
_IPTV_RECENTS_MAX = 10
_IPTV_RECENTS_TTL = 30 * 86400  # 30 days


def iptv_recents_add(stream_id, name, icon=''):
    """Record a channel play in the recently-watched list."""
    recents = iptv_recents_get()
    # Remove existing entry for this channel (dedup + move to front)
    recents = [r for r in recents if str(r.get('stream_id', '')) != str(stream_id)]
    recents.insert(0, {
        'stream_id': str(stream_id),
        'name':      name,
        'icon':      icon,
        'ts':        time.time(),
    })
    recents = recents[:_IPTV_RECENTS_MAX]
    cache_set(_IPTV_RECENTS_KEY, recents, _IPTV_RECENTS_TTL)


def iptv_recents_get():
    """Return list of recently-watched channels, newest first."""
    return cache_get(_IPTV_RECENTS_KEY) or []


# ------------------------------------------------------------------ #
# RD Continue Watching
# Stores progress for items played via Real-Debrid (not in Emby).
# Each entry: {
#   'key':        unique id (imdb_id + optional S/E),
#   'imdb_id':    str,
#   'media_type': 'movie' | 'series',
#   'season':     int or None,
#   'episode':    int or None,
#   'title':      str,
#   'series_title': str,
#   'thumb':      str (URL),
#   'fanart':     str (URL),
#   'year':       int,
#   'duration':   int (seconds),
#   'position':   int (seconds),
#   'pct':        float (0-100),
#   'ts':         float (unix timestamp of last play),
# }
# ------------------------------------------------------------------ #

_RD_PROGRESS_KEY = 'rd_continue_watching_v1'
_RD_PROGRESS_MAX = 25
_RD_PROGRESS_TTL = 30 * 86400  # 30 days


def rd_progress_update(key, position, duration, metadata=None):
    """Update or create a RD continue-watching entry."""
    entries = rd_progress_get_all()
    pct = (position / duration * 100) if duration else 0

    # Remove if completed (>95%) or nearly not started (<2%)
    if pct > 95:
        entries = [e for e in entries if e.get('key') != key]
        cache_set(_RD_PROGRESS_KEY, entries, _RD_PROGRESS_TTL)
        return

    # Find existing or create new
    existing = next((e for e in entries if e.get('key') == key), None)
    if existing:
        existing['position'] = int(position)
        existing['pct']      = round(pct, 1)
        existing['ts']       = time.time()
        if metadata:
            existing.update(metadata)
    else:
        if pct < 2:
            return  # Don't save barely-started items
        entry = {
            'key':      key,
            'position': int(position),
            'pct':      round(pct, 1),
            'ts':       time.time(),
        }
        if metadata:
            entry.update(metadata)
        entries = [e for e in entries if e.get('key') != key]
        entries.insert(0, entry)

    entries = sorted(entries, key=lambda e: -e.get('ts', 0))[:_RD_PROGRESS_MAX]
    cache_set(_RD_PROGRESS_KEY, entries, _RD_PROGRESS_TTL)


def rd_progress_get_all():
    """Return all RD in-progress entries, newest first."""
    return cache_get(_RD_PROGRESS_KEY) or []


def rd_progress_get(key):
    """Return a single RD progress entry by key, or None."""
    return next((e for e in rd_progress_get_all() if e.get('key') == key), None)


def rd_progress_remove(key):
    """Remove a RD progress entry (e.g. on completion)."""
    entries = [e for e in rd_progress_get_all() if e.get('key') != key]
    cache_set(_RD_PROGRESS_KEY, entries, _RD_PROGRESS_TTL)
