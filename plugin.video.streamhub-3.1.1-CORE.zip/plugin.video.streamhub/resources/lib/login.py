"""
StreamHub - Login Wizard
Step-by-step in-menu login for Emby + optional TMDB API key + Xtream IPTV.
"""
import xbmc, xbmcgui, xbmcaddon
from resources.lib.kodi_utils import (
    log, get_setting, set_setting, keyboard_input, dialog_ok, notify, yesno_dialog
)


def run_login_wizard():
    dialog = xbmcgui.Dialog()

    # ── Step 1: Emby Server URL ──────────────────────────────────────
    current = get_setting('emby_server') or 'http://192.168.1.x:8096'
    server  = keyboard_input('Step 1 of 3  —  Emby Server URL', current)
    if not server:
        return
    if not server.startswith('http'):
        server = 'http://' + server

    # ── Step 2: Emby Username ────────────────────────────────────────
    username = keyboard_input('Step 2 of 3  —  Emby Username',
                              get_setting('emby_username') or '')
    if not username:
        return

    # ── Step 3: Emby Password ────────────────────────────────────────
    kb = xbmc.Keyboard('', 'Step 3 of 3  —  Emby Password')
    kb.setHiddenInput(True)
    kb.doModal()
    if not kb.isConfirmed():
        return
    password = kb.getText()

    prog = xbmcgui.DialogProgress()
    prog.create('StreamHub', 'Connecting to Emby...')
    prog.update(50)

    try:
        from resources.lib.emby_client import EmbyClient
        token, user_id, uname = EmbyClient.login(server, username, password)
        prog.update(100)
        prog.close()
        log(f'Emby login OK: {uname} @ {server}', xbmc.LOGINFO)

        # ── Optional: TMDB API key ───────────────────────────────────
        tmdb_key = get_setting('tmdb_api_key')
        if not tmdb_key:
            if yesno_dialog(
                'StreamHub  —  Connected!',
                f'Logged in as [B]{uname}[/B]\n\n'
                'Add a free TMDB API key to enable Popular, Trending and Top Rated lists?\n'
                '(Get one free at themoviedb.org/settings/api)'
            ):
                key = keyboard_input('Enter TMDB API Key')
                if key:
                    xbmcaddon.Addon().setSetting('tmdb_api_key', key.strip())
                    notify('TMDB API key saved!')
        else:
            dialog_ok('StreamHub  —  Connected!',
                      f'Logged in as [B]{uname}[/B]\nServer: {server}')

        # ── Optional: Xtream IPTV setup ──────────────────────────────
        xtream_server = get_setting('xtream_server')
        if not xtream_server:
            if yesno_dialog(
                'StreamHub  —  IPTV Setup',
                'Do you want to set up Xtream Codes IPTV for Live TV?\n\n'
                'You can also do this later from the IPTV menu.'
            ):
                _run_xtream_wizard()
        
        xbmc.executebuiltin('Container.Refresh')

    except Exception as e:
        prog.close()
        log(f'Login failed: {e}', xbmc.LOGERROR)
        dialog_ok('StreamHub  —  Login Failed',
                  f'Could not connect.\n\nError: {e}\n\nCheck your server URL and credentials.')


def run_xtream_wizard():
    """Public entry point — called from IPTV Setup menu item."""
    _run_xtream_wizard()
    xbmc.executebuiltin('Container.Refresh')


def _run_xtream_wizard():
    """Inner Xtream login wizard — shared by main wizard and standalone setup."""
    
    # Server URL
    current = get_setting('xtream_server') or 'http://yourprovider.com:8080'
    server  = keyboard_input('Xtream IPTV  —  Step 1 of 3  —  Server URL', current)
    if not server:
        return False
    if not server.startswith('http'):
        server = 'http://' + server
    server = server.rstrip('/')

    # Username
    username = keyboard_input('Xtream IPTV  —  Step 2 of 3  —  Username',
                              get_setting('xtream_username') or '')
    if not username:
        return False

    # Password
    kb = xbmc.Keyboard('', 'Xtream IPTV  —  Step 3 of 3  —  Password')
    kb.setHiddenInput(True)
    kb.doModal()
    if not kb.isConfirmed():
        return False
    password = kb.getText()

    # Test credentials
    prog = xbmcgui.DialogProgress()
    prog.create('StreamHub', 'Connecting to Xtream IPTV...')
    prog.update(50)

    try:
        from resources.lib.xtream_client import XtreamClient
        tmp = XtreamClient.__new__(XtreamClient)
        tmp.server   = server
        tmp.username = username
        tmp.password = password
        result = XtreamClient.authenticate(tmp, server, username, password)
        prog.update(100)
        prog.close()

        if not result:
            dialog_ok('Xtream IPTV  —  Failed',
                      'Could not connect. Check your server URL, username and password.')
            return False

        # Save credentials
        a = xbmcaddon.Addon()
        a.setSetting('xtream_server',   server)
        a.setSetting('xtream_username', username)
        a.setSetting('xtream_password', password)

        # Show account info
        ui   = result.get('user_info', {})
        si   = result.get('server_info', {})
        exp  = ui.get('exp_date', 'Unknown')
        conns = ui.get('max_connections', '?')
        notify(f'IPTV Connected  —  Expires: {exp}  |  Max connections: {conns}')
        log(f'Xtream login OK: {username} @ {server}', xbmc.LOGINFO)
        return True

    except Exception as e:
        prog.close()
        log(f'Xtream login error: {e}', xbmc.LOGERROR)
        dialog_ok('Xtream IPTV  —  Error', f'Connection error:\n{e}')
        return False


def run_rd_auth():
    """
    Real-Debrid open-source device OAuth flow.
    Step 1: Get device_code + user_code via /device/code
    Step 2: Show user the code — they go to real-debrid.com/device
    Step 3: Poll /device/credentials to get per-user client_id + client_secret
    Step 4: Exchange for access_token via /token
    """
    import time
    from urllib.request import urlopen, Request
    from urllib.parse import urlencode
    import json

    # Open-source app client ID (public, from RD docs)
    RD_CLIENT_ID   = 'X245A4XAIBGVM'
    RD_DEVICE_CODE = 'https://api.real-debrid.com/oauth/v2/device/code'
    RD_CREDENTIALS = 'https://api.real-debrid.com/oauth/v2/device/credentials'
    RD_TOKEN       = 'https://api.real-debrid.com/oauth/v2/token'

    prog = xbmcgui.DialogProgress()
    prog.create('StreamHub  —  Real-Debrid', 'Requesting device code...')
    prog.update(10)

    try:
        # Step 1: Get device code
        req = Request(
            f'{RD_DEVICE_CODE}?{urlencode({"client_id": RD_CLIENT_ID, "new_credentials": "yes"})}',
            headers={'Accept': 'application/json'}
        )
        with urlopen(req, timeout=15) as r:
            data = json.loads(r.read())

        device_code      = data.get('device_code', '')
        user_code        = data.get('user_code', '')
        verification_url = data.get('verification_url', 'https://real-debrid.com/device')
        interval         = int(data.get('interval', 5))
        expires_in       = int(data.get('expires_in', 600))

        if not device_code or not user_code:
            prog.close()
            dialog_ok('Real-Debrid  —  Error', 'Could not get device code from Real-Debrid.')
            return

        prog.close()

        # Step 2: Show code to user
        dialog_ok(
            'Real-Debrid  —  Authorise',
            f'1. Open  [B]{verification_url}[/B]  in a browser\n'
            f'2. Enter code:  [B][COLOR gold]{user_code}[/COLOR][/B]\n\n'
            f'Then press OK here to continue.'
        )

        # Step 3: Poll /device/credentials for per-user client_id + client_secret
        prog2 = xbmcgui.DialogProgress()
        prog2.create('Real-Debrid', 'Waiting for authorisation...\n\nPress Cancel to abort.')

        deadline   = time.time() + expires_in
        pct        = 0
        client_id  = None
        client_secret = None

        while time.time() < deadline:
            if prog2.iscanceled():
                prog2.close()
                notify('Real-Debrid linking cancelled')
                return

            time.sleep(interval)
            pct = min(pct + 5, 90)
            prog2.update(pct, 'Waiting for authorisation...\nMake sure you entered the code at real-debrid.com/device')

            try:
                cred_req = Request(
                    f'{RD_CREDENTIALS}?{urlencode({"client_id": RD_CLIENT_ID, "code": device_code})}',
                    headers={'Accept': 'application/json'}
                )
                with urlopen(cred_req, timeout=15) as cr:
                    cred_data = json.loads(cr.read())

                client_id     = cred_data.get('client_id', '')
                client_secret = cred_data.get('client_secret', '')

                if client_id and client_secret:
                    break  # Got credentials, proceed to token exchange

            except Exception as e:
                # 403 = pending (user hasn't authorized yet) — keep polling
                if '403' not in str(e):
                    log(f'RD credentials poll error: {e}', xbmc.LOGWARNING)

        prog2.close()

        if not client_id or not client_secret:
            dialog_ok('Real-Debrid  —  Timed Out',
                      'The code expired before authorisation was confirmed.\nPlease try again.')
            return

        # Step 4: Exchange credentials + device_code for access token
        prog3 = xbmcgui.DialogProgress()
        prog3.create('Real-Debrid', 'Getting access token...')
        prog3.update(80)

        token_req = Request(
            RD_TOKEN,
            data=urlencode({
                'client_id':     client_id,
                'client_secret': client_secret,
                'code':          device_code,
                'grant_type':    'http://oauth.net/grant_type/device/1.0',
            }).encode(),
            headers={
                'Content-Type': 'application/x-www-form-urlencoded',
                'Accept':       'application/json',
            },
            method='POST'
        )
        with urlopen(token_req, timeout=15) as tr:
            token_data = json.loads(tr.read())

        prog3.close()

        access_token  = token_data.get('access_token', '')
        refresh_token = token_data.get('refresh_token', '')

        if not access_token:
            dialog_ok('Real-Debrid  —  Error',
                      f'Token exchange failed: {token_data.get("error", "Unknown error")}')
            return

        # Save everything
        a = xbmcaddon.Addon()
        a.setSetting('rd_access_token',  access_token)
        a.setSetting('rd_refresh_token', refresh_token)
        a.setSetting('rd_client_id',     client_id)
        a.setSetting('rd_client_secret', client_secret)
        a.setSetting('rd_api_key',       access_token)

        log('Real-Debrid OAuth: linked successfully', xbmc.LOGINFO)
        dialog_ok('Real-Debrid  —  Linked!',
                  'Your Real-Debrid account is now connected.\n\n'
                  'RD sources will appear in the quality picker when available.')
        xbmc.executebuiltin('Container.Refresh')

    except Exception as e:
        try: prog.close()
        except: pass
        try: prog2.close()
        except: pass
        log(f'RD device auth error: {e}', xbmc.LOGERROR)
        dialog_ok('Real-Debrid  —  Error', f'Could not complete authorisation:\n{e}')


def do_rd_unlink():
    if not yesno_dialog('Real-Debrid  —  Unlink', 'Remove your Real-Debrid account?'):
        return
    a = xbmcaddon.Addon()
    for key in ('rd_api_key', 'rd_access_token', 'rd_refresh_token', 'rd_client_id', 'rd_client_secret'):
        a.setSetting(key, '')
    notify('Real-Debrid unlinked')
    xbmc.executebuiltin('Container.Refresh')


def do_logout():
    if not yesno_dialog('StreamHub  —  Log Out', 'Are you sure you want to log out?'):
        return
    a = xbmcaddon.Addon()
    for key in ('emby_server', 'emby_token', 'emby_user_id', 'emby_username'):
        a.setSetting(key, '')
    notify('Logged out from Emby')
    xbmc.executebuiltin('Container.Refresh')


def do_iptv_logout():
    if not yesno_dialog('StreamHub  —  IPTV Log Out', 'Remove Xtream IPTV credentials?'):
        return
    a = xbmcaddon.Addon()
    for key in ('xtream_server', 'xtream_username', 'xtream_password'):
        a.setSetting(key, '')
    notify('IPTV credentials removed')
    xbmc.executebuiltin('Container.Refresh')
