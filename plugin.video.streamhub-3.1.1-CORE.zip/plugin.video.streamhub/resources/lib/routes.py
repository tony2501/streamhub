"""
StreamHub - Route dispatcher
"""
import xbmc
import xbmcgui
from resources.lib.kodi_utils import log, end_directory_failed, notify


def _dispatch_iptv(mode, params):
    """Handle IPTV routes without requiring Emby login."""
    from resources.lib.xtream_client import XtreamClient
    xtream = XtreamClient()

    if mode == 'IPTV_MENU':
        from resources.lib.iptv_listings import iptv_menu
        iptv_menu(xtream)
    elif mode == 'IPTV_SETUP':
        from resources.lib.login import run_xtream_wizard
        run_xtream_wizard()
    elif mode == 'IPTV_LOGOUT':
        from resources.lib.login import do_iptv_logout
        do_iptv_logout()
    elif mode == 'IPTV_LIVE_CATS':
        from resources.lib.iptv_listings import list_live_categories
        list_live_categories(xtream)
    elif mode == 'IPTV_LIVE_STREAMS':
        from resources.lib.iptv_listings import list_live_streams
        list_live_streams(xtream, params.get('category_id'))
    elif mode == 'IPTV_PLAY':
        from resources.lib.iptv_listings import play_live_stream
        play_live_stream(xtream, params.get('stream_id', ''),
                         name=params.get('name', ''),
                         icon=params.get('icon', ''),
                         use_ts=params.get('use_ts', '0') == '1')
    elif mode == 'IPTV_RECENTS':
        from resources.lib.listings import list_iptv_recents
        list_iptv_recents()


def dispatch(mode, params):
    log(f'dispatch mode={mode}', xbmc.LOGDEBUG)

    # ---- No auth needed ----
    if mode == 'LOGIN_WIZARD':
        from resources.lib.login import run_login_wizard
        run_login_wizard(); return
    if mode == 'LOGOUT':
        from resources.lib.login import do_logout
        do_logout(); return
    if mode == 'SHOW_SETTINGS':
        import xbmcaddon
        xbmcaddon.Addon().openSettings(); return
    if mode == 'CLEAR_CACHE':
        from resources.lib.kodi_utils import cache_clear
        cache_clear()
        notify('Cache cleared')
        xbmc.executebuiltin('Container.Refresh'); return
    if mode == 'RD_LINK':
        from resources.lib.login import run_rd_auth
        run_rd_auth(); return
    if mode == 'RD_UNLINK':
        from resources.lib.login import do_rd_unlink
        do_rd_unlink(); return
    if mode == 'MAIN_MENU':
        from resources.lib.menus import show_main_menu
        show_main_menu(); return

    # ── IPTV modes don't require Emby login ────────────────────────────
    if mode in ('IPTV_MENU', 'IPTV_SETUP', 'IPTV_LOGOUT',
                'IPTV_LIVE_CATS', 'IPTV_LIVE_STREAMS', 'IPTV_PLAY', 'IPTV_PLAY_TS',
                'IPTV_RECENTS'):
        _dispatch_iptv(mode, params)
        return

    # ---- Requires Emby login ----
    from resources.lib.emby_client import EmbyClient
    emby = EmbyClient()
    if not emby.is_configured():
        notify('Please log in to Emby first', xbmcgui.NOTIFICATION_WARNING)
        from resources.lib.menus import show_main_menu
        show_main_menu(); return

    # TMDB client (optional — graceful fallback if no API key)
    from resources.lib.tmdb_api import TMDbAPI
    tmdb = TMDbAPI()

    from resources.lib.listings import (
        list_continue_watching,
        # TMDB-matched discovery
        list_movies_popular, list_movies_trending, list_movies_top_rated,
        list_movies_now_playing, list_movies_upcoming,
        list_shows_popular, list_shows_trending, list_shows_top_rated,
        list_shows_on_air, list_shows_airing_today,
        # Pure-Emby library
        list_movies_data, list_movies_paged,
        list_shows_data, list_shows_paged,
        list_seasons, list_episodes,
        list_genres, list_studios, list_years,
        do_search, list_search_results,
    )

    # ── Continue Watching ───────────────────────────────────────────────
    if mode == 'CONTINUE_WATCHING':
        list_continue_watching(emby)

    # ── Movies ──────────────────────────────────────────────────────────
    elif mode == 'MOVIES_MENU':
        from resources.lib.menus import show_movies_menu
        show_movies_menu()

    elif mode == 'MOVIES_POPULAR':
        list_movies_popular(emby, tmdb)
    elif mode == 'MOVIES_TRENDING':
        list_movies_trending(emby, tmdb)
    elif mode == 'MOVIES_TOP_RATED':
        list_movies_top_rated(emby, tmdb)
    elif mode == 'MOVIES_NOW_PLAYING':
        list_movies_now_playing(emby, tmdb)
    elif mode == 'MOVIES_UPCOMING':
        list_movies_upcoming(emby, tmdb)

    elif mode == 'MOVIES_RECENTLY_ADDED':
        list_movies_data(emby.movies_recently_added(), emby)
    elif mode == 'MOVIES_IN_PROGRESS':
        list_movies_data(emby.movies_in_progress(), emby)
    elif mode == 'MOVIES_FAVOURITES':
        list_movies_data(emby.movies_favourites(), emby)
    elif mode == 'MOVIES_RANDOM':
        list_movies_data(emby.movies_random(), emby)
    elif mode == 'MOVIES_UNWATCHED':
        list_movies_paged(emby, params, unwatched=True)
    elif mode == 'MOVIES_ALL':
        list_movies_paged(emby, params)
    elif mode == 'MOVIES_GENRES':
        list_genres(emby.movie_genres(), 'MOVIES_BY_GENRE')
    elif mode == 'MOVIES_BY_GENRE':
        list_movies_paged(emby, params, genre=params.get('genre'))
    elif mode == 'MOVIES_STUDIOS':
        list_studios(emby.movie_studios())
    elif mode == 'MOVIES_BY_STUDIO':
        list_movies_paged(emby, params, studio=params.get('studio'))
    elif mode == 'MOVIES_YEARS':
        list_years(emby.movie_years())
    elif mode == 'MOVIES_BY_YEAR':
        list_movies_paged(emby, params, year=params.get('year'))

    # ── TV Shows ─────────────────────────────────────────────────────────
    elif mode == 'TV_MENU':
        from resources.lib.menus import show_tv_menu
        show_tv_menu()

    elif mode == 'TV_POPULAR':
        list_shows_popular(emby, tmdb)
    elif mode == 'TV_TRENDING':
        list_shows_trending(emby, tmdb)
    elif mode == 'TV_TOP_RATED':
        list_shows_top_rated(emby, tmdb)
    elif mode == 'TV_ON_AIR':
        list_shows_on_air(emby, tmdb)
    elif mode == 'TV_AIRING_TODAY':
        list_shows_airing_today(emby, tmdb)

    elif mode == 'TV_NEXT_UP':
        list_episodes(emby.next_up(), emby)
    elif mode == 'TV_RECENTLY_ADDED':
        list_episodes(emby.shows_recently_added(), emby)
    elif mode == 'TV_IN_PROGRESS':
        list_episodes(emby.shows_in_progress(), emby)
    elif mode == 'TV_FAVOURITES':
        list_shows_data(emby.shows_favourites(), emby)
    elif mode == 'TV_UNWATCHED':
        list_shows_paged(emby, params, unwatched=True)
    elif mode == 'TV_ALL':
        list_shows_paged(emby, params)
    elif mode == 'TV_GENRES':
        list_genres(emby.show_genres(), 'TV_BY_GENRE')
    elif mode == 'TV_BY_GENRE':
        list_shows_paged(emby, params, genre=params.get('genre'))
    elif mode == 'TV_SEASONS':
        list_seasons(emby, params.get('series_id', ''))
    elif mode == 'TV_EPISODES':
        data = emby.episodes(params.get('series_id', ''), params.get('season_id', ''))
        list_episodes(data, emby)

    # ── Bingie Widget Routes ─────────────────────────────────────────────
    # Dedicated fast endpoints for Bingie skin home screen rows.
    # All use slim widget fields (_pw) + in-memory+disc cache so Bingie
    # renders rows instantly from cache on every home screen visit.
    elif mode == 'WIDGET_CONTINUE_WATCHING':
        from resources.lib.listings import list_continue_watching
        list_continue_watching(emby)
    elif mode == 'WIDGET_MOVIES_RECENT':
        from resources.lib.listings import list_movies_data
        list_movies_data(emby.movies_recently_added(limit=20), emby, widget=True)
    elif mode == 'WIDGET_MOVIES_INPROGRESS':
        from resources.lib.listings import list_movies_data
        list_movies_data(emby.movies_in_progress(limit=20), emby, widget=True)
    elif mode == 'WIDGET_SHOWS_RECENT':
        from resources.lib.listings import list_shows_data
        list_shows_data(emby.shows_recently_added(limit=20), emby, widget=True)
    elif mode == 'WIDGET_SHOWS_INPROGRESS':
        from resources.lib.listings import list_episodes
        list_episodes(emby.shows_in_progress(limit=20), emby, widget=True)
    elif mode == 'WIDGET_MOVIES_POPULAR':
        from resources.lib.listings import list_movies_data
        list_movies_data(emby.movies_popular(limit=20, widget=True), emby, widget=True)
    elif mode == 'WIDGET_MOVIES_TOPRATED':
        from resources.lib.listings import list_movies_data
        list_movies_data(emby.movies_top_rated(limit=20, widget=True), emby, widget=True)
    # ── Search ───────────────────────────────────────────────────────────
    elif mode == 'NEW_SEARCH':
        do_search(emby)
    elif mode == 'SEARCH_RESULTS':
        list_search_results(emby, params.get('query', ''))

    # ── Playback ─────────────────────────────────────────────────────────
    elif mode == 'PLAY':
        from resources.lib.player import play_item
        play_item(emby, params.get('item_id', ''))

    # ── TMDbHelper / Bingie player entry point ────────────────────────────
    # Called by streamhub.json player file via TMDbHelper.
    # Receives tmdb_id + media_type (movie/tv) + optional season/episode.
    # Looks up the matching Emby item and plays best quality version.
    elif mode == 'TMDB_PLAY':
        from resources.lib.player import play_by_tmdb_id
        play_by_tmdb_id(
            emby,
            tmdb_id=params.get('tmdb_id', ''),
            media_type=params.get('media_type', 'movie'),
            season=params.get('season', ''),
            episode=params.get('episode', ''),
        )

    # ── Utility ──────────────────────────────────────────────────────────
    elif mode == 'TOGGLE_FAVOURITE':
        iid    = params.get('item_id', '')
        is_fav = params.get('is_fav', 'false') == 'true'
        emby.toggle_favourite(iid, not is_fav)
        notify('Removed from Favourites' if is_fav else 'Added to Favourites', ms=2000)
        xbmc.executebuiltin('Container.Refresh')
    elif mode == 'MARK_WATCHED':
        emby.mark_watched(params.get('item_id', ''))
        notify('Marked as Watched', ms=2000)
        xbmc.executebuiltin('Container.Refresh')

    else:
        log(f'Unknown mode: {mode}', xbmc.LOGWARNING)
        end_directory_failed()
