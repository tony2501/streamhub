"""
StreamHub - Xtream Codes IPTV Client
"""

import json
import re
import base64
import threading
import xbmc
from urllib.request import Request, urlopen
from urllib.parse import urlencode
from urllib.error import HTTPError, URLError

from resources.lib.kodi_utils import (
    log, get_setting, set_setting, cache_get, cache_set
)

_TTL_CATS    = 3600
_TTL_STREAMS = 1800
_TTL_EPG     = 600
_TTL_EPG_FAIL = 300   # cache 503/failure for 5 min so we stop hammering


def _decode_epg_str(s):
    if not s:
        return ''
    try:
        decoded = base64.b64decode(s).decode('utf-8', errors='replace').strip()
        if decoded and all(32 <= ord(c) < 127 or c in '\n\r\t' for c in decoded[:50]):
            return decoded
    except Exception:
        pass
    return s.strip()


class XtreamClient:

    def __init__(self):
        self.server   = (get_setting('xtream_server', '') or 'http://88871-itself.tx-4kott.com').rstrip('/')
        self.username = get_setting('xtream_username', '') or 'u2ox8anuc2'
        self.password = get_setting('xtream_password', '') or '6295ee6d02'

    def is_configured(self):
        return bool(self.server and self.username and self.password)

    def authenticate(self, server, username, password):
        url = f'{server.rstrip("/")}/player_api.php?username={username}&password={password}'
        try:
            req = Request(url, headers={'User-Agent': 'Kodi/21 StreamHub'})
            with urlopen(req, timeout=10) as r:
                data = json.loads(r.read())
            if data.get('user_info', {}).get('auth') == 1:
                return data
        except Exception as e:
            log(f'Xtream auth error: {e}', xbmc.LOGWARNING)
        return None

    def _api(self, action, extra_params=None, ck=None, ttl=300, timeout=15):
        if ck:
            cached = cache_get(ck)
            if cached is not None:
                return cached
        params = {'username': self.username, 'password': self.password, 'action': action}
        if extra_params:
            params.update(extra_params)
        url = f'{self.server}/player_api.php?{urlencode(params)}'
        try:
            req = Request(url, headers={'User-Agent': 'Kodi/21 StreamHub'})
            with urlopen(req, timeout=timeout) as r:
                data = json.loads(r.read())
            if ck:
                cache_set(ck, data, ttl)
            return data
        except HTTPError as e:
            log(f'Xtream HTTP {e.code} {action}: {e.reason}', xbmc.LOGWARNING)
            raise
        except URLError as e:
            log(f'Xtream URLError {action}: {e.reason}', xbmc.LOGWARNING)
            raise
        except Exception as e:
            log(f'Xtream error {action}: {e}', xbmc.LOGWARNING)
            raise

    def play_url(self, stream_id, prefer_ts=False):
        ext = 'ts' if prefer_ts else 'm3u8'
        return f'{self.server}/live/{self.username}/{self.password}/{stream_id}.{ext}'

    def get_live_categories(self):
        return self._api('get_live_categories', ck='xt_live_cats', ttl=_TTL_CATS) or []

    def get_live_streams(self, category_id=None):
        ck = f'xt_live_streams_{category_id or "all"}'
        extra = {'category_id': category_id} if category_id else {}
        return self._api('get_live_streams', extra, ck=ck, ttl=_TTL_STREAMS) or []

    # ---------------------------------------------------------------- #
    # EPG — with availability caching so 503 providers are skipped fast
    # ---------------------------------------------------------------- #

    def _epg_available(self):
        """
        Returns False if we've already seen a 503/failure from this provider
        within the last 5 minutes. Avoids hammering a dead EPG endpoint.
        """
        fail_ck = f'xt_epg_fail_{self.server}'
        return cache_get(fail_ck) is None

    def _mark_epg_failed(self):
        fail_ck = f'xt_epg_fail_{self.server}'
        cache_set(fail_ck, True, _TTL_EPG_FAIL)

    def get_epg_for_stream(self, stream_id):
        """
        Fetch Now/Next EPG for a single stream_id.
        Returns list of up to 2 dicts: [{title, description, start, end}, ...]
        Returns [] silently if EPG is known to be unavailable.
        """
        if not self._epg_available():
            return []

        ck = f'xt_epg_{stream_id}'
        cached = cache_get(ck)
        if cached is not None:
            return cached

        try:
            data = self._api('get_short_epg',
                             {'stream_id': str(stream_id), 'limit': 2},
                             timeout=3)   # short timeout per stream
            listings = (data or {}).get('epg_listings', [])
            result = []
            for entry in listings[:2]:
                result.append({
                    'title':       _decode_epg_str(entry.get('title', '')),
                    'description': _decode_epg_str(entry.get('description', '')),
                    'start':       entry.get('start', ''),
                    'end':         entry.get('end', ''),
                })
            cache_set(ck, result, _TTL_EPG)
            return result

        except (HTTPError, URLError, Exception) as e:
            # 503 or any error: mark EPG as unavailable for this provider
            log(f'EPG unavailable for {self.server}, skipping for {_TTL_EPG_FAIL}s: {e}',
                xbmc.LOGWARNING)
            self._mark_epg_failed()
            return []

    def get_epg_batch(self, stream_ids):
        """
        Fetch EPG for multiple streams in parallel.
        Returns dict: {stream_id_str: [now, next]}
        If EPG is known unavailable, returns {} immediately (no threads spawned).
        Max 2s wall-clock wait — channel list must feel fast.
        """
        if not self._epg_available():
            log('EPG skipped (provider marked unavailable)', xbmc.LOGDEBUG)
            return {}

        results = {}
        lock    = threading.Lock()

        def _fetch(sid):
            epg = self.get_epg_for_stream(sid)
            if epg:
                with lock:
                    results[str(sid)] = epg

        threads = [threading.Thread(target=_fetch, args=(sid,), daemon=True)
                   for sid in stream_ids[:50]]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=2)   # 2s max — don't punish the user for slow EPG

        log(f'EPG batch: {len(results)}/{len(stream_ids)} channels', xbmc.LOGDEBUG)
        return results
    def _xmltv_cache_key(self):
        return f'xt_xmltv_{self.server}'

    def _fetch_and_parse_xmltv(self):
        """
        Blocking fetch+parse of the XMLTV feed. Runs in a background thread.
        Stores result in cache when done. Returns parsed dict or {}.

        Cache stores a tuple: (epg_dict, name_index)
          epg_dict   : {channel_id -> [now_entry, next_entry]}
          name_index : {normalised_display_name -> channel_id}
        """
        ck  = self._xmltv_cache_key()
        url = f'{self.server}/xmltv.php?username={self.username}&password={self.password}'
        try:
            from urllib.request import urlopen, Request
            from datetime import datetime, timezone, timedelta
            import xml.etree.ElementTree as ET
            import re

            req = Request(url, headers={'User-Agent': 'Kodi/21 StreamHub'})
            log(f'XMLTV: fetching {url}', xbmc.LOGDEBUG)
            with urlopen(req, timeout=30) as r:
                raw = r.read()

            now          = datetime.now(timezone.utc)
            window_start = now - timedelta(hours=1)
            window_end   = now + timedelta(hours=4)

            def _parse_time(s):
                if not s: return None
                try:
                    m = re.match(r'(\d{14})\s*([+-]\d{4})?', s)
                    if not m: return None
                    dt     = datetime.strptime(m.group(1), '%Y%m%d%H%M%S')
                    tz_str = m.group(2) or '+0000'
                    sign   = 1 if tz_str[0] == '+' else -1
                    off_h, off_m = int(tz_str[1:3]), int(tz_str[3:5])
                    dt -= timedelta(hours=sign*off_h, minutes=sign*off_m)
                    return dt.replace(tzinfo=timezone.utc)
                except: return None

            def _norm(s):
                """Normalise a channel name for fuzzy matching.
                Strips HD/HEVC/FHD/SD suffixes, punctuation, extra spaces, lowercase."""
                s = s.upper()
                # strip country prefix like "UK| " or "IT| "
                s = re.sub(r'^[A-Z]{2}\|\s*', '', s)
                # strip quality suffixes
                s = re.sub(r'\b(HEVC|FHD|UHD|HD|SD|4K)\b', '', s)
                # strip non-alphanumeric
                s = re.sub(r'[^A-Z0-9]', ' ', s)
                return re.sub(r'\s+', ' ', s).strip()

            root = ET.fromstring(raw)

            # ── 1. Build display-name index — UK/IT channels only ─────────────
            # We only care about UK and IT content, so skip everything else.
            # This keeps the cache small and matching fast.
            uk_it_cids = set()
            name_index = {}   # normalised_name -> channel_id
            for ch in root.iter('channel'):
                cid = ch.get('id', '')
                if not cid: continue
                display_names = [dn.text for dn in ch.iter('display-name') if dn.text]
                # Keep channel if any display-name looks like UK or IT content
                is_uk_it = any(
                    re.match(r'^(UK|IT)\b', n.strip(), re.IGNORECASE)
                    for n in display_names
                )
                if not is_uk_it:
                    continue
                uk_it_cids.add(cid)
                for dn_text in display_names:
                    key = _norm(dn_text)
                    if key:
                        name_index[key] = cid
            log(f'XMLTV: indexed {len(uk_it_cids)} UK/IT channels, {len(name_index)} name entries', xbmc.LOGDEBUG)

            # ── 2. Parse <programme> elements — UK/IT only ───────────────────
            by_channel = {}
            for prog in root.iter('programme'):
                cid = prog.get('channel', '')
                if cid not in uk_it_cids: continue   # skip non-UK/IT
                start = _parse_time(prog.get('start', ''))
                stop  = _parse_time(prog.get('stop', ''))
                if not start or not stop: continue
                if stop < window_start or start > window_end: continue
                title_el = prog.find('title')
                desc_el  = prog.find('desc')
                entry = {
                    'title':       (title_el.text if title_el is not None else '').strip(),
                    'description': (desc_el.text  if desc_el  is not None else '').strip(),
                    'start':       start.strftime('%H:%M'),
                    'end':         stop.strftime('%H:%M'),
                }
                by_channel.setdefault(cid, []).append((start, entry))

            epg_dict = {}
            for cid, progs in by_channel.items():
                progs.sort(key=lambda x: x[0])
                now_p = next_p = None
                for start, entry in progs:
                    if start <= now:   now_p  = entry
                    elif now_p:        next_p = entry; break
                if now_p or next_p:
                    epg_dict[cid] = [p for p in [now_p, next_p] if p]

            log(f'XMLTV parsed: {len(epg_dict)} channels with EPG', xbmc.LOGINFO)
            cache_set(ck, (epg_dict, name_index), 900)
            return epg_dict, name_index

        except Exception as e:
            log(f'XMLTV fetch failed: {e}', xbmc.LOGWARNING)
            return {}, {}

    def warm_xmltv_cache(self):
        """
        Fire XMLTV fetch in background — returns immediately.
        Call this when listing categories so cache is ready by the time
        the user clicks into a category.
        """
        ck = self._xmltv_cache_key()
        if cache_get(ck) is not None:
            return   # already cached, nothing to do
        t = threading.Thread(target=self._fetch_and_parse_xmltv, daemon=True)
        t.start()
        log('XMLTV: background warm started', xbmc.LOGDEBUG)

    def get_xmltv_epg(self):
        """
        Return (epg_dict, name_index) from cache. Fetches synchronously if not cached.
        epg_dict   : {channel_id -> [now_entry, next_entry]}
        name_index : {normalised_display_name -> channel_id}
        """
        ck     = self._xmltv_cache_key()
        cached = cache_get(ck)
        if cached is not None:
            # cached value is (epg_dict, name_index) tuple
            if isinstance(cached, tuple) and len(cached) == 2:
                return cached
            # old-format cache (plain dict) — invalidate and re-fetch
            log('XMLTV: stale cache format, re-fetching', xbmc.LOGDEBUG)
        return self._fetch_and_parse_xmltv()

    def get_epg_batch_with_xmltv_fallback(self, streams):
        """
        Match streams to XMLTV EPG data.
        Three-tier matching per stream:
          1. epg_channel_id exact match against XMLTV channel IDs
          2. Normalised stream name match against XMLTV display-name index
          3. Name match after stripping ' / ...' alternate-name suffixes
        streams: list of stream dicts (need stream_id, epg_channel_id, name)
        Returns dict: {stream_id_str: [now_entry, ...]}
        """
        epg_dict, name_index = self.get_xmltv_epg()
        if not epg_dict:
            return {}

        def _norm(s):
            s = s.upper()
            s = re.sub(r'^[A-Z]{2}\|\s*', '', s)          # strip "UK| "
            s = re.sub(r'\b(HEVC|FHD|UHD|HD|SD|4K)\b', '', s)  # strip quality
            s = re.sub(r'[^A-Z0-9]', ' ', s)
            return re.sub(r'\s+', ' ', s).strip()

        result = {}
        missed = 0
        for s in streams:
            sid  = str(s.get('stream_id', ''))
            cid  = s.get('epg_channel_id', '')
            name = s.get('name', '')

            epg = None

            # ── Tier 1: exact epg_channel_id match ───────────────────────────
            if cid and cid in epg_dict:
                epg = epg_dict[cid]

            # ── Tier 2: normalised stream name → display-name index ──────────
            if epg is None and name:
                key = _norm(name)
                if key and key in name_index:
                    mapped_cid = name_index[key]
                    epg = epg_dict.get(mapped_cid)

            # ── Tier 3: strip " / ALTERNATE" suffix and try again ────────────
            if epg is None and name:
                base = re.split(r'\s*/\s*', name)[0]   # "BBC 3 / CBBC HD" → "BBC 3"
                if base != name:
                    key = _norm(base)
                    if key and key in name_index:
                        mapped_cid = name_index[key]
                        epg = epg_dict.get(mapped_cid)

            if epg:
                result[sid] = epg
            else:
                missed += 1

        log(f'XMLTV matched {len(result)}/{len(streams)} streams ({missed} unmatched)', xbmc.LOGDEBUG)
        return result
