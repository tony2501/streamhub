"""
StreamHub - Menu definitions
"""
import xbmcplugin
from resources.lib.kodi_utils import HANDLE, get_setting, add_dir_item, end_directory


def show_main_menu():
    from resources.lib.emby_client import EmbyClient
    client    = EmbyClient()
    logged_in = client.is_configured()

    # Warm widget cache in background — fires parallel requests so that
    # Bingie home rows are served from memory by the time the skin asks.
    if logged_in:
        from resources.lib.prefetch import start as prefetch_start
        prefetch_start(client)
    server    = get_setting('emby_server') or 'Not connected'
    username  = get_setting('emby_username') or ''
    tmdb_key  = get_setting('tmdb_api_key')

    if logged_in:
        add_dir_item(
            f'[COLOR gray]Connected:  [B]{username}[/B]  |  {server}[/COLOR]',
            'MAIN_MENU', icon='DefaultAddonProgram.png', is_folder=False
        )
        if not tmdb_key:
            add_dir_item(
                '[COLOR orange][B]TMDB API key not set - tap Settings to add it[/B][/COLOR]',
                'SHOW_SETTINGS', icon='DefaultAddonProgram.png'
            )
        add_dir_item('Continue Watching',          'CONTINUE_WATCHING',      'DefaultRecentlyAddedMovies.png')
        add_dir_item('Recently Watched Channels',  'IPTV_RECENTS',           'DefaultAddonPVRClient.png')
        add_dir_item('IPTV  —  Live TV',              'IPTV_MENU',     'DefaultAddonPVRClient.png')
        add_dir_item('Movies',                    'MOVIES_MENU',   'DefaultMovies.png')
        add_dir_item('TV Shows',                  'TV_MENU',       'DefaultTVShows.png')
        add_dir_item('Search',                    'NEW_SEARCH',    'DefaultAddonsSearch.png')
        add_dir_item('[COLOR gray]--------[/COLOR]', 'MAIN_MENU', is_folder=False)
        # Real-Debrid status + link/unlink
        rd_token = get_setting('rd_access_token') or get_setting('rd_api_key')
        if rd_token:
            add_dir_item('[COLOR limegreen]Real-Debrid: Linked  —  Unlink[/COLOR]', 'RD_UNLINK', 'DefaultAddonProgram.png', is_folder=False)
        else:
            add_dir_item('[COLOR orange]Real-Debrid: Not linked  —  Tap to link[/COLOR]', 'RD_LINK', 'DefaultAddonProgram.png', is_folder=False)
        add_dir_item('Switch Account / Re-Login', 'LOGIN_WIZARD',  'DefaultAddonProgram.png')
        add_dir_item('Log Out',                   'LOGOUT',        'DefaultAddonProgram.png')
        add_dir_item('Clear Cache',               'CLEAR_CACHE',   'DefaultAddonProgram.png')
        add_dir_item('Settings',                  'SHOW_SETTINGS', 'DefaultAddonProgram.png')
    else:
        add_dir_item(
            '[COLOR yellow][B]Not connected to Emby - tap to Log In[/B][/COLOR]',
            'LOGIN_WIZARD', icon='DefaultAddonProgram.png'
        )
        add_dir_item('Log In to Emby', 'LOGIN_WIZARD',  'DefaultAddonProgram.png')
        add_dir_item('Settings',       'SHOW_SETTINGS', 'DefaultAddonProgram.png')

    end_directory('files', [xbmcplugin.SORT_METHOD_NONE], cache=False)


def show_movies_menu():
    tmdb_ok = bool(get_setting('tmdb_api_key'))
    suffix  = '' if tmdb_ok else '  [COLOR gray](TMDB key needed)[/COLOR]'
    entries = [
        (f'Popular{suffix}',          'MOVIES_POPULAR',        'DefaultMovies.png'),
        (f'Trending{suffix}',          'MOVIES_TRENDING',       'DefaultMovies.png'),
        (f'Top Rated{suffix}',         'MOVIES_TOP_RATED',      'DefaultMovies.png'),
        (f'Now Playing{suffix}',       'MOVIES_NOW_PLAYING',    'DefaultRecentlyAddedMovies.png'),
        (f'Upcoming{suffix}',          'MOVIES_UPCOMING',       'DefaultMovies.png'),
        ('Recently Added',             'MOVIES_RECENTLY_ADDED', 'DefaultRecentlyAddedMovies.png'),
        ('In Progress',                'MOVIES_IN_PROGRESS',    'DefaultRecentlyAddedMovies.png'),
        ('Favourites',                 'MOVIES_FAVOURITES',     'DefaultFavourites.png'),
        ('Random Pick',                'MOVIES_RANDOM',         'DefaultMovies.png'),
        ('Unwatched',                  'MOVIES_UNWATCHED',      'DefaultMovies.png'),
        ('All Movies',                 'MOVIES_ALL',            'DefaultMovies.png'),
        ('By Genre',                   'MOVIES_GENRES',         'DefaultGenre.png'),
        ('By Year',                    'MOVIES_YEARS',          'DefaultYear.png'),
        ('By Studio',                  'MOVIES_STUDIOS',        'DefaultActor.png'),
    ]
    for label, mode, icon in entries:
        add_dir_item(label, mode, icon)
    end_directory('movies', [xbmcplugin.SORT_METHOD_NONE])


def show_tv_menu():
    tmdb_ok = bool(get_setting('tmdb_api_key'))
    suffix  = '' if tmdb_ok else '  [COLOR gray](TMDB key needed)[/COLOR]'
    entries = [
        (f'Popular{suffix}',                 'TV_POPULAR',          'DefaultTVShows.png'),
        (f'Trending{suffix}',                'TV_TRENDING',         'DefaultTVShows.png'),
        (f'Top Rated{suffix}',               'TV_TOP_RATED',        'DefaultTVShows.png'),
        (f'On The Air{suffix}',              'TV_ON_AIR',           'DefaultTVShows.png'),
        (f'Airing Today{suffix}',            'TV_AIRING_TODAY',     'DefaultTVShows.png'),
        ('Next Up',                          'TV_NEXT_UP',          'DefaultTVShows.png'),
        ('Recently Added Episodes',          'TV_RECENTLY_ADDED',   'DefaultRecentlyAddedEpisodes.png'),
        ('In Progress',                      'TV_IN_PROGRESS',      'DefaultRecentlyAddedEpisodes.png'),
        ('Favourites',                       'TV_FAVOURITES',       'DefaultFavourites.png'),
        ('Unwatched',                        'TV_UNWATCHED',        'DefaultTVShows.png'),
        ('All Shows',                        'TV_ALL',              'DefaultTVShows.png'),
        ('By Genre',                         'TV_GENRES',           'DefaultGenre.png'),
    ]
    for label, mode, icon in entries:
        add_dir_item(label, mode, icon)
    end_directory('tvshows', [xbmcplugin.SORT_METHOD_NONE])
