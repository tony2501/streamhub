"""
StreamHub - Player
Playback, resume handling, Emby progress reporting, and autoplay next episode.
"""

import json
import threading
import time
import xbmc, xbmcgui, xbmcplugin
from resources.lib.kodi_utils import (
    log, get_bool, HANDLE, notify, _stream_height
)


def _ticks(secs):  return int(secs) * 10_000_000
def _secs(ticks):  return int(ticks) // 10_000_000 if ticks else 0
def _fmt(secs):
    h, r = divmod(int(secs), 3600)
    m, s = divmod(r, 60)
    return f'{h}:{m:02d}:{s:02d}' if h else f'{m}:{s:02d}'


class _Monitor(xbmc.Player):
    def __init__(self, client, iid, total_ticks, ms_id=None, series_id=None,
                 season_number=None, episode_number=None):
        super().__init__()
        self._c              = client
        self._iid            = iid
        self._ms_id          = ms_id
        self._total          = total_ticks
        self._stop           = threading.Event()
        self._ended          = False
        self._series_id      = series_id
        self._season_number  = season_number
        self._episode_number = episode_number
        threading.Thread(target=self._loop, daemon=True).start()

    def _loop(self):
        while not self._stop.is_set():
            time.sleep(10)
            if self._stop.is_set() or not self.isPlaying():
                break
            try:
                self._c.report_progress(self._iid, _ticks(self.getTime()), ms_id=self._ms_id)
            except Exception as e:
                log(f'Progress: {e}', xbmc.LOGWARNING)

    def onPlayBackStopped(self):
        self._stop.set()
        try:    self._c.report_stop(self._iid, _ticks(self.getTime()), self._ms_id)
        except: self._c.report_stop(self._iid, 0, self._ms_id)

    def onPlayBackEnded(self):
        self._stop.set()
        self._ended = True
        if get_bool('mark_played', True):
            self._c.mark_watched(self._iid)
        self._c.report_stop(self._iid, self._total, self._ms_id)

    def onPlayBackPaused(self):
        try:    self._c.report_progress(self._iid, _ticks(self.getTime()), paused=True, ms_id=self._ms_id)
        except: pass

    def onPlayBackResumed(self):
        try:    self._c.report_progress(self._iid, _ticks(self.getTime()), paused=False, ms_id=self._ms_id)
        except: pass


def _autoplay_next(client, series_id, season_number, episode_number):
    """
    Show a 15-second countdown dialog then play the next episode.
    Returns True if next episode was launched, False if cancelled/not found.
    """
    if not series_id:
        return False

    next_ep = client.get_next_episode(series_id, season_number, episode_number)
    if not next_ep:
        return False

    next_id   = next_ep.get('Id', '')
    next_name = next_ep.get('Name', '')
    s_num     = next_ep.get('ParentIndexNumber', '')
    e_num     = next_ep.get('IndexNumber', '')
    series    = next_ep.get('SeriesName', '')
    label     = f'S{s_num:02d}E{e_num:02d} – {next_name}' if s_num and e_num else next_name

    progress = xbmcgui.DialogProgress()
    progress.create(f'Next: {series}', label)

    countdown = 15
    for i in range(countdown, 0, -1):
        if progress.iscanceled():
            progress.close()
            return False
        progress.update(
            int((countdown - i) / countdown * 100),
            f'Playing next in {i}s…\n{label}'
        )
        time.sleep(1)

    progress.close()
    log(f'Autoplay next episode: {next_id} ({label})', xbmc.LOGINFO)
    play_item(client, next_id)
    return True


def _rd_autoplay_next(client, imdb_id, season_num, episode_num, base_metadata, duration_s):
    """
    After an RD episode ends, offer 15s countdown then play next episode via RD.
    Looks up next episode from Emby using the series IMDB ID.
    """
    if not season_num or not episode_num:
        return

    # Find the series in Emby by IMDB ID
    series_items = client.items_by_provider_id('imdb', imdb_id, item_type='Series')
    if not series_items:
        return
    series_id = series_items[0].get('Id', '')
    if not series_id:
        return

    next_ep = client.get_next_episode(series_id, season_num, episode_num)
    if not next_ep:
        return

    next_s   = next_ep.get('ParentIndexNumber', season_num)
    next_e   = next_ep.get('IndexNumber', episode_num + 1)
    next_name = next_ep.get('Name', f'S{next_s:02d}E{next_e:02d}')
    series_name = base_metadata.get('series_title', '')
    label = f'S{next_s:02d}E{next_e:02d} \u2013 {next_name}'

    progress = xbmcgui.DialogProgress()
    progress.create(f'Next: {series_name}', label)
    countdown = 15
    for i in range(countdown, 0, -1):
        if progress.iscanceled():
            progress.close()
            return
        progress.update(
            int((countdown - i) / countdown * 100),
            f'Playing next in {i}s\u2026\n{label}'
        )
        time.sleep(1)
    progress.close()

    # Play the next episode's Emby item_id — goes through full picker again
    play_item(client, next_ep.get('Id', ''))


def play_item(client, item_id):
    if not item_id:
        log('play_item: no item_id', xbmc.LOGERROR)
        return

    item = client.get_item(item_id)
    if not item:
        notify('Could not load item from Emby', xbmcgui.NOTIFICATION_ERROR)
        return

    # ------------------------------------------------------------------ #
    # Build Emby quality options
    # Strategy:
    #   1. Try PlaybackInfo — works when Emby stores versions as MediaSources
    #   2. If only 1 source returned, query by provider ID to find sibling
    #      items (4K + 1080p stored as separate Emby items with same TVDB/TMDB)
    #   3. Fall back to item's own MediaSources
    # ------------------------------------------------------------------ #

    def _label2(ms):
        """Detail line for picker — video info, audio tracks, subtitles."""
        videos = [s for s in ms.get('MediaStreams', []) if s.get('Type') == 'Video']
        audios = [s for s in ms.get('MediaStreams', []) if s.get('Type') == 'Audio']
        subs   = [s for s in ms.get('MediaStreams', []) if s.get('Type') == 'Subtitle']
        details = []
        for v in videos:
            details.append('{} {} {}bit'.format(
                v.get('DisplayTitle', ''), v.get('VideoRange', ''), v.get('BitDepth', '')))
        aud = ['{} {} {}'.format(
            a.get('Language', ''), a.get('Codec', ''), a.get('Channels', ''))
            for a in audios]
        if aud:
            details.append(', '.join(aud).upper())
        sub_langs = [s.get('Language', '') for s in subs]
        if sub_langs:
            details.append('S: {}'.format(', '.join(sub_langs)).upper())
        return ' | '.join(details)

    def _quality_label(ms):
        """Primary label for picker — resolution + source type so versions are distinguishable."""
        from resources.lib.kodi_utils import _clean_version_label
        return _clean_version_label(ms)

    def _best_source(sib):
        """Sort key — best quality (highest resolution) first."""
        sources = sib.get('MediaSources', [])
        if not sources:
            return 0
        return -max(_stream_height(ms) for ms in sources)

    playback_info = client.get_playback_info(item_id)
    media_sources = (playback_info or {}).get('MediaSources') or []

    # unified picker lists — (ListItem, source_type, payload)
    # source_type: 'emby' or 'rd'
    # payload for emby: (item_id, ms_id, item_dict)
    # payload for rd:   {'url': ..., 'label': ..., ...}
    picker_items = []
    play_map     = []   # [(source_type, payload)]

    itype = item.get('Type', '')
    pids  = item.get('ProviderIds', {})

    # --- Emby sources ---
    if len(media_sources) <= 1:
        # Look for sibling items via provider ID
        if itype == 'Episode':
            pid_keys = ('Tvdb', 'Imdb', 'Tmdb')
        else:
            pid_keys = ('Imdb', 'Tmdb', 'Tvdb')

        pid_pairs = [(k.lower(), pids[k]) for k in pid_keys if pids.get(k)]

        sibling_items = []
        for provider, pid in pid_pairs:
            emby_type = 'Episode' if itype == 'Episode' else 'Movie'
            data = client._get(client._user('/Items'), {
                'AnyProviderIdEquals': f'{provider}.{pid}',
                'IncludeItemTypes':    emby_type,
                'Recursive':           'true',
                'Fields':              'MediaSources,MediaStreams,ProviderIds,Name,RunTimeTicks',
                'Limit':               10,
            })
            siblings = (data or {}).get('Items', [])
            if len(siblings) > 1:
                sibling_items = siblings
                break

        if len(sibling_items) > 1:
            sibling_items = sorted(sibling_items, key=_best_source)
            for sib in sibling_items:
                sources = sorted(sib.get('MediaSources', []),
                                 key=lambda ms: -_stream_height(ms))
                if not sources:
                    continue
                ms     = sources[0]
                picker_items.append(xbmcgui.ListItem(label=_quality_label(ms),
                                                      label2=_label2(ms)))
                play_map.append(('emby', (sib.get('Id', item_id), ms.get('Id'), sib)))
        else:
            # Single Emby version
            sources = media_sources or item.get('MediaSources', [])
            if sources:
                ms = sources[0]
                picker_items.append(xbmcgui.ListItem(label=_quality_label(ms),
                                                      label2=_label2(ms)))
                play_map.append(('emby', (item_id, ms.get('Id'), item)))
    else:
        # PlaybackInfo returned multiple sources
        media_sources = sorted(media_sources, key=lambda ms: -_stream_height(ms))
        for ms in media_sources:
            picker_items.append(xbmcgui.ListItem(label=_quality_label(ms),
                                                  label2=_label2(ms)))
            play_map.append(('emby', (item_id, ms.get('Id'), item)))

    # --- Real-Debrid sources (appended after Emby) ---
    # For episodes, Emby stores the IMDB ID on the series, not the episode.
    # Fall back to fetching the series item to get its IMDB ID.
    imdb_id = pids.get('Imdb', '')
    if not imdb_id and itype == 'Episode':
        series_item_id = item.get('SeriesId', '')
        if series_item_id:
            try:
                series_item = client._get(client._user(f'/Items/{series_item_id}'), {
                    'Fields': 'ProviderIds',
                })
                imdb_id = (series_item or {}).get('ProviderIds', {}).get('Imdb', '')
            except Exception:
                pass

    rd_streams = []
    try:
        from resources.lib.rd_client import RDClient
        rd = RDClient()
        if rd.is_configured() and imdb_id:
            if itype == 'Episode':
                rd_streams = rd.get_streams(
                    imdb_id, media_type='series',
                    season=item.get('ParentIndexNumber'),
                    episode=item.get('IndexNumber'),
                )
            else:
                rd_streams = rd.get_streams(imdb_id, media_type='movie')
    except Exception as e:
        log(f'RD fetch error: {e}', xbmc.LOGWARNING)

    for rd_s in rd_streams:
        li = xbmcgui.ListItem(label=rd_s['label'], label2=rd_s['label2'])
        picker_items.append(li)
        play_map.append(('rd', rd_s))

    # --- Nothing at all ---
    if not picker_items:
        notify('No playable sources found', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return

    # --- Show picker (skip if only 1 source) ---
    if len(picker_items) == 1:
        resp = 0
    else:
        resp = xbmcgui.Dialog().select('Select Quality', picker_items, useDetails=True)
        if resp < 0:
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return

    source_type, payload = play_map[resp]

    # --- Resolve selected source ---
    if source_type == 'rd':
        # RD path — direct HTTP URL, track progress locally for Continue Watching
        rd_url     = payload['url']
        name       = item.get('Name', '')
        ticks      = item.get('RunTimeTicks', 0)
        duration_s = _secs(ticks) if ticks else 0

        # Build a stable key for this item
        is_episode   = itype == 'Episode'
        season_num   = item.get('ParentIndexNumber') if is_episode else None
        episode_num  = item.get('IndexNumber')       if is_episode else None
        rd_key       = imdb_id
        if is_episode and season_num and episode_num:
            rd_key = f'{imdb_id}:s{season_num}e{episode_num}'

        rd_metadata = {
            'imdb_id':      imdb_id,
            'media_type':   'series' if is_episode else 'movie',
            'season':       season_num,
            'episode':      episode_num,
            'title':        name,
            'series_title': item.get('SeriesName', '') if is_episode else '',
            'thumb':        client.image_url(item_id),
            'fanart':       client.image_url(item_id, 'Backdrop', 1920),
            'year':         int(item.get('ProductionYear') or 0),
            'duration':     duration_s,
            'overview':     item.get('Overview', ''),
        }

        li  = xbmcgui.ListItem(name, path=rd_url)
        tag = li.getVideoInfoTag()
        tag.setTitle(name)
        tag.setPlot(item.get('Overview', ''))
        year = item.get('ProductionYear', 0)
        tag.setYear(int(year) if year else 0)
        tag.setRating(float(item.get('CommunityRating') or 0))
        if ticks:
            tag.setDuration(duration_s)
        tag.setMediaType('movie' if itype == 'Movie' else 'episode')
        if is_episode:
            tag.setTvShowTitle(item.get('SeriesName', ''))
            tag.setSeason(season_num or 0)
            tag.setEpisode(episode_num or 0)
        li.setArt({
            'thumb':  client.image_url(item_id),
            'fanart': client.image_url(item_id, 'Backdrop', 1920),
        })
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.setResolvedUrl(HANDLE, True, li)
        log(f'Playing via RD: {payload["label"]}', xbmc.LOGINFO)

        # Use a proper xbmc.Player subclass with callbacks — same pattern as
        # the Emby _Monitor. A bare xbmc.Player() created after setResolvedUrl
        # does NOT receive playback events in the plugin invoker thread.
        from resources.lib.kodi_utils import rd_progress_update

        class _RDMonitor(xbmc.Player):
            def __init__(self):
                super().__init__()
                self._stopped = threading.Event()
                self._ended   = False
                threading.Thread(target=self._loop, daemon=True).start()

            def _loop(self):
                # Wait up to 10s for playback to start
                for _ in range(40):
                    if self.isPlaying():
                        break
                    time.sleep(0.25)
                # Report every 10s while playing
                last = 0.0
                while not self._stopped.is_set():
                    time.sleep(1)
                    if not self.isPlaying():
                        break
                    now = time.time()
                    if now - last >= 10 and duration_s > 0:
                        try:
                            rd_progress_update(rd_key, self.getTime(),
                                               duration_s, rd_metadata)
                        except Exception:
                            pass
                        last = now

            def onPlayBackStopped(self):
                self._stopped.set()
                try:
                    rd_progress_update(rd_key, self.getTime(),
                                       duration_s, rd_metadata)
                except Exception:
                    pass

            def onPlayBackEnded(self):
                self._ended = True
                self._stopped.set()
                # Mark complete — progress_update will remove it at >95%
                if duration_s > 0:
                    rd_progress_update(rd_key, duration_s, duration_s, rd_metadata)

            def onPlayBackPaused(self):
                try:
                    rd_progress_update(rd_key, self.getTime(),
                                       duration_s, rd_metadata)
                except Exception:
                    pass

        monitor = _RDMonitor()
        km = xbmc.Monitor()

        # Wait for playback to start
        for _ in range(40):
            if monitor.isPlaying() or km.abortRequested():
                break
            time.sleep(0.25)

        # Block until done
        while monitor.isPlaying() and not km.abortRequested():
            time.sleep(1)
        monitor._stopped.set()

        # Autoplay next episode for RD TV
        if is_episode and monitor._ended and imdb_id:
            _rd_autoplay_next(client, imdb_id, season_num, episode_num,
                              rd_metadata, duration_s)
        return

    # --- Emby path (original flow) ---
    item_id, ms_id, item = payload
    ticks = item.get('RunTimeTicks', 0)
    url   = client.stream_url(item_id, ms_id)

    # Episode metadata for autoplay next
    is_episode     = item.get('Type') == 'Episode'
    series_id      = item.get('SeriesId', '')
    season_number  = item.get('ParentIndexNumber', 0)
    episode_number = item.get('IndexNumber', 0)

    # Resume prompt
    ud       = item.get('UserData', {})
    resume_t = ud.get('PlaybackPositionTicks', 0)
    if resume_t and get_bool('resume_from_emby', True):
        total_s  = _secs(ticks)
        resume_s = _secs(resume_t)
        pct      = (resume_s / total_s * 100) if total_s else 0
        if 2 < pct < 97:
            choice = xbmcgui.Dialog().contextmenu([
                f'Resume from {_fmt(resume_s)}',
                'Play from beginning',
            ])
            if choice == 1:
                resume_t = 0

    # Build ListItem
    name = item.get('Name', '')
    li   = xbmcgui.ListItem(name, path=url)
    tag  = li.getVideoInfoTag()
    tag.setTitle(name)
    tag.setPlot(item.get('Overview', ''))
    year = item.get('ProductionYear', 0)
    tag.setYear(int(year) if year else 0)
    tag.setRating(float(item.get('CommunityRating') or 0))
    if ticks: tag.setDuration(_secs(ticks))
    tag.setMediaType('movie' if item.get('Type') == 'Movie' else 'episode')
    li.setArt({
        'thumb':  client.image_url(item_id),
        'fanart': client.image_url(item_id, 'Backdrop', 1920),
    })

    client.report_start(item_id, resume_t, ms_id)
    xbmcplugin.setResolvedUrl(HANDLE, True, li)

    monitor = _Monitor(
        client, item_id, ticks, ms_id=ms_id,
        series_id=series_id if is_episode else None,
        season_number=season_number,
        episode_number=episode_number,
    )

    if resume_t:
        seek_s = _secs(resume_t)
        def _seek():
            for _ in range(40):
                time.sleep(0.25)
                if monitor.isPlaying():
                    try: monitor.seekTime(seek_s)
                    except: pass
                    return
        threading.Thread(target=_seek, daemon=True).start()

    km = xbmc.Monitor()

    # Wait up to 10s for Kodi to actually start playing before we monitor.
    # setResolvedUrl returns immediately; playback starts asynchronously.
    for _ in range(40):
        if monitor.isPlaying() or km.abortRequested():
            break
        time.sleep(0.25)

    while monitor.isPlaying() and not km.abortRequested():
        time.sleep(1)
    monitor._stop.set()

    # After episode ends naturally — offer to play next
    if is_episode and monitor._ended and series_id:
        _autoplay_next(client, series_id, season_number, episode_number)


def play_by_tmdb_id(client, tmdb_id, media_type='movie', season='', episode=''):
    """
    Entry point for TMDbHelper / Bingie player JSON.
    Resolves tmdb_id -> Emby item_id, then plays best quality version.
    media_type: 'movie' or 'tv'
    season/episode: strings, required for TV episodes.
    """
    if not tmdb_id:
        notify('StreamHub: no tmdb_id received')
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return

    if media_type == 'movie':
        # Find the Emby movie matching this TMDB id
        items = client.items_by_provider_id('tmdb', tmdb_id, item_type='Movie')
        if not items:
            notify(f'StreamHub: movie not in Emby library (tmdb={tmdb_id})')
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return
        item_id = items[0].get('Id', '')
        play_item(client, item_id)

    elif media_type == 'tv':
        if not season or not episode:
            notify('StreamHub: season/episode required for TV playback')
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return
        # Find all Emby series matching this TMDB id (may be multiple — 4K + 1080p)
        series_list = client.items_by_provider_id('tmdb', tmdb_id, item_type='Series')
        if not series_list:
            notify(f'StreamHub: TV show not in Emby library (tmdb={tmdb_id})')
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return

        # Try each series until we find one that has this episode
        ep_data = None
        for series in series_list:
            series_id = series.get('Id', '')
            ep_data = client.episode_by_number(series_id, int(season), int(episode))
            if ep_data:
                break

        if not ep_data:
            notify(f'StreamHub: S{season}E{episode} not found in Emby')
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return
        item_id = ep_data.get('Id', '')
        play_item(client, item_id)

    else:
        notify(f'StreamHub: unknown media_type={media_type}')
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
