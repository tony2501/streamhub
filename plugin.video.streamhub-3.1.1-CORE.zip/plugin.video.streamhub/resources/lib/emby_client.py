"""
StreamHub - Emby API Client v2.1
Content lists mirror TMDB Helper categories as closely as possible
using Emby's available sort/filter parameters.
"""

import json
import uuid
import datetime
from urllib.parse import urlencode
from urllib.request import urlopen, Request
from urllib.error import URLError, HTTPError

import xbmc
import xbmcgui

from resources.lib.kodi_utils import (
    log, get_setting, set_setting, get_int,
    cache_get, cache_set, notify
)

_CLIENT  = 'StreamHub'
_VERSION = '2.7.8'
_DEVICE  = 'StreamHubKodi'

# Full field list so version/resolution info is available
_FIELDS = (
    'BasicSyncInfo,Container,DateCreated,EpisodeCount,Genres,'
    'Overview,ParentId,ProviderIds,SeasonUserData,SortName,'
    'Studios,Taglines,UserData,MediaSources,RunTimeTicks,'
    'OfficialRating,CommunityRating,ProductionYear,Path,'
    'Width,Height,MediaStreams'
)

# Slim fields for widget/home-screen rows.
# No MediaSources/MediaStreams/Studios/Taglines — only needed at playback.
# Cuts response ~60% for fast Bingie widget loading.
_WIDGET_FIELDS = (
    'BasicSyncInfo,Genres,Overview,UserData,SeriesName,SeriesId,'
    'RunTimeTicks,OfficialRating,CommunityRating,ProductionYear,'
    'ProviderIds,ParentIndexNumber,IndexNumber,SortName'
)


_DEFAULT_SERVER  = 'https://emby5.mm04.appboxmanager.xyz'
_DEFAULT_TOKEN   = '763f377758974b9baf8104cf44f189f9'
_DEFAULT_USER_ID = 'ab5b108d51d24e10958eb2c02aa2d7e2'


class EmbyClient:
    def __init__(self):
        self.server      = (get_setting('emby_server') or _DEFAULT_SERVER).rstrip('/')
        self.token       = get_setting('emby_token')   or _DEFAULT_TOKEN
        self.user_id     = get_setting('emby_user_id') or _DEFAULT_USER_ID
        self.timeout     = get_int('http_timeout', 30)
        self._session_id = str(uuid.uuid4())
        # Pre-build auth header — constant for the lifetime of this client
        self._auth = (
            f'MediaBrowser Client="{_CLIENT}", Device="Kodi", '
            f'DeviceId="{_DEVICE}", Version="{_VERSION}", Token="{self.token}"'
        )

    def is_configured(self):
        return bool(self.server and self.token and self.user_id)

    # ------------------------------------------------------------------ #
    # Auth
    # ------------------------------------------------------------------ #
    def _auth_header(self):
        return self._auth

    # ------------------------------------------------------------------ #
    # HTTP
    # ------------------------------------------------------------------ #
    def _get(self, endpoint, params=None, ck=None, cttl=None):
        if ck:
            cached = cache_get(ck)
            if cached is not None:
                return cached
        qs  = ('?' + urlencode(params)) if params else ''
        url = f'{self.server}{endpoint}{qs}'
        req = Request(url, headers={
            'X-Emby-Authorization': self._auth_header(),
            'Accept': 'application/json',
        })
        last_error = None
        for attempt in (1, 2):
            try:
                # First attempt uses a shorter timeout so a slow server gets
                # a second chance quickly rather than failing after 30s.
                t = 12 if attempt == 1 else self.timeout
                with urlopen(req, timeout=t) as r:
                    data = json.loads(r.read())
                    if ck:
                        cache_set(ck, data, cttl or get_int('cache_ttl', 5) * 60)
                    return data
            except HTTPError as e:
                log(f'HTTP {e.code} {url}: {e.reason}', xbmc.LOGERROR)
                if e.code == 401:
                    notify('Emby: Unauthorised - please log in again', xbmcgui.NOTIFICATION_ERROR)
                return None   # HTTP errors won't improve with a retry
            except URLError as e:
                log(f'URLError {url} (attempt {attempt}): {e.reason}', xbmc.LOGWARNING)
                last_error = e
            except Exception as e:
                log(f'Request error {url} (attempt {attempt}): {e}', xbmc.LOGWARNING)
                last_error = e

        log(f'All retries failed for {url}: {last_error}', xbmc.LOGERROR)
        notify(f'Cannot reach Emby — check your connection', xbmcgui.NOTIFICATION_ERROR)
        return None

    def _post(self, endpoint, payload=None):
        url  = f'{self.server}{endpoint}'
        data = json.dumps(payload or {}).encode()
        req  = Request(url, data=data, headers={
            'X-Emby-Authorization': self._auth_header(),
            'Content-Type': 'application/json',
            'Accept': 'application/json',
        }, method='POST')
        try:
            with urlopen(req, timeout=self.timeout) as r:
                return json.loads(r.read()) if r.length else {}
        except Exception as e:
            body = ''
            try: body = e.read().decode('utf-8', errors='replace')
            except: pass
            log(f'POST {endpoint} payload={json.dumps(payload)} error={e} body={body}', xbmc.LOGWARNING)
        return None

    def _user(self, path=''):
        return f'/Users/{self.user_id}{path}'

    def _p(self, extra=None):
        """Base params with full fields (used for playback, detail views)."""
        p = {
            'UserId':           self.user_id,
            'Fields':           _FIELDS,
            'EnableImageTypes': 'Primary,Backdrop,Thumb',
            'ImageTypeLimit':   1,
        }
        if extra:
            p.update(extra)
        return p

    def _pw(self, extra=None):
        """Slim widget params — fast response for home screen rows."""
        p = {
            'UserId':           self.user_id,
            'Fields':           _WIDGET_FIELDS,
            'EnableImageTypes': 'Primary,Backdrop,Thumb',
            'ImageTypeLimit':   1,
        }
        if extra:
            p.update(extra)
        return p

    # ------------------------------------------------------------------ #
    # Login
    # ------------------------------------------------------------------ #
    @staticmethod
    def login(server_url, username, password):
        url = f'{server_url.rstrip("/")}/Users/AuthenticateByName'
        payload = json.dumps({'Username': username, 'Pw': password}).encode()
        headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'X-Emby-Authorization': (
                f'MediaBrowser Client="{_CLIENT}", Device="Kodi", '
                f'DeviceId="{_DEVICE}", Version="{_VERSION}"'
            ),
        }
        req = Request(url, data=payload, headers=headers, method='POST')
        with urlopen(req, timeout=30) as r:
            data = json.loads(r.read())
        token   = data['AccessToken']
        user_id = data['User']['Id']
        uname   = data['User']['Name']
        from xbmcaddon import Addon
        a = Addon()
        a.setSetting('emby_server',   server_url.rstrip('/'))
        a.setSetting('emby_token',    token)
        a.setSetting('emby_user_id',  user_id)
        a.setSetting('emby_username', uname)
        return token, user_id, uname

    # ------------------------------------------------------------------ #
    # Images / URLs
    # ------------------------------------------------------------------ #
    def image_url(self, item_id, kind='Primary', width=500):
        if not item_id:
            return ''
        return f'{self.server}/Items/{item_id}/Images/{kind}?maxWidth={width}&api_key={self.token}'

    def stream_url(self, item_id, ms_id=None):
        p = {'static': 'true', 'api_key': self.token}
        if ms_id:
            p['MediaSourceId'] = ms_id
        return f'{self.server}/Videos/{item_id}/stream?{urlencode(p)}'

    # ------------------------------------------------------------------ #
    # Playback reporting
    # ------------------------------------------------------------------ #
    def report_start(self, iid, ticks=0, ms_id=None):
        payload = {
            'ItemId':               iid,
            'PositionTicks':        ticks,
            'IsPaused':             False,
            'IsMuted':              False,
            'PlayMethod':           'DirectPlay',
            'CanSeek':              True,
            'QueueableMediaTypes':  ['Video'],
            'PlaySessionId':        self._session_id,
        }
        if ms_id:
            payload['MediaSourceId'] = ms_id
        self._post('/Sessions/Playing', payload)

    def report_progress(self, iid, ticks=0, paused=False, ms_id=None):
        payload = {
            'ItemId':               iid,
            'PositionTicks':        ticks,
            'IsPaused':             paused,
            'IsMuted':              False,
            'PlayMethod':           'DirectPlay',
            'CanSeek':              True,
            'QueueableMediaTypes':  ['Video'],
            'PlaySessionId':        self._session_id,
        }
        if ms_id:
            payload['MediaSourceId'] = ms_id
        self._post('/Sessions/Playing/Progress', payload)

    def report_stop(self, iid, ticks=0, ms_id=None):
        payload = {
            'ItemId':               iid,
            'PositionTicks':        ticks,
            'IsPaused':             False,
            'PlayMethod':           'DirectPlay',
            'QueueableMediaTypes':  ['Video'],
            'PlaySessionId':        self._session_id,
        }
        if ms_id:
            payload['MediaSourceId'] = ms_id
        self._post('/Sessions/Playing/Stopped', payload)

    def mark_watched(self, iid):
        url = f'{self.server}{self._user(f"/PlayedItems/{iid}")}'
        req = Request(url, data=b'', headers={
            'X-Emby-Authorization': self._auth_header(), 'Content-Length': '0'
        }, method='POST')
        try:
            with urlopen(req, timeout=self.timeout): pass
        except Exception as e:
            log(f'mark_watched: {e}', xbmc.LOGWARNING)

    def toggle_favourite(self, iid, make_fav):
        url    = f'{self.server}{self._user(f"/FavoriteItems/{iid}")}'
        method = 'POST' if make_fav else 'DELETE'
        req    = Request(url, data=b'', headers={
            'X-Emby-Authorization': self._auth_header(), 'Content-Length': '0'
        }, method=method)
        try:
            with urlopen(req, timeout=self.timeout): pass
        except Exception as e:
            log(f'toggle_fav: {e}', xbmc.LOGWARNING)

    def get_item(self, iid):
        # Use the Items endpoint for metadata
        return self._get(self._user(f'/Items/{iid}'), {
            'Fields': 'MediaSources,MediaStreams,Overview,UserData,RunTimeTicks,'
                      'Genres,ProductionYear,OfficialRating,CommunityRating',
        })

    def get_playback_info(self, iid):
        """
        POST {server}/emby/Items/{id}/PlaybackInfo
        Exact URL and payload from EmbyCon downloadutils.get_item_playback_info().
        Returns ALL quality versions as MediaSources in a single response.
        """
        url     = f'{self.server}/emby/Items/{iid}/PlaybackInfo?MaxStreamingBitrate=2147483647'
        payload = json.dumps({
            'UserId':              self.user_id,
            'AutoOpenLiveStream':  True,
            'DeviceProfile': {
                'Name':               'Kodi',
                'MaxStaticBitrate':    2147483647,
                'MaxStreamingBitrate': 2147483647,
                'DirectPlayProfiles':  [
                    {'Type': 'Video'},
                    {'Type': 'Audio'},
                    {'Type': 'Photo'},
                ],
                'TranscodingProfiles': [],
                'ResponseProfiles':    [],
                'ContainerProfiles':   [],
                'CodecProfiles':       [],
                'SubtitleProfiles':    [],
            },
        }).encode()
        req = Request(url, data=payload, headers={
            'X-Emby-Authorization': self._auth_header(),
            'Content-Type':         'application/json',
            'Accept':               'application/json',
        }, method='POST')
        try:
            with urlopen(req, timeout=self.timeout) as r:
                return json.loads(r.read())
        except Exception as e:
            log(f'get_playback_info {iid}: {e}', xbmc.LOGWARNING)
        return None



    # ------------------------------------------------------------------ #
    #
    #  MOVIES — TMDB-equivalent categories
    #
    #  TMDB Popular    = most-played + highest community rating
    #  TMDB Trending   = recently added + community rating boost
    #  TMDB Top Rated  = sorted by CommunityRating DESC
    #  TMDB Now Playing= released within last 60 days (PremiereDate range)
    #  TMDB Upcoming   = PremiereDate in the future / unwatched new arrivals
    #
    # ------------------------------------------------------------------ #

    def _movies(self, extra, widget=False, ck=None, cttl=120):
        base = {'IncludeItemTypes': 'Movie', 'Recursive': 'true'}
        base.update(extra)
        pfn = self._pw if widget else self._p
        return self._get(self._user('/Items'), params=pfn(base), ck=ck, cttl=cttl)

    def movies_popular(self, limit=50, widget=False):
        """Most-played movies on this server — mirrors TMDB Popular."""
        ck = 'w_movies_popular' if widget else None
        return self._movies({
            'Limit': limit,
            'SortBy': 'PlayCount,CommunityRating',
            'SortOrder': 'Descending',
        }, widget=widget, ck=ck)

    def movies_trending(self, limit=50, widget=False):
        """Recently added with highest ratings — mirrors TMDB Trending."""
        ck = 'w_movies_trending' if widget else None
        return self._movies({
            'Limit': limit,
            'SortBy': 'DateCreated,CommunityRating',
            'SortOrder': 'Descending',
        }, widget=widget, ck=ck)

    def movies_top_rated(self, limit=50, widget=False):
        """Highest community rating — mirrors TMDB Top Rated."""
        ck = 'w_movies_toprated' if widget else None
        return self._movies({
            'Limit': limit,
            'SortBy': 'CommunityRating',
            'SortOrder': 'Descending',
            'MinCommunityRating': 7,
        }, widget=widget, ck=ck)

    def movies_now_playing(self, limit=50):
        """
        Released in the last 90 days — mirrors TMDB Now Playing.
        Uses PremiereDate descending so most-recent theatrical releases come first.
        """
        cutoff = (datetime.datetime.utcnow() - datetime.timedelta(days=90)).strftime('%Y-%m-%dT00:00:00Z')
        return self._movies({
            'Limit': limit,
            'SortBy': 'PremiereDate',
            'SortOrder': 'Descending',
            'MinPremiereDate': cutoff,
        })

    def movies_upcoming(self, limit=50):
        """
        Newly added, unwatched, sorted by premiere date ascending
        — mirrors TMDB Upcoming (movies you haven't seen yet, sorted by release).
        """
        return self._movies({
            'Limit': limit,
            'SortBy': 'PremiereDate',
            'SortOrder': 'Descending',
            'IsPlayed': 'false',
        })

    def movies_recently_added(self, limit=20):
        return self._get(self._user('/Items'), params=self._pw({
            'IncludeItemTypes': 'Movie', 'Recursive': 'true',
            'Limit': limit, 'SortBy': 'DateCreated', 'SortOrder': 'Descending',
        }), ck='w_movies_recent', cttl=120)

    def movies_in_progress(self, limit=20):
        return self._get(self._user('/Items'), params=self._pw({
            'IncludeItemTypes': 'Movie', 'Recursive': 'true',
            'Limit': limit, 'Filters': 'IsResumable',
            'SortBy': 'DatePlayed', 'SortOrder': 'Descending',
        }), ck='w_movies_inprogress', cttl=60)

    def movies_favourites(self, limit=50):
        return self._movies({'Limit': limit, 'Filters': 'IsFavorite'})

    def movies_random(self, limit=20):
        return self._movies({'Limit': limit, 'SortBy': 'Random'})

    def movies_unwatched(self, start=0, limit=50):
        return self._movies({
            'StartIndex': start, 'Limit': limit,
            'SortBy': 'SortName', 'IsPlayed': 'false',
        })

    def movies_all(self, start=0, limit=50, sort='SortName', order='Ascending',
                   genre=None, year=None, studio=None, search=None):
        ex = {'StartIndex': start, 'Limit': limit, 'SortBy': sort, 'SortOrder': order}
        if genre:  ex['Genres'] = genre
        if year:   ex['Years']  = year
        if studio: ex['Studios'] = studio
        if search: ex['SearchTerm'] = search
        return self._movies(ex)

    def movie_genres(self):
        return self._get('/Genres',
                         {'IncludeItemTypes': 'Movie', 'UserId': self.user_id},
                         ck='movie_genres', cttl=600)

    def movie_studios(self):
        return self._get('/Studios',
                         {'IncludeItemTypes': 'Movie', 'UserId': self.user_id},
                         ck='movie_studios', cttl=600)

    def movie_years(self):
        data = self.movies_all(limit=2000, sort='ProductionYear', order='Descending')
        if not data:
            return []
        return sorted(
            {str(i['ProductionYear']) for i in data.get('Items', []) if i.get('ProductionYear')},
            reverse=True
        )

    # ------------------------------------------------------------------ #
    #
    #  TV SHOWS — TMDB-equivalent categories
    #
    #  TMDB Popular      = most-played series
    #  TMDB Trending     = recently added + rating
    #  TMDB Top Rated    = CommunityRating DESC
    #  TMDB On The Air   = currently airing (IsAiring=true)
    #  TMDB Airing Today = airing today (IsAiringToday=true)
    #
    # ------------------------------------------------------------------ #

    def _shows(self, extra, widget=False, ck=None, cttl=120):
        base = {'IncludeItemTypes': 'Series', 'Recursive': 'true'}
        base.update(extra)
        pfn = self._pw if widget else self._p
        return self._get(self._user('/Items'), params=pfn(base), ck=ck, cttl=cttl)

    def shows_popular(self, limit=50, widget=False):
        ck = 'w_shows_popular' if widget else None
        return self._shows({
            'Limit': limit,
            'SortBy': 'PlayCount,CommunityRating',
            'SortOrder': 'Descending',
        }, widget=widget, ck=ck)

    def shows_trending(self, limit=50, widget=False):
        ck = 'w_shows_trending' if widget else None
        return self._shows({
            'Limit': limit,
            'SortBy': 'DateCreated,CommunityRating',
            'SortOrder': 'Descending',
        }, widget=widget, ck=ck)

    def shows_top_rated(self, limit=50, widget=False):
        ck = 'w_shows_toprated' if widget else None
        return self._shows({
            'Limit': limit,
            'SortBy': 'CommunityRating',
            'SortOrder': 'Descending',
            'MinCommunityRating': 7,
        }, widget=widget, ck=ck)

    def shows_on_air(self, limit=50):
        """Series currently airing — mirrors TMDB On The Air."""
        return self._shows({
            'Limit': limit,
            'SortBy': 'SortName',
            'IsAiring': 'true',
        })

    def shows_airing_today(self, limit=50):
        """Series airing today — mirrors TMDB Airing Today."""
        return self._shows({
            'Limit': limit,
            'SortBy': 'SortName',
            'IsAiringToday': 'true',
        })

    def shows_recently_added(self, limit=20):
        return self._get(self._user('/Items'), params=self._pw({
            'IncludeItemTypes': 'Series', 'Recursive': 'true',
            'Limit': limit, 'SortBy': 'DateCreated', 'SortOrder': 'Descending',
        }), ck='w_shows_recent', cttl=120)

    def shows_in_progress(self, limit=20):
        return self._get(self._user('/Items'), params=self._pw({
            'IncludeItemTypes': 'Episode', 'Recursive': 'true',
            'Limit': limit, 'Filters': 'IsResumable',
            'SortBy': 'DatePlayed', 'SortOrder': 'Descending',
        }), ck='w_shows_inprogress', cttl=60)

    def continue_watching(self, limit=25):
        """
        Continue Watching using Emby's dedicated /Items/Resume endpoint.
        This is the same source Emby's own home screen uses — reflects
        cross-device playback state in real time with no caching.
        """
        return self._get(self._user('/Items/Resume'), params=self._pw({
            'IncludeItemTypes': 'Movie,Episode',
            'Recursive':        'true',
            'Limit':            limit,
        }))  # no cache — live cross-device state

    def shows_favourites(self, limit=50):
        return self._shows({'Limit': limit, 'Filters': 'IsFavorite'})

    def shows_unwatched(self, start=0, limit=50):
        return self._shows({
            'StartIndex': start, 'Limit': limit,
            'SortBy': 'SortName', 'IsPlayed': 'false',
        })

    def shows_all(self, start=0, limit=50, sort='SortName', order='Ascending',
                  genre=None, search=None):
        ex = {'StartIndex': start, 'Limit': limit, 'SortBy': sort, 'SortOrder': order}
        if genre:  ex['Genres'] = genre
        if search: ex['SearchTerm'] = search
        return self._shows(ex)

    def show_genres(self):
        return self._get('/Genres',
                         {'IncludeItemTypes': 'Series', 'UserId': self.user_id},
                         ck='show_genres', cttl=600)

    def next_up(self, limit=20, series_id=None):
        p = {
            'UserId': self.user_id, 'Limit': limit,
            'Fields': 'BasicSyncInfo,Overview,UserData,RunTimeTicks,SeriesId',
            'EnableImageTypes': 'Primary,Backdrop,Thumb', 'ImageTypeLimit': 1,
        }
        if series_id:
            p['SeriesId'] = series_id
        return self._get('/Shows/NextUp', params=p)

    def get_next_episode(self, series_id, season_number, episode_number):
        """
        Return the next unwatched episode item after season_number/episode_number,
        or None if we're at the end of the series.
        Uses /Shows/NextUp with SeriesId — Emby tracks watch state and returns
        the correct next item automatically.
        """
        try:
            data = self.next_up(limit=1, series_id=series_id)
            items = (data or {}).get('Items', [])
            if items:
                return items[0]
        except Exception as e:
            log(f'get_next_episode error: {e}', xbmc.LOGWARNING)
        return None

    def seasons(self, series_id):
        return self._get(f'/Shows/{series_id}/Seasons', {
            'UserId': self.user_id,
            'Fields': 'BasicSyncInfo,Overview,UserData',
            'EnableImageTypes': 'Primary,Backdrop,Thumb',
        })

    def episodes(self, series_id, season_id):
        # Fetch ALL episode items in the season — including duplicate quality
        # versions (4K item + 1080p item for the same episode number).
        # GroupItemsIntoCollections=false prevents Emby collapsing duplicates.
        # High Limit ensures we get every item even for long seasons.
        return self._get(self._user('/Items'), self._p({
            'ParentId':                   season_id,
            'SeriesId':                   series_id,
            'IncludeItemTypes':           'Episode',
            'Recursive':                  'false',
            'SortBy':                     'IndexNumber,SortName',
            'SortOrder':                  'Ascending',
            'GroupItemsIntoCollections':  'false',
            'Limit':                      '500',
        }))

    def search(self, query, limit=50):
        """
        Search Emby directly using the Items endpoint with SearchTerm.
        Returns full item data including MediaSources so results are
        immediately playable. No TMDB involved.
        """
        return self._get(self._user('/Items'), {
            'SearchTerm':       query,
            'UserId':           self.user_id,
            'IncludeItemTypes': 'Movie,Series,Episode',
            'Recursive':        'true',
            'Limit':            limit,
            'Fields':           _FIELDS,
            'EnableImageTypes': 'Primary,Backdrop,Thumb',
            'ImageTypeLimit':   1,
            'SortBy':           'SortName',
            'SortOrder':        'Ascending',
        })

    def items_by_provider_id(self, provider, provider_id, item_type='Movie'):
        """
        Find Emby items matching a provider ID (tmdb, imdb, tvdb).
        Returns list of item dicts, or [].
        """
        data = self._get(self._user('/Items'), {
            'AnyProviderIdEquals': f'{provider}.{provider_id}',
            'IncludeItemTypes':    item_type,
            'Recursive':           'true',
            'Fields':              'ProviderIds,MediaSources',
            'Limit':               5,
        })
        return (data or {}).get('Items', [])

    def episode_by_number(self, series_id, season_number, episode_number):
        """
        Fetch a specific episode by S/E number from an Emby series.
        Returns the episode item dict, or None.
        Emby's SeasonNumber/EpisodeNumber query params are unreliable —
        fetch all episodes and filter client-side.
        """
        data = self._get(self._user('/Items'), {
            'ParentId':            series_id,
            'IncludeItemTypes':    'Episode',
            'Recursive':           'true',
            'Fields':              _FIELDS,
            'EnableImageTypes':    'Primary,Thumb',
            'ImageTypeLimit':      1,
            'Limit':               500,
        })
        for item in (data or {}).get('Items', []):
            if (item.get('ParentIndexNumber') == season_number and
                    item.get('IndexNumber') == episode_number):
                return item
        return None
