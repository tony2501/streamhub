"""
StreamHub - Real-Debrid / Torrentio client

Flow:
  1. Query Torrentio for RD-cached streams by IMDB id
  2. Filter: cached only, <= 10 GB
  3. Resolve each torrent hash + file index via RD /torrents/instantAvailability
     then /torrents/addMagnet + /torrents/selectFiles + /torrents/info
     to get the final unrestricted HTTP link — OR use /unrestrict/link directly
     when Torrentio provides a full magnet/info_hash.
  4. Return list of dicts ready to drop into the quality picker.

Label format:  [RD] 4K HDR — The.Movie.Name.2160p.DV.mkv
"""

import json
import re
import time
from urllib.parse import urlencode, quote
from urllib.request import urlopen, Request
from urllib.error import URLError, HTTPError

import xbmc

from resources.lib.kodi_utils import log, get_setting, set_setting

_TORRENTIO_BASE = 'https://torrentio.strem.fun'
_RD_BASE        = 'https://api.real-debrid.com/rest/1.0'
_MAX_BYTES      = 10 * 1024 * 1024 * 1024   # 10 GB hard cap
_TIMEOUT        = 15


# ------------------------------------------------------------------ #
# Helpers
# ------------------------------------------------------------------ #

def _get(url, token=None, timeout=_TIMEOUT):
    headers = {'Accept': 'application/json'}
    if token:
        headers['Authorization'] = f'Bearer {token}'
    req = Request(url, headers=headers)
    try:
        with urlopen(req, timeout=timeout) as r:
            return json.loads(r.read())
    except HTTPError as e:
        log(f'RD HTTP {e.code} {url}', xbmc.LOGWARNING)
    except URLError as e:
        log(f'RD URLError {url}: {e.reason}', xbmc.LOGWARNING)
    except Exception as e:
        log(f'RD error {url}: {e}', xbmc.LOGWARNING)
    return None


def _post(url, data, token):
    body = urlencode(data).encode()
    req  = Request(url, data=body, headers={
        'Authorization': f'Bearer {token}',
        'Content-Type':  'application/x-www-form-urlencoded',
        'Accept':        'application/json',
    }, method='POST')
    try:
        with urlopen(req, timeout=_TIMEOUT) as r:
            return json.loads(r.read()) if r.length else {}
    except HTTPError as e:
        body_txt = ''
        try: body_txt = e.read().decode('utf-8', errors='replace')
        except: pass
        log(f'RD POST HTTP {e.code} {url}: {body_txt}', xbmc.LOGWARNING)
    except Exception as e:
        log(f'RD POST error {url}: {e}', xbmc.LOGWARNING)
    return None


def _delete(url, token):
    req = Request(url, headers={'Authorization': f'Bearer {token}'}, method='DELETE')
    try:
        with urlopen(req, timeout=_TIMEOUT): pass
    except Exception as e:
        log(f'RD DELETE {url}: {e}', xbmc.LOGWARNING)


# ------------------------------------------------------------------ #
# Size parsing
# ------------------------------------------------------------------ #

def _parse_size(size_str):
    """
    Parse Torrentio size string → bytes.
    Formats seen: '8.23 GB', '1.2 TB', '900 MB', '4.1GB'
    Returns 0 if unparseable (treated as unknown, allowed through).
    """
    if not size_str:
        return 0
    m = re.search(r'([\d.]+)\s*(GB|MB|TB|KB)', str(size_str), re.IGNORECASE)
    if not m:
        return 0
    val  = float(m.group(1))
    unit = m.group(2).upper()
    return int(val * {'KB': 1024, 'MB': 1024**2, 'GB': 1024**3, 'TB': 1024**4}[unit])


# ------------------------------------------------------------------ #
# Resolution / HDR label from filename
# ------------------------------------------------------------------ #

def _label_from_name(name):
    """
    Extract resolution + HDR tag from torrent filename.
    Returns e.g. '4K HDR', '4K DV', '1080p', '720p'
    """
    n = name.lower()
    res = ''
    if re.search(r'\b(2160p|4k|uhd)\b', n):
        res = '4K'
    elif re.search(r'\b1080p\b', n):
        res = '1080p'
    elif re.search(r'\b720p\b', n):
        res = '720p'
    elif re.search(r'\b480p\b', n):
        res = '480p'

    hdr = ''
    if re.search(r'\b(dv|dolby.?vision)\b', n):
        hdr = 'DV'
    elif re.search(r'\bhdr10\+\b', n):
        hdr = 'HDR10+'
    elif re.search(r'\bhdr\b', n):
        hdr = 'HDR'

    parts = [p for p in [res, hdr] if p]
    return ' '.join(parts) if parts else 'Unknown'


def _sort_key(stream):
    """Sort RD results: best resolution first, then largest file first."""
    res_order = {'4K': 0, '4K DV': 0, '4K HDR': 0, '4K HDR10+': 0,
                 '1080p': 1, '720p': 2, '480p': 3, 'Unknown': 4}
    res = _label_from_name(stream.get('_name', ''))
    return (res_order.get(res, 4), -stream.get('_size', 0))  # negative = largest first


# ------------------------------------------------------------------ #
# Torrentio query
# ------------------------------------------------------------------ #

def _torrentio_streams(imdb_id, media_type, season=None, episode=None, rd_token=None):
    """
    Query Torrentio for RD-cached streams.
    media_type: 'movie' or 'series'
    Returns raw Torrentio stream list (dicts).
    """
    if not rd_token:
        return []

    # Torrentio URL format: config options in ONE path segment, pipe-separated.
    # The | must be percent-encoded as %7C to pass through Cloudflare WAF.
    # e.g. /qualityfilter=other,scr,cam%7Crealdebrid=TOKEN/stream/movie/tt123.json
    opts = f'qualityfilter=other,scr,cam,unknown%7Crealdebrid={rd_token}'
    if media_type == 'series' and season and episode:
        path = f'{_TORRENTIO_BASE}/{opts}/stream/series/{imdb_id}:{int(season)}:{int(episode)}.json'
    else:
        path = f'{_TORRENTIO_BASE}/{opts}/stream/movie/{imdb_id}.json'

    log(f'Torrentio URL: {path}', xbmc.LOGINFO)

    # Torrentio (behind Cloudflare) blocks Python's default urllib UA.
    # Must send a browser-like User-Agent.
    from urllib.request import Request as _Req
    req = _Req(path, headers={
        'Accept':     'application/json',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    })
    try:
        with urlopen(req, timeout=20) as r:
            data = json.loads(r.read())
    except Exception as e:
        log(f'Torrentio fetch error: {e}', xbmc.LOGERROR)
        data = {}

    streams = (data or {}).get('streams', [])
    log(f'Torrentio: {len(streams)} streams returned for {imdb_id}', xbmc.LOGINFO)
    return streams


# ------------------------------------------------------------------ #
# Resolve RD stream to direct HTTP URL
# ------------------------------------------------------------------ #

def _resolve_rd_stream(stream, token):
    """
    Resolve a Torrentio stream dict to a direct playable HTTP URL.

    Modern Torrentio (2025+) returns a pre-resolved URL in the stream's 'url'
    field, format:
      https://torrentio.strem.fun/resolve/realdebrid/<key>/<hash>/null/0/filename.mp4

    This URL is directly playable by Kodi — no additional RD API calls needed.
    We fall back to the old addMagnet flow only if no url is present.
    """
    url = stream.get('url', '')
    if url:
        log(f'RD: using Torrentio pre-resolved URL', xbmc.LOGDEBUG)
        return url

    # Legacy fallback: infoHash present but no url
    info_hash = stream.get('infoHash', '').lower()
    file_idx  = stream.get('fileIdx')

    if not info_hash:
        log('RD: no url and no infoHash — cannot resolve', xbmc.LOGWARNING)
        return None

    magnet = f'magnet:?xt=urn:btih:{info_hash}'
    add_data = _post(f'{_RD_BASE}/torrents/addMagnet', {'magnet': magnet}, token)
    if not add_data:
        return None

    torrent_id = add_data.get('id', '')
    if not torrent_id:
        return None

    try:
        files_param = str(int(file_idx) + 1) if file_idx is not None else 'all'
        _post(f'{_RD_BASE}/torrents/selectFiles/{torrent_id}', {'files': files_param}, token)

        for _ in range(10):
            info   = _get(f'{_RD_BASE}/torrents/info/{torrent_id}', token=token)
            links  = (info or {}).get('links', [])
            status = (info or {}).get('status', '')
            if links and status in ('downloaded', 'waiting_files_selection', 'queued'):
                unres = _post(f'{_RD_BASE}/unrestrict/link', {'link': links[0]}, token)
                return (unres or {}).get('download')
            if status in ('error', 'virus', 'dead', 'magnet_error'):
                break
            time.sleep(1)
        return None
    finally:
        _delete(f'{_RD_BASE}/torrents/delete/{torrent_id}', token)


# ------------------------------------------------------------------ #
# Public API
# ------------------------------------------------------------------ #

class RDClient:
    def __init__(self):
        # Prefer the OAuth access token; fall back to legacy api key setting
        self.token = get_setting('rd_access_token', '') or get_setting('rd_api_key', '')

    def is_configured(self):
        return bool(self.token)

    def get_streams(self, imdb_id, media_type='movie', season=None, episode=None):
        """
        Fetch RD-cached streams for an item from Torrentio.

        Returns list of dicts:
          {
            'label':   '[RD] 4K DV — The.Movie.Name.2160p...',
            'label2':  '8.23 GB  |  cached',
            'url':     'https://...',       # resolved direct HTTP link
            '_size':   8829956096,
            '_name':   'The.Movie.Name.2160p.DV.mkv',
          }

        Only returns cached results under the 10 GB cap.
        Emby sources go first in the picker — caller appends these after.
        """
        if not self.token or not imdb_id:
            return []

        log(f'RD: fetching streams for {imdb_id} ({media_type})', xbmc.LOGINFO)

        raw = _torrentio_streams(
            imdb_id, media_type,
            season=season, episode=episode,
            rd_token=self.token,
        )

        if not raw:
            log(f'RD: Torrentio returned no streams for {imdb_id}', xbmc.LOGINFO)
            return []

        # Parse and pre-filter by size
        candidates = []
        for s in raw:
            title = s.get('title', '') or s.get('name', '')
            # Torrentio title format:
            # "The.Movie.Name.2160p...\n👤 12 💾 8.23 GB ⚙️ YTS"
            # Split on newline to get filename vs metadata
            lines     = title.split('\n')
            name      = lines[0].strip() if lines else title
            size_str  = ''
            for line in lines[1:]:
                m = re.search(r'[\d.]+\s*(?:GB|MB|TB|KB)', line, re.IGNORECASE)
                if m:
                    size_str = m.group(0)
                    break

            size_bytes = _parse_size(size_str)

            # Drop anything over 10 GB (size_bytes==0 means unknown — let through)
            if size_bytes > _MAX_BYTES:
                log(f'RD: skipping {name} — {size_str} > 10 GB', xbmc.LOGDEBUG)
                continue

            candidates.append({
                '_raw':  s,
                '_name': name,
                '_size': size_bytes,
                '_size_str': size_str or '? GB',
            })

        if not candidates:
            log(f'RD: all streams filtered out (size cap) for {imdb_id}', xbmc.LOGINFO)
            return []

        # Filter: only keep cached streams. Torrentio labels uncached as "[RD download]"
        # in the stream name field. Cached streams are "[RD+]". That's the only
        # reliable signal — don't filter on URL pattern as it varies.
        def _is_cached(c):
            raw   = c['_raw']
            url   = raw.get('url', '')
            sname = (raw.get('name', '') or '').lower()
            if not url:
                return False
            if '[rd download]' in sname:
                return False
            return True

        verified = [c for c in candidates if _is_cached(c)]

        log(f'RD: {len(verified)}/{len(candidates)} cached streams for {imdb_id}', xbmc.LOGINFO)

        if not verified:
            return []

        # Sort best quality first
        verified.sort(key=lambda c: _sort_key(c))

        # Resolve direct URLs
        results = []
        for c in verified:
            url = _resolve_rd_stream(c['_raw'], self.token)
            if not url:
                log(f'RD: could not resolve URL for {c["_name"]}', xbmc.LOGWARNING)
                continue

            res_tag = _label_from_name(c['_name'])
            label   = f'[RD] {res_tag} \u2014 {c["_name"]}'
            label2  = f'{c["_size_str"]}  |  RD cached'

            results.append({
                'label':  label,
                'label2': label2,
                'url':    url,
                '_size':  c['_size'],
                '_name':  c['_name'],
            })

        log(f'RD: returning {len(results)} resolved streams', xbmc.LOGINFO)
        return results
