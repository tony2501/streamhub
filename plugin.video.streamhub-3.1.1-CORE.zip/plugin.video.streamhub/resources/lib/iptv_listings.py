"""
StreamHub - IPTV / Live TV Listings
"""

import re
import urllib.parse as _up
from datetime import datetime
import xbmc
import xbmcgui
import xbmcplugin

from resources.lib.kodi_utils import (
    HANDLE, add_dir_item, end_directory, end_directory_failed,
    plugin_url, notify, log, get_bool
)
from resources.lib.channel_logos import get_logo


def iptv_menu(xtream):
    if not xtream.is_configured():
        notify('IPTV not configured — use IPTV Setup in the menu')
        add_dir_item('IPTV Setup', 'IPTV_SETUP', 'DefaultAddonPVRClient.png', is_folder=False)
        end_directory('files')
        return

    add_dir_item('Live TV', 'IPTV_LIVE_CATS', 'DefaultAddonPVRClient.png')
    end_directory('files')


def list_live_categories(xtream):
    cats = xtream.get_live_categories()
    if not cats:
        notify('No IPTV categories found')
        end_directory_failed()
        return

    for cat in cats:
        name = cat.get('category_name', 'Unknown')
        if not re.match(r'^(UK|IT)\b', name.strip(), re.IGNORECASE):
            continue
        cid = str(cat.get('category_id', ''))
        add_dir_item(name, 'IPTV_LIVE_STREAMS',
                     'DefaultAddonPVRClient.png', category_id=cid)

    end_directory('files', cache=True)


def list_live_streams(xtream, category_id):
    streams = xtream.get_live_streams(category_id)
    if not streams:
        notify('No channels in this category')
        end_directory_failed()
        return

    prefer_ts = get_bool('xtream_use_ts', False)

    # Fetch EPG for all streams in parallel — 2s max wait
    stream_ids = [str(s.get('stream_id', '')) for s in streams]
    epg_data   = xtream.get_epg_batch(stream_ids)

    def _fmt_time(ts):
        """Format EPG timestamp for display."""
        try:
            dt = datetime.strptime(ts[:19], '%Y-%m-%d %H:%M:%S')
            return dt.strftime('%H:%M')
        except Exception:
            return ''

    for s in streams:
        sid  = str(s.get('stream_id', ''))
        name = s.get('name', 'Unknown').strip()
        icon = s.get('stream_icon', '')
        logo = get_logo(name, fallback_url=icon)

        # Build EPG info for this channel
        epg       = epg_data.get(sid, [])
        now_entry = epg[0] if epg else None
        nxt_entry = epg[1] if len(epg) > 1 else None

        # Label: channel name + now-playing title if available
        if now_entry and now_entry.get('title'):
            t_start = _fmt_time(now_entry.get('start', ''))
            t_end   = _fmt_time(now_entry.get('end', ''))
            label   = name
            now_str = f"[B]{now_entry['title']}[/B]"
            if t_start and t_end:
                now_str = f"{t_start}–{t_end}  {now_str}"
        else:
            label   = name
            now_str = ''

        # Plot: now playing + next up
        plot_parts = []
        if now_entry:
            line = now_entry.get('title', '')
            if now_entry.get('description'):
                line += f"\n{now_entry['description']}"
            t_s = _fmt_time(now_entry.get('start', ''))
            t_e = _fmt_time(now_entry.get('end', ''))
            if t_s and t_e:
                line = f"[B]Now ({t_s}–{t_e}):[/B] {line}"
            else:
                line = f"[B]Now:[/B] {line}"
            plot_parts.append(line)
        if nxt_entry:
            line = nxt_entry.get('title', '')
            t_s  = _fmt_time(nxt_entry.get('start', ''))
            t_e  = _fmt_time(nxt_entry.get('end', ''))
            if t_s and t_e:
                line = f"[B]Next ({t_s}–{t_e}):[/B] {line}"
            else:
                line = f"[B]Next:[/B] {line}"
            plot_parts.append(line)
        plot = '\n\n'.join(plot_parts)

        route_url = plugin_url('IPTV_PLAY',
                               stream_id=sid,
                               name=_up.quote(name, safe=''),
                               icon=_up.quote(icon, safe=''),
                               use_ts='1' if prefer_ts else '0')

        li = xbmcgui.ListItem(label)
        li.setProperty('IsPlayable', 'true')

        if logo:
            li.setArt({'thumb': logo, 'icon': logo, 'clearlogo': logo})

        # Set EPG info on the list item
        info = {'title': name, 'mediatype': 'video', 'plot': plot}
        if now_entry:
            info['tagline'] = now_str
        li.setInfo('video', info)

        # EPG properties for skins that read them
        if now_entry:
            li.setProperty('EPG.Title',       now_entry.get('title', ''))
            li.setProperty('EPG.Plot',         now_entry.get('description', ''))
            li.setProperty('EPG.StartTime',    _fmt_time(now_entry.get('start', '')))
            li.setProperty('EPG.EndTime',      _fmt_time(now_entry.get('end', '')))
        if nxt_entry:
            li.setProperty('EPG.Next.Title',   nxt_entry.get('title', ''))
            li.setProperty('EPG.Next.StartTime', _fmt_time(nxt_entry.get('start', '')))

        li.addContextMenuItems([
            ('Play (TS fallback)',  f'PlayMedia({xtream.play_url(sid, prefer_ts=True)})'),
            ('Play (HLS)',          f'PlayMedia({xtream.play_url(sid, prefer_ts=False)})'),
        ])

        xbmcplugin.addDirectoryItem(HANDLE, route_url, li, False)

    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=True)


def play_live_stream(xtream, stream_id, name='', icon='', use_ts=False):
    prefer_ts = use_ts or get_bool('xtream_use_ts', False)
    url = xtream.play_url(stream_id, prefer_ts=prefer_ts)

    decoded_name = _up.unquote(name) if name else stream_id
    decoded_icon = _up.unquote(icon) if icon else ''

    from resources.lib.kodi_utils import iptv_recents_add
    iptv_recents_add(stream_id, decoded_name, decoded_icon)
    log(f'IPTV play + recent recorded: {decoded_name} ({stream_id})', xbmc.LOGINFO)

    li = xbmcgui.ListItem(path=url)
    li.setMimeType('video/mp2t' if prefer_ts else 'application/x-mpegURL')
    li.setContentLookup(False)
    xbmcplugin.setResolvedUrl(HANDLE, True, li)
