"""
StreamHub - TMDB <-> Emby Matcher  (v2 - fast, no full-library scan)

Instead of indexing the whole library, we query Emby directly for each
TMDB ID using the AnyProviderIdEquals filter.  Results are cached so
repeated opens of the same list are instant.

One Emby API call per TMDB result sounds expensive, but:
- We batch by sending all IDs in one call via AnyProviderIdEquals
- Results are cached for 5 minutes (configurable)
- Kodi plugin timeout is ~30s, but we stay well inside it
"""

import json
import xbmc
from resources.lib.kodi_utils import log, cache_get, cache_set, get_int

TMDB_IMG = 'https://image.tmdb.org/t/p'


def _poster(path):
    return f'{TMDB_IMG}/w500{path}' if path else ''

def _backdrop(path):
    return f'{TMDB_IMG}/w1280{path}' if path else ''

def _year(s):
    try:    return int(str(s)[:4])
    except: return 0


# ------------------------------------------------------------------ #
# Public API
# ------------------------------------------------------------------ #

def _best_height(e):
    from resources.lib.kodi_utils import _stream_height
    for ms in e.get('MediaSources', []):
        h = _stream_height(ms)
        if h: return -h
    return 0


def match_movies(tmdb_results, emby_client, limit=50):
    """
    Match TMDB movie results against the Emby library.
    Returns merged items in TMDB order, limited to `limit`.
    """
    if not tmdb_results:
        return []

    # Build lookup from provider IDs
    # { 'tmdb:NNN': tmdb_item, 'imdb:ttNNNN': tmdb_item }
    by_tmdb = {}
    by_imdb = {}
    tmdb_ids = []
    imdb_ids = []
    for t in tmdb_results:
        tid = str(t.get('id', ''))
        iid = t.get('imdb_id', '') or ''
        if tid:
            by_tmdb[tid] = t
            tmdb_ids.append(tid)
        if iid:
            by_imdb[iid] = t
            imdb_ids.append(iid)

    # Fetch matching Emby items — one call using provider ID filters
    emby_map = _fetch_emby_by_provider_ids(emby_client, tmdb_ids, imdb_ids, 'Movie')

    matched = []
    seen_tmdb = set()
    for t in tmdb_results:
        tid = str(t.get('id', ''))
        iid = t.get('imdb_id', '') or ''
        emby_items = emby_map.get(f'tmdb:{tid}') or emby_map.get(f'imdb:{iid}') or []
        if not emby_items or tid in seen_tmdb:
            continue
        seen_tmdb.add(tid)
        # Sort highest resolution first, use best as primary display item
        emby_items = sorted(emby_items, key=_best_height)
        primary = _merge_movie(t, emby_items[0])
        # Store all version IDs so the picker can load them at play time
        primary['_version_ids'] = [e['Id'] for e in emby_items]
        matched.append(primary)
        if len(matched) >= limit:
            break

    log(f'match_movies: {len(tmdb_results)} TMDB -> {len(matched)} matched', xbmc.LOGINFO)
    return matched


def match_tvshows(tmdb_results, emby_client, limit=50):
    """Match TMDB TV results against the Emby library."""
    if not tmdb_results:
        return []

    by_tmdb = {}
    tmdb_ids = []
    for t in tmdb_results:
        tid = str(t.get('id', ''))
        if tid:
            by_tmdb[tid] = t
            tmdb_ids.append(tid)

    emby_map = _fetch_emby_by_provider_ids(emby_client, tmdb_ids, [], 'Series')

    matched = []
    seen_tmdb = set()
    for t in tmdb_results:
        tid = str(t.get('id', ''))
        emby_items = emby_map.get(f'tmdb:{tid}') or []
        if not emby_items or tid in seen_tmdb:
            continue
        seen_tmdb.add(tid)
        emby_items = sorted(emby_items, key=_best_height)
        primary = _merge_show(t, emby_items[0])
        primary['_version_ids'] = [e['Id'] for e in emby_items]
        matched.append(primary)
        if len(matched) >= limit:
            break

    log(f'match_tvshows: {len(tmdb_results)} TMDB -> {len(matched)} matched', xbmc.LOGINFO)
    return matched


# ------------------------------------------------------------------ #
# Emby lookup by provider IDs — single batched API call
# ------------------------------------------------------------------ #

_FIELDS = (
    'BasicSyncInfo,Genres,Overview,Studios,Taglines,UserData,'
    'MediaSources,RunTimeTicks,OfficialRating,CommunityRating,'
    'ProductionYear,ProviderIds,MediaStreams'
)


def _fetch_emby_by_provider_ids(client, tmdb_ids, imdb_ids, item_type):
    """
    Ask Emby for all items whose ProviderIds contain any of the given
    TMDB or IMDB IDs.  Uses the AnyProviderIdEquals parameter which
    accepts a comma-separated list of  'Provider.ID=value' pairs.

    Returns a dict:
        { 'tmdb:NNN': emby_item, 'imdb:ttNNN': emby_item, ... }
    """
    if not tmdb_ids and not imdb_ids:
        return {}

    # Build cache key from sorted IDs
    cache_key = f'emby_match_{item_type}_' + '_'.join(sorted(tmdb_ids[:20]))
    cached = cache_get(cache_key)
    if cached is not None:
        return cached

    # Build AnyProviderIdEquals string
    # Format: "Tmdb.123,Tmdb.456,Imdb.tt123"
    pairs = []
    for tid in tmdb_ids:
        pairs.append(f'Tmdb.{tid}')
    for iid in imdb_ids:
        pairs.append(f'Imdb.{iid}')

    # Split into batches of 50 to avoid URL length issues
    result_map = {}
    batch_size = 50
    for i in range(0, len(pairs), batch_size):
        batch = pairs[i:i + batch_size]
        params = {
            'UserId':                client.user_id,
            'IncludeItemTypes':      item_type,
            'Recursive':             'true',
            'AnyProviderIdEquals':   ','.join(batch),
            'Fields':                _FIELDS,
            'EnableImageTypes':      'Primary,Backdrop,Thumb',
            'ImageTypeLimit':        1,
        }
        data = client._get(f'/Users/{client.user_id}/Items', params=params)
        if not data:
            continue
        for item in data.get('Items', []):
            pids = item.get('ProviderIds', {})
            tid  = str(pids.get('Tmdb', '') or pids.get('tmdb', ''))
            iid  = pids.get('Imdb', '') or pids.get('imdb', '')
            # Store ALL versions — if a title has 4K + 1080p as separate Emby
            # items they share the same provider ID. Keep a list per key so
            # both are shown in the listing with their resolution badges.
            for key in ([f'tmdb:{tid}'] if tid else []) + ([f'imdb:{iid}'] if iid else []):
                result_map.setdefault(key, []).append(item)

    ttl = get_int('cache_ttl', 5) * 60
    cache_set(cache_key, result_map, ttl)
    log(f'Emby provider lookup ({item_type}): {len(pairs)} pairs -> {len(result_map)} results', xbmc.LOGINFO)
    return result_map


# ------------------------------------------------------------------ #
# Merge: TMDB metadata + Emby stream data
# ------------------------------------------------------------------ #

def _merge_movie(tmdb, emby):
    merged = dict(emby)
    merged['Name']            = tmdb.get('title') or emby.get('Name', '')
    merged['Overview']        = tmdb.get('overview') or emby.get('Overview', '')
    merged['CommunityRating'] = tmdb.get('vote_average') or emby.get('CommunityRating', 0)
    merged['ProductionYear']  = _year(tmdb.get('release_date', '')) or emby.get('ProductionYear', 0)
    merged['_tmdb_poster']    = _poster(tmdb.get('poster_path', ''))
    merged['_tmdb_backdrop']  = _backdrop(tmdb.get('backdrop_path', ''))
    merged['_use_tmdb_art']   = True
    return merged


def _merge_show(tmdb, emby):
    merged = dict(emby)
    merged['Name']            = tmdb.get('name') or emby.get('Name', '')
    merged['Overview']        = tmdb.get('overview') or emby.get('Overview', '')
    merged['CommunityRating'] = tmdb.get('vote_average') or emby.get('CommunityRating', 0)
    merged['ProductionYear']  = _year(tmdb.get('first_air_date', '')) or emby.get('ProductionYear', 0)
    merged['_tmdb_poster']    = _poster(tmdb.get('poster_path', ''))
    merged['_tmdb_backdrop']  = _backdrop(tmdb.get('backdrop_path', ''))
    merged['_use_tmdb_art']   = True
    return merged
