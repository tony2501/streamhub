"""
StreamHub - Bingie Repository + Skin Installer

On first run:
1. Copies the bundled repository.bingie zip to a temp location
2. Installs it via InstallAddon builtin
3. Then installs skin.bingie from the repo via InstallAddon

Runs silently in a background thread so it never blocks the UI.
Only installs once (tracked by marker file).
"""

import os
import shutil
import threading
import time
import xbmc
import xbmcvfs
import xbmcaddon
from resources.lib.kodi_utils import log, notify


def _marker_file():
    data_dir = xbmcvfs.translatePath(
        'special://userdata/addon_data/plugin.video.streamhub/'
    )
    if not xbmcvfs.exists(data_dir):
        xbmcvfs.mkdirs(data_dir)
    return os.path.join(data_dir, '.bingie_installed')


def _is_installed(addon_id):
    """Check if an addon is already installed."""
    try:
        xbmcaddon.Addon(addon_id)
        return True
    except Exception:
        return False


def _do_install():
    """Run in background thread — install repo then skin."""
    # Give Kodi a moment to fully settle after addon load
    time.sleep(3)

    # --- Step 1: Install the Bingie repository ---
    if not _is_installed('repository.bingie'):
        addon_path = xbmcaddon.Addon('plugin.video.streamhub').getAddonInfo('path')
        repo_zip = os.path.join(addon_path, 'resources', 'data', 'repository_bingie-1_0_0.zip')

        if not os.path.exists(repo_zip):
            log('StreamHub: Bingie repo zip not found, skipping install', xbmc.LOGWARNING)
            return

        # Copy to a temp path Kodi can access
        tmp = xbmcvfs.translatePath('special://temp/repository_bingie-1_0_0.zip')
        try:
            shutil.copy2(repo_zip, tmp)
        except Exception as e:
            log(f'StreamHub: failed to copy repo zip: {e}', xbmc.LOGWARNING)
            return

        log('StreamHub: installing Bingie repository...', xbmc.LOGINFO)
        xbmc.executebuiltin(f'InstallAddon(repository.bingie)', True)
        time.sleep(2)

        # If builtin didn't work, try installing from zip directly
        if not _is_installed('repository.bingie'):
            xbmc.executebuiltin(f'InstallFromZip({tmp})', True)
            time.sleep(3)
    else:
        log('StreamHub: Bingie repository already installed', xbmc.LOGDEBUG)

    # --- Step 2: Install skin.bingie from the repo ---
    if not _is_installed('skin.bingie'):
        log('StreamHub: installing skin.bingie...', xbmc.LOGINFO)
        xbmc.executebuiltin('InstallAddon(skin.bingie)', True)
        time.sleep(5)

        if _is_installed('skin.bingie'):
            log('StreamHub: skin.bingie installed successfully', xbmc.LOGINFO)
            notify('StreamHub: Bingie skin installed ✓', ms=3000)
        else:
            log('StreamHub: skin.bingie install may need manual confirmation', xbmc.LOGWARNING)
    else:
        log('StreamHub: skin.bingie already installed', xbmc.LOGDEBUG)

    # Write marker so we don't attempt again
    try:
        with open(_marker_file(), 'w') as f:
            f.write('installed')
    except Exception as e:
        log(f'StreamHub: could not write bingie marker: {e}', xbmc.LOGWARNING)


def install_bingie(force=False):
    """
    Trigger Bingie repo + skin installation in a background thread.
    Skips if already installed unless force=True.
    """
    if not force and os.path.exists(_marker_file()):
        log('StreamHub: Bingie already installed, skipping', xbmc.LOGDEBUG)
        return

    if _is_installed('skin.bingie') and not force:
        # Already on system, just write marker and skip
        try:
            with open(_marker_file(), 'w') as f:
                f.write('installed')
        except Exception:
            pass
        return

    threading.Thread(target=_do_install, daemon=True).start()
