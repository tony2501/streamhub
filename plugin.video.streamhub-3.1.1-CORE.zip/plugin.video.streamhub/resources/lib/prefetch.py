"""
StreamHub - Background Widget Prefetcher

Fires parallel Emby requests for every home-screen widget endpoint
the moment the main menu loads. By the time Bingie renders its rows,
all responses are already in the in-memory+disc cache.

Total wall-clock time = slowest single Emby request (~200-400ms).
Subsequent widget loads = <5ms (memory hit).
"""

import threading
import xbmc
from resources.lib.kodi_utils import log, cache_get


def _prefetch_all(client):
    """
    Prefetch all widget endpoints in parallel background threads.
    Each task checks its cache key first — already-cached items are
    skipped instantly with zero network cost.
    """
    # (method_name, kwargs, cache_key_to_check)
    tasks = [
        ('continue_watching',     {},                          'w_continue_watching'),
        ('movies_recently_added', {'limit': 20},               'w_movies_recent'),
        ('movies_in_progress',    {'limit': 20},               'w_movies_inprogress'),
        ('shows_recently_added',  {'limit': 20},               'w_shows_recent'),
        ('shows_in_progress',     {'limit': 20},               'w_shows_inprogress'),
        ('movies_popular',        {'limit': 20, 'widget': True}, 'w_movies_popular'),
        ('movies_top_rated',      {'limit': 20, 'widget': True}, 'w_movies_toprated'),
    ]

    def _run(method_name, kwargs, ck):
        if ck and cache_get(ck) is not None:
            return  # already warm, skip
        try:
            fn = getattr(client, method_name)
            fn(**kwargs)
            log(f'Prefetch done: {method_name}', xbmc.LOGDEBUG)
        except Exception as e:
            log(f'Prefetch error {method_name}: {e}', xbmc.LOGWARNING)

    threads = [
        threading.Thread(target=_run, args=(name, kw, ck), daemon=True)
        for name, kw, ck in tasks
    ]
    for t in threads:
        t.start()
    log(f'Prefetch: {len(threads)} widget endpoints warming in background', xbmc.LOGINFO)
    # No join — background only, never block the menu render


def start(client):
    """Entry point — wraps _prefetch_all in one thread so main menu returns immediately."""
    threading.Thread(target=_prefetch_all, args=(client,), daemon=True).start()
