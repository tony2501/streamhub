"""
StreamHub - TMDB API Client
Fetches real TMDB lists (Popular, Trending, Top Rated, Now Playing, Upcoming,
On The Air, Airing Today) and returns TMDB IDs + IMDb IDs for Emby matching.

TMDB API key is stored in addon settings. Users can get a free key at:
https://www.themoviedb.org/settings/api
"""

import json
from urllib.parse import urlencode
from urllib.request import urlopen, Request
from urllib.error import URLError, HTTPError

import xbmc

from resources.lib.kodi_utils import log, get_setting, cache_get, cache_set

TMDB_BASE  = 'https://api.themoviedb.org/3'
TMDB_IMAGE = 'https://image.tmdb.org/t/p'


class TMDbAPI:
    def __init__(self):
        self.api_key = get_setting('tmdb_api_key') or '435fb4fb5912e6d5f5b80c736bf289e1'

    def is_configured(self):
        return bool(self.api_key)

    def _get(self, path, params=None, cache_key=None, cache_ttl=3600):
        if not self.api_key:
            return None
        if cache_key:
            cached = cache_get(cache_key)
            if cached is not None:
                return cached
        p = {'api_key': self.api_key, 'language': 'en-US'}
        if params:
            p.update(params)
        url = f'{TMDB_BASE}{path}?{urlencode(p)}'
        try:
            req = Request(url, headers={'Accept': 'application/json'})
            with urlopen(req, timeout=15) as r:
                data = json.loads(r.read())
                if cache_key:
                    cache_set(cache_key, data, cache_ttl)
                return data
        except HTTPError as e:
            if e.code == 401:
                log('TMDB: Invalid API key', xbmc.LOGERROR)
            else:
                log(f'TMDB HTTP {e.code}: {path}', xbmc.LOGWARNING)
        except URLError as e:
            log(f'TMDB URLError: {e.reason}', xbmc.LOGWARNING)
        except Exception as e:
            log(f'TMDB error: {e}', xbmc.LOGWARNING)
        return None

    def _results(self, data):
        return (data or {}).get('results', [])

    # ------------------------------------------------------------------ #
    # Extract IDs from a TMDB result item
    # ------------------------------------------------------------------ #
    @staticmethod
    def get_ids(item):
        """Return (tmdb_id, imdb_id). imdb_id may be None if not in result."""
        return str(item.get('id', '')), item.get('imdb_id', '')

    # ------------------------------------------------------------------ #
    # Movie lists
    # ------------------------------------------------------------------ #
    def movies_popular(self, page=1):
        data = self._get('/movie/popular', {'page': page},
                         cache_key=f'tmdb_mov_popular_{page}', cache_ttl=3600)
        return self._results(data)

    def movies_trending_day(self):
        data = self._get('/trending/movie/day', {},
                         cache_key='tmdb_mov_trending_day', cache_ttl=1800)
        return self._results(data)

    def movies_trending_week(self):
        data = self._get('/trending/movie/week', {},
                         cache_key='tmdb_mov_trending_week', cache_ttl=3600)
        return self._results(data)

    def movies_top_rated(self, page=1):
        data = self._get('/movie/top_rated', {'page': page},
                         cache_key=f'tmdb_mov_toprated_{page}', cache_ttl=3600)
        return self._results(data)

    def movies_now_playing(self):
        data = self._get('/movie/now_playing', {},
                         cache_key='tmdb_mov_nowplaying', cache_ttl=3600)
        return self._results(data)

    def movies_upcoming(self):
        data = self._get('/movie/upcoming', {},
                         cache_key='tmdb_mov_upcoming', cache_ttl=3600)
        return self._results(data)

    # ------------------------------------------------------------------ #
    # TV lists
    # ------------------------------------------------------------------ #
    def tv_popular(self, page=1):
        data = self._get('/tv/popular', {'page': page},
                         cache_key=f'tmdb_tv_popular_{page}', cache_ttl=3600)
        return self._results(data)

    def tv_trending_day(self):
        data = self._get('/trending/tv/day', {},
                         cache_key='tmdb_tv_trending_day', cache_ttl=1800)
        return self._results(data)

    def tv_trending_week(self):
        data = self._get('/trending/tv/week', {},
                         cache_key='tmdb_tv_trending_week', cache_ttl=3600)
        return self._results(data)

    def tv_top_rated(self, page=1):
        data = self._get('/tv/top_rated', {'page': page},
                         cache_key=f'tmdb_tv_toprated_{page}', cache_ttl=3600)
        return self._results(data)

    def tv_on_air(self):
        data = self._get('/tv/on_the_air', {},
                         cache_key='tmdb_tv_onair', cache_ttl=3600)
        return self._results(data)

    def tv_airing_today(self):
        data = self._get('/tv/airing_today', {},
                         cache_key='tmdb_tv_airingtoday', cache_ttl=1800)
        return self._results(data)

    # ------------------------------------------------------------------ #
    # Get external IDs for a TMDB item (to match against Emby)
    # ------------------------------------------------------------------ #
    def movie_external_ids(self, tmdb_id):
        """Returns dict with imdb_id etc."""
        data = self._get(f'/movie/{tmdb_id}/external_ids',
                         cache_key=f'tmdb_mov_extids_{tmdb_id}', cache_ttl=86400)
        return data or {}

    def tv_external_ids(self, tmdb_id):
        data = self._get(f'/tv/{tmdb_id}/external_ids',
                         cache_key=f'tmdb_tv_extids_{tmdb_id}', cache_ttl=86400)
        return data or {}

    # ------------------------------------------------------------------ #
    # Build a lookup: {tmdb_id: item, imdb_id: item} from a results list
    # ------------------------------------------------------------------ #
    @staticmethod
    def build_id_map(results):
        """
        Returns a dict mapping both 'tmdb-NNNN' and 'tt...' (imdb) to
        the TMDB result item. Used for O(1) Emby matching.
        """
        id_map = {}
        for item in results:
            tid = str(item.get('id', ''))
            if tid:
                id_map[f'tmdb-{tid}'] = item
            iid = item.get('imdb_id', '')
            if iid:
                id_map[iid] = item
        return id_map
